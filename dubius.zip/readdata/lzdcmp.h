
#ifdef __cplusplus
extern "C" {
#endif

void LZDecompress(uint8_t *in, uint32_t insize, uint8_t *out, uint32_t *outsize);

#ifdef __cplusplus
};
#endif