/*
	IMAGE Header File
The Encyclopedia of Graphics File Formats	
*/
#ifndef __IMAGE__
#define __IMAGE__

#include "common.h"

#if defined( _WIN32 ) 

#else
	
#endif

#ifdef __cplusplus
extern "C" {
#endif


typedef struct
{
	unsigned char *bitmap;	/* w*h*bpp/8 */
	unsigned char *palette;	/* c*24/8 */
	uint32_t	w, h, c;	/* Width, Height, the number of colors */
	uint32_t	bpp;	/* bits per pixel */
	uint32_t	bpc;	/* bits per Red/Green/Blue channel */
} raw_file;


/* Read/Write Data from/to Binary File */
int32_t ReadBFile(char *FileName, uint32_t FileOffset, uint8_t **Buf, uint32_t *BufSize);
int32_t WriteBFile(char *FileName, uint8_t * DATBuf, uint32_t DATSize);
int32_t GetFileExtension(char *FileName, char *FileExtension, uint32_t *Length);
int32_t GetPathName(char *FileName, char *PathName, uint32_t *Length);
int32_t MakeDir(char *FileName);

#ifndef MY_TGA

#define MY_TGA

#define TGA_INTERLACED(a)       ( (a) & 0xc0 )
#define TGA_FLIP(a)             ( ((a) & 0x20) ? 0 : 1)
#define TGA_MAPPED              1
#define TGA_RGB                 2
#define TGA_RLE_MAPPED          9
#define TGA_RLE_RGB             10

/*
 * 18 Bytes Targa header.
 */
typedef struct {
		uint8_t	num_id;
		uint8_t	cmap_type;
		uint8_t	image_type;
		uint16_t	cmap_orign;
		uint16_t	cmap_length;
		uint8_t	cmap_entry_size;
		uint16_t	xorig, yorig;
		uint16_t	xsize, ysize;
		uint8_t	pixel_size;
		uint8_t	image_descriptor;
} tga_hdr;

#endif       /* MY_TGA */

int32_t WriteTGAFile(char *FileName, raw_file *raw);

/*
 RIX Image File, ColoRIX VGA Paint
 10 bytes header.
*/
typedef struct	_RIX_HEAD
{
	char	ID[4];			/* Three-character ID field, "RIX" */
	uint16_t	Width;		/* Image width in pixels */
	uint16_t	Height;		/* Image height in lines */
	uint8_t	PaletteType;	/* Palette type code */
	uint8_t	StorageType;	/* Format of bitmap data */
} RIX_HEAD;

/*
PaletteType identifies the type of display device and can have any of the values listed below.
Value	Type of Display Device
CB		EGA
AB		Extended EGA
AF		VGA
E7		Targa 16
9F		IBM PGA
10		Targa 16
18		Targa 24
20		Targa 32

StorageType can have any of the values listed below. 
Value	Type of Data
80		Compressed
40		Extension block
20		Encrypted
00		Linear, one byte per pixel
01		Planar (0213), similar to EGA
02		Planar (0123), similar to EGA
03		Text
 
If the storage type value indicates an extension block value, 
it is followed by a byte containing an extension format value. 
Some typical format extension types are illustrated below. 
Value	Type of Extension
00		ASCII text
01		Original image origin
02		Original image screen resolution
03		Encryptor's ID
04		Bitmap palette in use; length is either 2 or 32 bytes
 
Following the header is a palette, which is either 48 or 768 bytes long. 
Palette entries are stored as RGB triples, one for each color. 
Following the palette is the image data. 
If the image data is not encrypted or compressed, 
the data format can be deduced from the storage type value. 

*/

/*
 PCX Image File, PC Paintbrush File Format
 128 bytes header.
*/
typedef struct _PCXHEADER
{
  uint8_t	Identifier;		/* PCX Id Number (Always 0x0A) */
  uint8_t	Version;		/* Version Number */
  uint8_t	Encoding;		/* Encoding Format */
  uint8_t	BitsPerPixel;	/* Bits per Pixel */
  uint16_t	XStart;			/* Left of image */
  uint16_t	YStart;			/* Top of Image */
  uint16_t	XEnd;			/* Right of Image */
  uint16_t	YEnd;			/* Bottom of image */
  uint16_t	HorzResolution;	/* Horizontal Resolution */
  uint16_t	VertResolution;	/* Vertical Resolution */
  uint8_t	Palette[48];	/* 16-Color EGA Palette */
  uint8_t	Reserved1;		/* Reserved (Always 0) */
  uint8_t	NumBitPlanes;	/* Number of Bit Planes */
  uint16_t	BytesPerLine;	/* Bytes per Scan-line */
  uint16_t	PaletteType;	/* Palette Type */
  uint16_t	HorzScreenSize;	/* Horizontal Screen Size */
  uint16_t	VertScreenSize;	/* Vertical Screen Size */
  uint8_t	Reserved2[54];	/* Reserved (Always 0) */
} PCXHEADER;


raw_file* load_raw(char *name, int verbose, int debug_flag=0);
int32_t ReadRAWPix(uint8_t *buf, raw_file *raw, int debug_flag=0);
int32_t ReadRIXPix(uint8_t *buf, raw_file *raw, int debug_flag=0);

/*
Frame Buffer Processing for Video Card 
*/
int32_t Bitmap(uint8_t *Buf, uint32_t BufSize, uint8_t Plane, uint8_t *DataBuf);
int32_t WxHxP(uint8_t *Buf, uint32_t BufSize, uint32_t Width, uint16_t Height, uint8_t Plane, uint16_t numPix, uint8_t *DataBuf);
int32_t WxHxPUM(uint8_t *Buf, uint32_t BufSize, uint16_t Width, uint16_t Height, uint8_t Plane, uint8_t ColorDepth, uint8_t Endianness, uint8_t *DataBuf);

#ifdef __cplusplus
};
#endif

#endif 