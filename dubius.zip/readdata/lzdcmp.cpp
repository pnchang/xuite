/*
lzdcmp - file decompressor using limpel-ziev algorithm
Tom Pfau
Digital Equipment Corporation
Parsippany, NJ
LZ_ASM

David Kirschbaum
LZ13
ftp://ftp.scene.org/pub/mirrors/hornet/code/compress/
*/

#include <stdio.h>
#include <stdint.h>
#include "lzdcmp.h"	/* LZDecompress */

//Constants
#define	CLEAR	256
#define	EOD	257
#define	FIRST_FREE	258

//Hash table entry
typedef	struct _hash_rec
{
	uint32_t	Next;	// Next Code
	uint8_t	Char;
} hash_rec;

 
hash_rec	hash[4096];	//Dictionary  
uint32_t	cur_code;
uint32_t	old_code;
uint32_t	in_code;
uint32_t	free_code = FIRST_FREE;
uint32_t	stack_count = 0;
uint32_t	nbits = 9;
uint32_t	max_code = 512;
uint32_t	bit_offset = 0;
uint8_t	fin_char;
uint8_t	k;
uint32_t	mask;	//mask[]={ 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x01FF, 0x03FF, 0x07FF, 0x0FFF};
uint32_t	out_offset = 0;
uint32_t	stack[4096];
uint32_t	max_stack=0;	// 

void inittab()
{
	nbits = 9;
	max_code = 512;
	mask =511;
	free_code = FIRST_FREE;
}

uint32_t read_code(uint8_t	*in)
{
	uint32_t	a,c;

	c = bit_offset&7;
	a = bit_offset>>3;
	a =*((uint32_t*)(in+a));
	a = (a>>c)&mask; 
	bit_offset = bit_offset+nbits;
	
	return	(a);
}

void add_code()
{
	hash[free_code].Char = k;
	hash[free_code].Next = old_code;
	free_code++;
}

void LZDecompress(uint8_t *in, uint32_t insize, uint8_t *out, uint32_t *outsize)
{
	
	max_stack =0;
	bit_offset = 0;
	stack_count = 0;
	out_offset = 0;
	inittab();
	
	do{
		cur_code = read_code(in);
		if (cur_code==EOD)	break;
		if (cur_code==CLEAR)
		{
			inittab();
			do{
				cur_code = read_code(in);
				if (cur_code==EOD)	break;
			}while(cur_code==CLEAR);
			if (cur_code==EOD)	break;
			old_code = cur_code;
			k = cur_code;
			fin_char = k;
			out[out_offset++] = k;
		}
		else
		{
			in_code = cur_code;
			if (cur_code>=free_code)
			{
				cur_code = old_code;
				stack[stack_count++] = k;
			}
			
				while (cur_code>=CLEAR)
				{
					stack[stack_count++] = hash[cur_code].Char;
					cur_code = hash[cur_code].Next;
				}
				
				k = cur_code;
				stack[stack_count++] = k;
				
				if (stack_count>max_stack)	max_stack = stack_count;	// Maximum Stack Depth
				while (stack_count)
				{
					out[out_offset++]=stack[--stack_count];
				}
				if (free_code<max_code)
				{
					add_code();
					old_code = in_code;
				}
				if (free_code>=max_code)
				{
					if (nbits<12)
					{
						nbits++;
						max_code = max_code<<1;
						mask = max_code-1;
					}
				}
	
		}
	
	}while(1);
	*outsize = out_offset;
#if 1
	printf("(%06x %08x %08x)\t", max_stack, bit_offset/8, out_offset);
#endif	

}
