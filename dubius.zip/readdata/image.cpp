/*
	IMAGE Function 
*/
#include <stdio.h>
#include <stdlib.h>	/* malloc() */
#include <string.h>
#include <memory.h>
#ifdef __GNUC__
#include <sys/types.h>
#include <sys/stat.h>	/* mkdir() */
#endif
#if defined(_MSC_VER)||defined(MINGW)
#include <direct.h>	/* _mkdir() */
#endif
#include "image.h"


#if defined(__unix__)
/*
Prototype function
	strupr() 
*/
char *strupr(char *s)
{
	char *str;
	str = s;
	while (*str != '\0')
	{
		if (*str >= 'a' && *str <= 'z') {
			*str -= 'a'-'A';
		}
		str++;
	}
	return s;
}

#endif

/*
  Read Data From Binary File
  Return:
     0: Pass
	xx: Fail
*/
int32_t ReadBFile(char *FileName, uint32_t FileOffset, uint8_t **Buf, uint32_t *BufSize)
{
	FILE	*hFile;
	uint32_t	FileSize;
	uint32_t	numRead;
	int32_t	result = -1;
	
	hFile = fopen( FileName, "rb");

	/* Open for read (will fail if file does not exist) */
	if( hFile == NULL )
	{
		printf( "The file %s was not opened\n", FileName);
	}
	else
	{
		FileSize = -1;	// Default Size
 
		result	= fseek(hFile, 0L, SEEK_END);	//	SEEK_END End of File
		if (result)
		{
			// Error Handle
		}
		else
		{
			FileSize = ftell(hFile);	// Get a Right File Size
			if (FileSize<*BufSize)
			{
				result = result|0x0001;		// Enable bit 0			
				// ERROR if Buffer Size is bigger than File Size
				*BufSize =  FileSize;	// Set a Right Data Size
			}
			
				*Buf = (uint8_t*)malloc(*BufSize);	// number of Read Data
				if (*Buf==NULL)
				{
					result = result|0x0002;	// Enable bit 1
				}
				else
				{
					result = fseek(hFile, FileOffset, SEEK_SET);	//	SEEK_SET Set Offset of File
					numRead = fread(*Buf, 1, *BufSize, hFile);	
					result = fclose(hFile);
					// Pass 
					if (numRead==*BufSize)
					{
						result = 0;	// PASS
					}
					
				}
			
		}
	}
	
	return	result;
}

// Write Data To Binary File
int32_t WriteBFile(char *FileName, uint8_t * DATBuf, uint32_t DATSize)
{
	FILE	*hFile;
	uint32_t	numWritten;
	int32_t	result=-1;


		hFile = fopen( FileName, "w+b");
		/* Open for write */
		if( hFile == NULL )
		{
			printf( "The file %s was not created\n", FileName);
		}
		else
		{
			numWritten = fwrite( DATBuf, sizeof( char ), DATSize, hFile);

			if (numWritten==DATSize)
				printf( " %10d bytes >>", DATSize);
			
			/* Close stream */
			result = fclose(hFile);
			if( result )
				printf( "The file %s was not closed\n", FileName);
		}

		return	result;
}

// Get File Extension 
int32_t GetFileExtension(char *FileName, char *FileExtension, uint32_t *Length)
{
		int32_t	result=-1;
		uint32_t	extensionLength	= 0;

		if ((FileName!=NULL)&&(FileExtension!=NULL))
		{
			char *pDot	= FileName;
			pDot = strrchr(pDot, '.');
			pDot++;
			FileExtension[0] = '\0';	// NULL character
			extensionLength = strlen(pDot);
			result=-2;	// no extension or too short
			if ((pDot)&&(extensionLength<*Length))
			{
				strcpy(FileExtension, pDot);
				strupr(FileExtension);	// uppercase string						
				*Length = extensionLength;	// Real Length of File Extension
				result = 0;
			}	
		}
		
		return	result;
}

// Get Path Name - Directory folder
int32_t GetPathName(char *FileName, char *PathName, uint32_t *Length)
{
		int32_t	ErrNo=-1;	
		/*  a hierarchy of directories */
		char *pSlash	= FileName;
		char FolderSymbol = '\\';	// or '/'
		
		uint32_t	nameLength	= 0;

		// Check Folder Symbol backslash(\) or slash(/)
		pSlash = FileName;
		FolderSymbol = '\\';	// backslashes
		pSlash = strrchr(pSlash, FolderSymbol);
		if (pSlash==NULL)
		{
			pSlash = FileName;
			FolderSymbol = '/';	// slashes
			pSlash = strrchr(pSlash, FolderSymbol);
			if (pSlash==NULL)
				FolderSymbol = '\0';	// NULL 
		}
		// Valid Folder
		if (FolderSymbol) {
			// Find Path
			nameLength	= strlen(FileName)-strlen(pSlash)+1;
			ErrNo=-2;	// too short
			if (nameLength<*Length)
			{
				memcpy(PathName, FileName, nameLength);
				PathName[nameLength]='\0';	// NULL character
				*Length = nameLength;	// Real Length
				ErrNo = 0;
			}
		}
		
		return	ErrNo;
}

int32_t MakeDir(char *FileName)
{
		int32_t	ErrNo;	
		/*  Create a hierarchy of directories */
		char *pSlash	= FileName;
		char FolderSymbol = '\\';	// or '/'
		
		uint32_t	nameLength	= 0;

		// Check Folder Symbol backslash(\) or slash(/)
		pSlash = FileName;
		FolderSymbol = '\\';	// backslashes
		pSlash = strchr(pSlash, FolderSymbol);
		if (pSlash==NULL)
		{
			pSlash = FileName;
			FolderSymbol = '/';	// slashes
			pSlash = strchr(pSlash, FolderSymbol);
			if (pSlash==NULL)
				FolderSymbol = '\0';	// NULL 
		}
		// Valid Folder
		if (FolderSymbol) {
			// Create Subdirectory
			while (pSlash!=NULL)
			{
				pSlash	= strchr(pSlash, FolderSymbol);
				
				if (pSlash!=NULL)
				{
					/* Get the name of subdirectory */
					nameLength	= strlen(pSlash);
					if (nameLength)
					{ 
						char	*subdirectoryName;
						
						pSlash++;	// ignore first slash
					#if (DBGLEVEL&0x01) 
						printf("%s %d \t", pSlash, nameLength-1);
					#endif
						nameLength	= strlen(FileName)-nameLength;
						subdirectoryName = new char[nameLength+1];
						if (subdirectoryName)
						{
							strncpy(subdirectoryName, FileName, nameLength);
							subdirectoryName[nameLength] = '\0';
				
					#ifdef	WIN32
							ErrNo = _mkdir(subdirectoryName);
					#else
							ErrNo = mkdir(subdirectoryName, S_IWUSR);
					#endif
							delete	subdirectoryName;
						}
					}
				}	
			}; // while()
		}
		
		return	ErrNo;
}

/*
Write TGA File
*/
int32_t WriteTGAFile(char *FileName, raw_file *raw)
{
	int32_t	result=-1;
	tga_hdr	tga;
	uint32_t	Size;
	uint32_t	TGAOffset;
	uint8_t	TGAPalette[256*3];
	uint8_t	*TGABuf;	// PIX DATA	
	int32_t	i;
	
		// Initialize 	
		TGAOffset = 0;
		Size = sizeof(tga) + raw->c*3 + raw->w*raw->h*raw->bpp/8;	// total size
		TGABuf = (uint8_t*)malloc(Size);	// PIX DATA	
		if (TGABuf)
		{
			// Set TGA Header 
		
			/*
			* Bytes are in reverse order so ...
			*/
			tga.num_id	= 0x00;
			tga.cmap_type	= 0x01;
			tga.image_type	= 0x01;
			tga.cmap_orign	= 0x0000;	// 2 bytes
			tga.cmap_length = raw->c;	// 2 bytes
			tga.cmap_entry_size = 24;	// 1 byte
			tga.xorig = 0x0000;
			tga.yorig = 0x0000;
			tga.xsize = raw->w;
			tga.ysize = raw->h;
			tga.pixel_size = raw->bpp;     /* we'll use it directly */
			tga.image_descriptor = 0x20;
			Size = sizeof(tga);
			memcpy(TGABuf+TGAOffset, &tga, Size);
			TGAOffset = TGAOffset+Size;
		
			// RGB to BGR 
			uint8_t	b = 8-raw->bpc;	// 8 bits per each channel		
			for(i=0;i<(raw->c);i++)
			{
				uint8_t	tmp;
				tmp = *(raw->palette+i*3+0)<<b ;	// Red 
				TGAPalette[i*3+0] = *(raw->palette+i*3+2)<<b;	// Blue 
				TGAPalette[i*3+1] = *(raw->palette+i*3+1)<<b;	// Green
				TGAPalette[i*3+2] = tmp;	// Red 
			}
			// Palette Data
			Size = raw->c*3;
			memcpy(TGABuf+TGAOffset, TGAPalette, Size);
			TGAOffset = TGAOffset + Size;
			
			// Pixels Data
			Size = raw->w*raw->h*raw->bpp/8;
			memcpy(TGABuf+TGAOffset, raw->bitmap, Size);
			TGAOffset = TGAOffset + Size;
			
			WriteBFile(FileName, TGABuf, TGAOffset);
			free(TGABuf);
			result = 0;	// Pass
		}
	return 	result;
}

/*
Handmade Software Inc.(HSI) Raw 
Image Alchemy HSI Temporary Raw Bitmap 
Image Alchemy User's Manual 
*/

raw_file* load_raw(char *name, int verbose, int debug_flag)
{
	raw_file* raw = (raw_file*)malloc( sizeof(raw_file) );
	unsigned char head[32];
	uint32_t	size;
	FILE *f = fopen(name, "rb");

	if (debug_flag)
	{
		fprintf(stdout, "load_raw(): arg name=%s verbose=%d\n", name, verbose);
	}

	if(!f)	return NULL;							// can't open

	if (fread(head, 32, 1, f) < 1)	return NULL;	// too small
	if (memcmp(head, "mhwanh", 6))	return NULL;	// not raw file

	raw->w = head[8] * 256 + head[9];
	raw->h = head[10] * 256 + head[11];
	raw->c = head[12] * 256 + head[13];
	if (raw->c > 256)	return NULL;				// too many colors!?
	if (debug_flag)
	{
		printf("RAW: %s %d x %d, %d colors\n", name, raw->w, raw->h, raw->c);
	}
	if (raw->c)
	{
		raw->palette = (unsigned char *)malloc(raw->c * 3);
		fread(raw->palette, 3, raw->c, f);
		raw->bpp = 8;
		raw->bpc = 8;
	}
	else
	{
		raw->palette = NULL;
		raw->bpp = 24;
		raw->bpc = 8;
	}
	size = raw->h * raw->w * raw->bpp/8;
	raw->bitmap = (unsigned char *)malloc(size);
	fread(raw->bitmap, size, 1, f);

	fclose(f);

	return raw;
} /* end function load_raw */

/*
Read HSI Raw Picture Data from Buffer
*/
int32_t ReadRAWPix(uint8_t *buf, raw_file *raw, int debug_flag)
{
	int32_t	result=-1;
	uint8_t Head[32];
	uint32_t	Offset;
	uint32_t	Size;
	
	Offset	= 0;
	Size	=32;
	memcpy(Head, buf+Offset, Size);	// 32 bytes
	Offset = Offset + Size; 
	if (memcmp(Head, "mhwanh", 6)==0)	
	{
		// HSI Raw Picture

		raw->w = Head[8] * 256 + Head[9];	// Big Endian 
		raw->h = Head[10] * 256 + Head[11];
		raw->c = Head[12] * 256 + Head[13];
		if (raw->c <= 256)	
		{
			// reasonable value
			
			if (debug_flag)
			{
				printf("HSI RAW: %d x %d, %d colors\n", raw->w, raw->h, raw->c);
			}
			if (raw->c)
			{
				Size = raw->c * 3;
				raw->palette = (unsigned char *)malloc(Size);
				memcpy(raw->palette, buf+Offset, Size);
				Offset = Offset + Size; 
				raw->bpp = 8;
				raw->bpc = 8;
			}
			else
			{
				raw->palette = NULL;
				raw->bpp = 24;
				raw->bpc = 8;
			}
			
			Size = raw->h * raw->w * raw->bpp/8;
			raw->bitmap = (unsigned char *)malloc(Size);
			memcpy(raw->bitmap, buf+Offset, Size);
			Offset = Offset + Size; 
			result = 0;	// Pass
		}
	}
	
	return	result;
}

/*
Read ColoRIX Image Data from Buffer
*/
int32_t ReadRIXPix(uint8_t *buf, raw_file *raw, int debug_flag)
{
	int32_t	result=-1;
	RIX_HEAD	Head;
	uint32_t	Offset;
	uint32_t	Size;
	
	Offset	= 0;
	Size	=sizeof(RIX_HEAD);
	memcpy(&Head, buf+Offset, Size);	// 32 bytes
	Offset = Offset + Size; 
	if (memcmp(Head.ID, "RIX3", 4)==0)	
	{
		// ColorRIX Picture
		raw->w = Head.Width;	// Little Endian 
		raw->h = Head.Height;
		raw->c = -1;	// Deafult  
		switch (Head.PaletteType)
		{
			case 0xAF:
			//VGA
				raw->c = 256;	// the number of colors
				raw->bpp = 8;	// bits per pixel
				raw->bpc = 8;	// bits per channel			
				break;
			
		}
			if (debug_flag)
			{
				printf("ColorRIX: %d x %d, %d colors\n", raw->w, raw->h, raw->c);
			}		
		if (raw->c <= 256)	
		{
			// reasonable value
			if (raw->c)
			{
				Size = raw->c * 3;
				raw->palette = (unsigned char *)malloc(Size);
				memcpy(raw->palette, buf+Offset, Size);
				Offset = Offset + Size; 

			}
			else
			{
				raw->palette = NULL;
				raw->bpp = 24;
				raw->bpc = 8;
			}
		}
		
		if (Head.StorageType==0x00)
		{
			Size = raw->h * raw->w * raw->bpp/8;
			raw->bitmap = (unsigned char *)malloc(Size);
			memcpy(raw->bitmap, buf+Offset, Size);
			Offset = Offset + Size; 
			result = 0;	// Pass
		}
	}
	
	return	result;
}

/*
For example:
80*480 8-bit to 640*480 1-bit Bitmap
*/
int32_t Bitmap(uint8_t *Buf, uint32_t BufSize, uint8_t Plane, uint8_t *DataBuf)
{
	int32_t	Status=0;	
	uint32_t	i,b;
	uint32_t	Offset;
	uint8_t	x,c;	
	uint8_t	M[8]={0x80, 0x40, 0x20, 0x10, 0x08, 0x04, 0x02, 0x01};

	for (i=0;i<BufSize;i++)
	{
		x = Buf[i];
		Offset=i*8;	// 8-bit
		for(b=0;b<8;b++)
		{
			if (x&M[b])	c=0x01;
			else	c=0x00;
			DataBuf[Offset+b]=(c<<Plane);
		}
	}
	
	return	Status;	
}

/*
Width/8*Hight*4Plane*Number Pictures
640*480 16 Colors Picture
Plane: depth of colors ( x-bits)
numPix: number of pictures (numPix>=1)
*/
int32_t WxHxP(uint8_t *Buf, uint32_t BufSize, uint32_t Width, uint16_t Height, uint8_t Plane, uint16_t numPix, uint8_t *DataBuf)
{
	int32_t	Status=-1;
	uint32_t	i, h, Offset,PlaneSize,FBSize;
	uint32_t	n;	// picture number
	uint8_t	p;	// plane number
	uint8_t	*pFB;	// pointer of Frame Buffer 

	Offset = 0;
	PlaneSize = Width/8*1/numPix;
	if (BufSize==(PlaneSize*Height*Plane*numPix))
	{
		FBSize =  Width*1/numPix;
		pFB = new uint8_t[FBSize];
		if (pFB)
		{
			for (n=0;n<numPix;n++)
			{
				for(h=0;h<Height;h++)
				{
					for (p=0;p<Plane;p++)
					{
						Offset=(((n*Height+h)*Plane)+p)*PlaneSize;	// offset of nth Plane 
						Status=Bitmap(Buf+Offset, PlaneSize, p, pFB);
						for(i=0;i<FBSize;i++)
						{
							DataBuf[(((n*Height)+h)*FBSize)+i]=DataBuf[(((n*Height)+h)*FBSize)+i]|pFB[i];
						}
					}
				}
			}
			delete	pFB;
		}
	}
	
	return	Status;
}

/*
Width/4*Hight*(ColorDepth/8)*4Plane unchained mode Picture
320*200*4/8  16 Colors Picture in Byte
*/
int32_t WxHxPUM(uint8_t *Buf, uint32_t BufSize, uint16_t Width, uint16_t Height, uint8_t Plane, uint8_t ColorDepth, uint8_t Endianness, uint8_t *DataBuf)
{
	int32_t	Status=-1;
	uint32_t	i, Offset,PlaneSize,FBSize;
	uint8_t	p;
	uint8_t	n;	// numbers of Pixel in Byte	
	uint8_t	mask;	// 0x01, 0x03, 0x07, 0x0F, 0x1F, 0x3F, 0x7F, 0xFF
	uint8_t	*pFB;	// pointer of Frame Buffer 
	

	Offset = 0;
	if (ColorDepth>0)
	{
		Status=-4;
		
		n = (8/ColorDepth);	// numbers of Pixel in Byte		
		PlaneSize = Width/4*Height/n;
		uint8_t	mask = 0xFF>>(8-ColorDepth);
		if (BufSize==(PlaneSize*Plane))
		{
			for (p=0;p<Plane;p++)
			{
				Offset=p*PlaneSize;	// offset of nth Plane 
				for(i=0;i<PlaneSize;i++)
				{
					uint8_t	x = Buf[Offset+i];
					for(int d=0;d<n;d++)
					{
						uint8_t	b, e;
						b = ColorDepth*d;	// right shift by b bits
						e=d;
						if (Endianness)	e=(n-1)-d;
						DataBuf[(i*n+e)*4+p]=(x>>b)&mask;
					}
				}
			}
			Status=0;
		}
	}
	
	return	Status;
}

/*
640*480 16 Colors Picture
*/
int32_t X320Y200(uint8_t *CodeBuf, uint16_t CodeSize, uint8_t *DataBuf)
{
	int32_t	Status=0;
	uint32_t	DataSize;
	
	DataSize = 320*200;
	//RLD
//	Status=RLD(CodeBuf, CodeSize, DataBuf, DataSize); 
	
	return	Status;
}
