/*
1994\d\dbs-od
Other Dimension
1995\o\optimal
1995\s\state
State of Hate
1996\m\machines
Machines of Madness
1996\m\mview
Magic View
1996\r\rotali
Rotaliator
Dubius
Finland
*/
#include <stdio.h>
#include <stdlib.h>	/* free() */
#include <string.h>	/* strrchr() */
#include <memory.h>
#ifdef __GNUC__
#include <sys/types.h>
#include <sys/stat.h>	/* mkdir() */
#endif
#ifdef _MSC_VER
#include <direct.h>	/* _mkdir() */
#endif
#include <stdint.h>	/* standard integer */

#include "common.h"
#include "image.h"	/* image */
#include "lzdcmp.h"	/* LZDecompress() */

#define	DBG		0x0000
#ifndef	UINT32_MAX
#define UINT32_MAX  4294967295UL
#endif 

#ifndef	MAX_PATH
#define	MAX_PATH	256
#endif

// Limitation
#define	RAWSIZE		8*1024*1024

//	Read data from the file unreal
uint32_t	DIRSize;


#pragma pack(push)	/* push current alignment to stack */
#pragma pack(1)	/* set alignment to 1 byte boundary */

/*
4 bytes Length Data Information Header 
in little endian
*/
typedef	struct _infoHeader{
	uint32_t	Offset;	// offset of directory
} infoHeader;
/*
21 bytes Length Directory Entry 
*/
typedef	struct _directoryEntry{
	uint32_t	Offset;	// Offset of Data
	uint32_t	Size;	// Size of Data
	uint8_t	Name[13];	// Filename 
} directoryEntry;

typedef	struct _pixInfo{
	uint32_t	Base;
	uint32_t	Offset;
	uint32_t	Size;
	uint16_t	Width;
	uint16_t	Height;
	uint8_t	Plane;
	uint8_t	PaletteInfoNo;
} pixInfo;


typedef	struct _paletteInfo{
	uint32_t	Base;
	uint32_t	Offset;
	uint32_t	Size;
	uint8_t	ColorNo;
} paletteInfo;

/* 8-byte length */
typedef	struct _pixHeader{
	uint16_t	Width;
	uint16_t	Height;
	uint8_t	u[4];
} pixHeader;

/* Program segmentation */
typedef	struct _programInfo{
	uint32_t	Offset;
	uint32_t	Size;
} programInfo;	

#pragma pack(pop)	/* restore original alignment from stack */

/*
Pix File
W definition:
0: Header of Pix 
otherwise, it is a width of picture
Palette: 256 colors * 3 channels RGB
*/
int32_t PixFile(char *FileName, uint8_t *Buf, uint32_t BufSize, uint16_t W, uint8_t *Palette)
{
	int32_t	Status=-1;
	char	Filename[1024];

	uint32_t	Base, Offset, Size;
	uint8_t		*Pix;
	uint32_t	PixSize;
	uint16_t	Width, Height, Plane;	
	uint32_t	PaletteOfs, PaletteSize;
	pixHeader	PixHeader;	
	//RIX_HEAD	RIXHeader;
	raw_file	RawPix;	

	if (W)
	{
		// By Argument W
		Offset = 0;	// Offset of Pix Data
		Size = 0;	// Size of Pix Header
		PixHeader.Width = W;
		PixHeader.Height = BufSize/PixHeader.Width;		
	}
	else
	{
		// Default
		Offset = 0;	// Offset of Pix Header
		Size = sizeof(pixHeader);	// Size of Pix Header
		memcpy(&PixHeader, Buf, Size);
		Offset = Offset+Size;	// Offset of Pix Data
	}
		Width = PixHeader.Width;
		Height = PixHeader.Height;
		PixSize = Width*Height*1;

				Pix = Buf+Offset;				
				RawPix.w = Width;
				RawPix.h = Height;
				RawPix.c = 256;
				RawPix.bpp = 8;
				RawPix.bpc = 6;
				RawPix.palette = Palette;
				RawPix.bitmap = Pix;
		
				sprintf(Filename, "%s.TGA", FileName);	
				printf("\t %12s: %08x %08x %6d x %6d %6d colors" , Filename, Offset, Size, RawPix.w, RawPix.h, RawPix.c);

					WriteTGAFile(Filename, &RawPix);	
					printf("\n");

					
	return	Status;	
}

/*
Data in Executable File
*/
int32_t Data(uint8_t *Buf, uint32_t BufBase, uint32_t BufSize, uint32_t EXESize)
{
	int32_t	Status=-1;
	char	Filename[128];
	char	DstFilename[128];
	uint8_t	Maximum;
	int32_t	i;
	uint8_t	*p;
	uint32_t	Base, Offset, Size;
	infoHeader	*InfoHeader;
	directoryEntry	de;
	uint32_t	DirectoryOffset, DirectorySize;
	uint16_t	numData;	// number of Data
	uint32_t	DataOffset, DataSize;
	uint32_t	DataType;
	uint16_t	numPix;	// number of Picture
	uint8_t		*Pix;	
	uint16_t	Width, Height, Plane;
	uint32_t	PlaneSize;
	uint16_t	numPlane;
	uint32_t	Length;
	uint32_t	RAWSize;
	uint8_t	Palette[256*3];
	uint32_t PaletteOffset, PaletteSize;	
	//RIX_HEAD	RIXHeader;
	raw_file	RawPix;	

// EXE
	programInfo	ProgramInfoTable[]={
			{ 0x00000000, 0x00003500},	// Seg000 CODE
		};

	uint32_t	DataOffsetTable[]={
			0x000084D0,
			0x0000F413,
			0x0000F713,
			0x0000FA13,
			0x0000FDBA,
			0x000100BA,
			0x000125DE,
			0x0001306A,
			0x000155FF,
			0x00016DF7,
			0x000195F3,
			0x0001B664,
			0x0001DADD,
			0x0001E9D6,
			0x0001ECD6,
			0x0001F1A4,
			0x0002DC97,
			0x00030451,
			0x00030DFD,
			0x0009F3A7
		};
		
	pixInfo	PixInfoTable[]={
			{ 0x00003660,0x0600,0xCF40,320,165,1, 0},	// seg003 
		};
	paletteInfo	PaletteInfoTable[]={
			{ 0x00003660,0x0000,0x0300,0},	//0 seg003
	};
		// Initialize
	if (EXESize==0x80FB)
	{
		// 1994\d\dbs-od 
		numData = sizeof(DataOffsetTable)/sizeof(uint32_t)-1;	// Number of data
		printf("%3d\n", numData);		
		for(i=0;i<numData;i++)
		{
			uint32_t	n, EntryOffset;
			uint8_t	t;
			
			
			DataOffset = DataOffsetTable[i]; // from the begin of file
			DataSize = DataOffsetTable[i+1]-DataOffsetTable[i];
			Offset = DataOffset;
			t = Buf[DataOffset];
			// Check first byte for file type.
			switch(t)
			{
				case 0x00:
					sprintf(Filename,"%02d.PAL", i);
				break;
				case 0x0A:
					sprintf(Filename,"%02d.PCX", i);
				break;
				case 0x50:
					sprintf(Filename,"%02d.S3M", i);
				break;
				default:
					sprintf(Filename,"%02d.DAT", i);
				break;
			}
			printf("\t%2d  %24s %08x %08x %08x \t", i, Filename, DataOffset, DataSize, (DataOffset+DataSize));
				Status = WriteBFile(Filename, Buf+DataOffset, DataSize);	
				printf("\n");

		}		
	}
	else
	{
		Base = EXESize;	// MZ EXE Size
		Offset = Base;
		Size = sizeof(directoryEntry);
		memcpy(&de, Buf+Offset, Size);
		DirectoryOffset = Offset;	// Offset of Directory
		DirectorySize = de.Offset;	// Size of Directory		
		numData = DirectorySize/Size;	// Number of data
		printf("%3d %08x %08x\n", numData, DirectoryOffset, DirectorySize);		
		for(i=0;i<numData;i++)
		{
			uint32_t	n, EntryOffset;
			
			memcpy(&de, Buf+Offset, Size);
			EntryOffset = Offset;	// Save it for debug used 
			sprintf(Filename,"%s", de.Name);
			DataOffset = Base+de.Offset; // from the begin of file
			DataSize = de.Size;
			printf("\t%2d  %08x %24s %08x %08x %08x \t", i, EntryOffset, Filename, DataOffset, DataSize, (DataOffset+DataSize));
			Offset = Offset+Size;	//
				Status = WriteBFile(Filename, Buf+DataOffset, DataSize);	
				printf("\n");

		}
	}
			printf(" number of data: %3d\n", numData);

	return	Status;
}

/*
Do Executable File(s)
BufBase: should be 0.
EXEBase: start address of code
EXESize: size of all executable files
*/
int32_t DoEXE(char *FileName, uint8_t *Buf, uint32_t BufBase, uint32_t BufSize, uint32_t *EXEBase, uint32_t *EXESize)
{
	int32_t	Status;
	char	Filename[128];
	uint32_t	Base, Offset, Size;	
	uint32_t	numEXE;	// number of EXE Files	
	uint32_t	sizeEXE;	// Size of All Executable Files
	IMAGE_DOS_HEADER *ImageDOSHeader;
	
	// Initialize
	Status = -1;
		*EXEBase = 0;	// zero code base
		
		numEXE	=0;
		sizeEXE	= 0;		
		Offset = BufBase;	// Start Address of Buffer
		ImageDOSHeader = (IMAGE_DOS_HEADER*)(Buf+Offset);
			// Check Signature 'MZ' 
			while ((*ImageDOSHeader).e_magic==IMAGE_DOS_SIGNATURE)
			{
				Base = (ImageDOSHeader->e_cparhdr)<<4;	// Base of CODE
				if (numEXE==0)	*EXEBase = Base;	// get Address of Code in First Executable File
				Size = ImageDOSHeader->e_cblp;
				if (Size)	Size = 512-Size;	// n bytes left on last page
				Size = (ImageDOSHeader->e_cp)*512-Size;
				printf("\t%3d  %08x %08x\t", numEXE, Offset, Size);
				sprintf(Filename, "%s%02d.EXE", FileName, numEXE);
				Status = WriteBFile(Filename, Buf+Offset, Size);	// write out the execute file.
				printf("\n");
				// if it is a pack execute file, crunch it. 
				Offset = Offset+Size;
				numEXE++;
				if (Offset>=BufSize)	break;	//	Excess 
				ImageDOSHeader = (IMAGE_DOS_HEADER*)(Buf+Offset);
			}
		
		if (numEXE)
		{
			// Find Executable File(s)
			*EXESize = Offset;
			printf("\t%3d  %08x %08x\n", numEXE, *EXEBase, *EXESize);
		}
		
	return	Status;
}

/*
XOR Operator 
Directory Entry in Data File
*/
typedef union _B4_t
{
	uint8_t	c[4];
	uint32_t	i;
	float	f;
} B4_t;

/* definition */
float	Key0 = 2.8516f;
float	Key1 = 7.2694f;
float	Key2 = 0.0;

#define	N	13
int32_t Xor(uint8_t *Buf, uint32_t BufSize)
{
	int32_t	Status=0;
	int32_t	i;
	uint32_t	k0, k1;
	uint32_t	*p;
	
	k0 = *(uint32_t*)&Key0;	//0x4036809D
	k1 = *(uint32_t*)&Key1;	//0x40E89EED
	
	p=(uint32_t*)(Buf+0);
	*p=(*p>>13)|(*p<<(32-13));	//ror 
	*p=*p-k1;
	*p=*p^k0;
	p=(uint32_t*)(Buf+4);
	*p=(*p>>7)|(*p<<(32-7));	//ror 
	*p=*p-k0;
	*p=*p^k1;
	// name
	p=(uint32_t*)(Buf+8);
	*p=(*p>>23)|(*p<<(32-23));	//ror 
	*p=*p^k1;
	*p=*p-k1;
	p=(uint32_t*)(Buf+12);
	*p=(*p>>9)|(*p<<(32-9));	//ror 
	*p=*p^k1;
	*p=*p-k1;
	p=(uint32_t*)(Buf+16);
	*p=(*p>>14)|(*p<<(32-14));	//ror 
	*p=*p^k1;
	*p=*p-k1;
	
	return	Status;
}

/*
Data Number: the index of directory 
Data Body in Data File
All float operations in the FPU, avoid getting a truncated value.
*/
int32_t Decode(uint8_t *Buf, uint32_t BufBase, uint32_t BufSize, uint32_t Number)
{
	int32_t	Status=0;
	int32_t	i;
	uint32_t	x, r, b;
	uint32_t	Offset;
	uint8_t	*p;
	
	// 2.8515999f, 7.2694001f
	__asm {
		fld     Key0
		fld     Key1
		fimul   Number
		mov     eax, BufBase
		shr     eax, 2
		inc     eax
		mov     x, eax
		fld     Key0
		fimul   x
		faddp   st(1), st
		fst     Key2
		wait
	}
	
/*	
	x = BufBase/4+1;
	Key2 = Key1*Number+Key0*x;
*/	
	p = (uint8_t*)&Key2;
	Offset = 0;
	// padding for a 4 bytes aligned address
	r= BufBase&0x03;	// %4
	Offset = 0;
	if (r)
	{
		for(i=r;i<4;i++)
		{
			Buf[Offset]=Buf[Offset]^p[i&3];
			Offset++;
		}
		//Key2=Key2+Key0;
		__asm{
			fadd   st, st(1)
			fst   Key2
		}
	}
	BufSize = BufSize-Offset; 
	for(i=0;i<BufSize;i++)
	{
		Buf[Offset]=Buf[Offset]^*((uint8_t*)&Key2+(i&3));	//p[i&3];
		Offset++;
		if ((i&3)==3)
		{
			//Key2=Key2+Key0;
			__asm{
			fadd   st, st(1)
			fst   Key2
			}
		}
	}
	__asm{
		fcompp
	}
	return	Status;
}


/*
Do Data File(s)
*/
int32_t DoDATA(uint8_t *Buf, uint32_t BufSize)
{
	int32_t	Status=-1;
	char	Filename[128];	
	uint32_t	Base, Offset, Size;	
	uint32_t	numData;	// number of Data Files	
	uint32_t	i, k;
	uint8_t	*p;
	infoHeader	*InfoHeader;
	directoryEntry	*de;
	uint32_t	DirectoryOffset, DirectorySize;
	uint32_t	DataOffset, DataSize;
	uint32_t	DataType;
	uint32_t	cSize, dSize;	// compressed/ decompressed data
	
		de = new directoryEntry[1];
		if (de)
		{		
			Offset = 0;
			Size = sizeof(directoryEntry);
			memcpy(de,(Buf+Offset),Size);
			Xor((uint8_t*)de, Size);	// Offset in first Directory Entry
			DirectoryOffset = Offset;	// Offset of Directory
			DirectorySize = de->Offset;	// Size of Directory
			numData = DirectorySize/Size;
			printf("%3d %08x %08x\n", numData, DirectoryOffset, DirectorySize);
			//numData = 2;
			for(i=0;i<numData;i++)
			{
				uint32_t	n, EntryOffset;
				
				Offset = DirectoryOffset+Size*i;	// Offset of Directory Entry
				memcpy(de,(Buf+Offset),Size);
				Xor((uint8_t*)de, Size);
				EntryOffset = Offset;	// Save it for debug used
				//Offset = Offset+Size;	// Next Directory
				sprintf(Filename,"%s", de->Name);
				DataOffset = de->Offset; // from the begin of file
				DataSize = de->Size;
				printf("\t%3d %08x %24s %08x %08x %08x\t", i, EntryOffset, Filename, DataOffset, DataSize, (DataOffset+DataSize));
				p = new uint8_t[DataSize];
				if (p)
				{
					char	*pExtension;
					uint8_t	isEXE=0;
					
					pExtension = strchr(Filename, '.');	
					// Filename extension 
					//printf("%s", pExtension+1);
					Status = memcmp(pExtension+1,"exe",3);
					if (Status==0)	isEXE=1;
					
					memcpy(p,Buf+DataOffset,DataSize);
					// decode data 
					Status = Decode(p, 0, DataSize, i);
					// decompressed data 
					if (isEXE)
					{
						uint8_t	*In, *Out;
						uint32_t	cSize, dSize;
						
						// "DubiouslyCompressedFile!"
						In = p+0x20;
						cSize = *(uint32_t*)(p+0x1c);
						dSize = *(uint32_t*)(p+0x18);
						printf("%08x %08x\t", cSize, dSize);
						Out = new uint8_t[dSize+2048];
						if (Out)
						{
							LZDecompress(In, cSize, Out, &dSize);
							printf("%8x\t", dSize);
							Status = WriteBFile(Filename, Out, dSize);	// write data to a file.
							delete	Out;
						}
					}
					else
					{
						// the other type files
						Status = WriteBFile(Filename, p, DataSize);	// write data to a file.
					}
					printf("\n");
					delete	p;
				}
				
			};
			delete	de;
			printf(" number of data: %3d\n", numData);
			
			Status = 0;
		}
	
	return	Status;
}


/* main program */
int main(int argc, char* argv[])
{
	FILE	*hFile;
	char	Filename[MAX_PATH];
	uint32_t	FileBase;
	uint32_t	FileOffset;
	uint32_t	numRead, numWritten;
	uint32_t	Base, Size, Offset;	
	uint32_t	Status;
	uint8_t	*CODEBuf = NULL;	// pointer of CODE Buffer
	uint8_t	*DATABuf = NULL;	// pointer of DATA Buffer

	if (argc==2)
	{
		strcpy(Filename, argv[1]);
	}
	else
	{
		printf("Syntax: %s FILENAME.EXE \n", argv[0]);
		return	-1;	
	}

	FileOffset = 0L;
	numRead = UINT32_MAX;	// Maximum value
	Status = ReadBFile( Filename, FileOffset, &CODEBuf, &numRead);	// Read CODE File
	if (Status==0)
	{
		char	PathName[4096];
		char	FileName[2048];
		char	FileNameExtension[1024];
		char	*p;
		uint32_t	Signature;		
		uint32_t	Length;
		
		PathName[0]='\0';	// NULL character
		Length = sizeof(PathName);
		Status = GetPathName(Filename, PathName, &Length);
		if (Status==0)
		{
			// Path
			printf("%s %4d  ", PathName, Length);
		}
		sprintf(FileName, "%s", Filename+Length);	// Filename
		p = strchr(FileName, '.');	
		if (p)
		{
			// Filename extension 
			sprintf(FileNameExtension,"%s", p+1);
			*p='\0';	// Null terminator
		}
		printf("%s%s.%s\t%08x %12d(%08x)\n", PathName, FileName, FileNameExtension, FileOffset, numRead, numRead);
			Base = 0;
			Offset = 0;
			Size = 0;
			Status = DoEXE(FileName, CODEBuf, Offset, numRead, &Base, &Size);
			Signature = *(uint32_t*)(CODEBuf+Size);
			// 4-byte Length
			switch	(Signature)
			{
			}
			
			Status = Data(CODEBuf, Base, numRead, Size);
			// .DAT File
			sprintf(Filename,"%s%s.DAT", PathName, FileName);
			FileOffset = 0L;
			numRead = UINT32_MAX;	// Maximum value
			Status = ReadBFile( Filename, FileOffset, &DATABuf, &numRead);	// Read CODE File
			if (Status==0)
			{
				printf("%s\t%08x %12d(%08x)\n", Filename, FileOffset, numRead, numRead);
				Status = DoDATA(DATABuf, numRead);
				free(DATABuf);	// free memory
			}
			
				
		free(CODEBuf);	// free memory
	}
	
	
	return	Status;
}

	
