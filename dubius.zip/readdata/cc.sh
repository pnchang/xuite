# linux 
#export LD_LIBRARY_PATH=/usr/local/lib 
gcc -fpack-struct=1 -fno-exceptions -fpermissive -static -D"__STDC_LIMIT_MACROS" -o readdatg  image.cpp lzdcmp.cpp readdat.cpp -lstdc++  
