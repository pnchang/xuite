////////////////////////////////////////////////////////
//
//		Curves  -  A B-Spline Mystify Screen Saver
//
//			Coded by Ben Houston
//
//			Created on July 11, 1997
//			Updated on July 29, 1997
//

#ifdef	__TURBOC__
#include <graphics.h>
#include <conio.h>
#include <dos.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>	// Standard Integer Types
#include <time.h>	// time()
#include "azrmath.h"

#define	NUM_CONTROLPTS	(7)
#define	QUEUE_SIZE		(10)

#define	MAX_SCREEN_X	(FWIDTH)
#define	MAX_SCREEN_Y	(FHEIGHT)
#define	MAX_DELTA		(15)

typedef struct
{
	int	x, y;
}	POINT2;

POINT2		vertices[NUM_CONTROLPTS];
POINT2		deltas[NUM_CONTROLPTS];

int			Index;	// local variable 
POINT2		queue[QUEUE_SIZE][NUM_CONTROLPTS];

void	initcontrol ( POINT2 *vertex, POINT2 *delta );
void	advancecontrol ( POINT2 *vertex, POINT2 *delta );
void	drawcurve ( POINT2 *a, POINT2 *b, POINT2 *c, POINT2 *d );

// DRAWING FUNCTIONS
void Putpixel(uint32_t X, uint32_t Y, uint32_t Colour, uint32_t *FrameBuffer);
void Line(uint32_t a, uint32_t b, uint32_t c, uint32_t  d, uint32_t Colour, uint32_t *FrameBuffer);

// Putpixel() - This puts a pixel on the screen by writing directly to memory. //
int Color;	// Colour
int Xmin = 0;
int Xmax = MAX_SCREEN_X-1;
int Ymin = 0;
int Ymax = MAX_SCREEN_Y-1;
void Putpixel (uint32_t X, uint32_t Y, uint32_t Colour, uint32_t *FrameBuffer) {
	if ( ((X>=Xmin)&&(X<=Xmax))&&((Y>=Ymin)&&(Y<=Ymax)) )
		FrameBuffer[X+Y*MAX_SCREEN_X] = Colour;
}

int abso(int value) {  if (value >= 0) return value;  else return -value; }

// sgn() - This checks the sign of an integer and returns a 1, -1, or 0.   //
int sgn(int a) {

	if (a > 0)  return +1;
	if (a < 0)  return -1;
	return 0;
}

// Line() - This draws a line from a,b to c,d of color col on screen Where //
void Line(uint32_t a, uint32_t b, uint32_t c, uint32_t d, uint32_t color, uint32_t *FrameBuffer) {

  int i,u,s,v,d1x,d1y,d2x,d2y,m,n;

  u   = c-a;       // x2-x1
  v   = d-b;       // y2-y1
  d1x = sgn(u);    // d1x is the sign of u (x2-x1) (VALUE -1,0,1)
  d1y = sgn(v);    // d1y is the sign of v (y2-y1) (VALUE -1,0,1)
  d2x = sgn(u);    // d2x is the sign of u (x2-x1) (VALUE -1,0,1)
  d2y = 0;
  m   = abso(u);   // m is the distance between x1 and x2
  n   = abso(v);   // n is the distance between y1 and y2

  if (m<=n) {      // if the x distance is greater than the y distance
    d2x = 0;
    d2y = sgn(v);  // d2y is the sign of v (x2-x1) (VALUE -1,0,1)
    m   = abso(v); // m is the distance between y1 and y2
    n   = abso(u); // n is the distance between x1 and x2
  }

  s = m / 2; // s is the m distance (either x or y) divided by 2

  for (i=0;i<m+1;i++) { // repeat this loop until it
                 // is = to m (y or x distance)
    Putpixel(a,b,color,FrameBuffer); // plot a pixel at the original x1, y1
    s += n;                  // add n (dis of x or y) to s (dis of x of y)
    if (s >= m) {            // if s is >= m (distance between y1 and y2)
      s -= m;
      a += d1x;
      b += d1y;
    }
    else {
      a += d2x;
      b += d2y;
    }
  }

}

#if 0
#define MULTIPLIER      0x015a4e35L
#define INCREMENT       1
static  long    Seed = 1;
int rand()
{
        Seed = MULTIPLIER * Seed + INCREMENT;
        return((int)(Seed >> 16) & 0x7fff);	
}
#endif

int Random(int x)
{
	return (rand()%x);
}

// 16 colors Red, Green, Blue
unsigned char Palette[16][3] = 
{
	{0x00, 0x00, 0x00},	// Black
	{0x00, 0x00, 0xAA},	// Blue
	{0x00, 0xAA, 0x00},	// Green
	{0x00, 0xAA, 0xAA},	// Cyan
	{0xAA, 0x00, 0x00},	// Red
	{0xAA, 0x00, 0xAA},	// Magenta
	{0xAA, 0x55, 0x00},	// Brown
	{0xAA, 0xAA, 0xAA},	// Light Gray
	{0x55, 0x55, 0x55},	// Gray
	{0x55, 0x55, 0xFF},	// Light Blue
	{0x55, 0xFF, 0x55},	// Light Green
	{0x55, 0xFF, 0xFF},	// Light Cyan
	{0xFF, 0x55, 0x55},	// Light Red
	{0xFF, 0x55, 0xFF},	// Light Magenta
	{0xFF, 0xFF, 0x55},	// Yellow
	{0xFF, 0xFF, 0xFF}	// White
};

int	color;
int p[2];

/*  graphics.h */
void setcolor(int _color)
{
	Color =_color;
}

void moveto(int _x, int _y)
{
	p[0] =_x;	p[1] =_y;
}

#ifndef RGB
#define RGB(r,g,b)	((r<<0)|(g<<8)|(b<<16))
#endif

void lineto(int _x, int _y)
{
	uint32_t Colour;
	
	Colour = RGB(Palette[Color][2], Palette[Color][1], Palette[Color][0]);	// to 32-bit depth color
	Line(p[0],p[1],_x,_y,Colour,FrameBuffer);
	p[0] =_x;	p[1] =_y;	// moveto()
}


void Init()
{
	int	i;
	//randomize ();
	srand( (unsigned int)time( NULL ) );


	for ( i = 0; i < NUM_CONTROLPTS; i ++ )
		initcontrol ( &vertices[i], &deltas[i] );

	color = Random ( 15 ) + 1;	
}

void Demo()
{
		int	i;
		
		//delay ( 80 );

		if (  Random(100) == 0 )
			color = Random ( 15 ) + 1;

		for ( i = 0; i < NUM_CONTROLPTS; i ++ )
			advancecontrol ( &vertices[i], &deltas[i] );

		for ( i = 0; i < NUM_CONTROLPTS; i ++ )
		{
			setcolor ( 0 );
			drawcurve (	&queue[Index][i],
							&queue[Index][( i + 1 ) % NUM_CONTROLPTS],
							&queue[Index][( i + 2 ) % NUM_CONTROLPTS],
							&queue[Index][( i + 3 ) % NUM_CONTROLPTS] );
		}

		for ( i = 0; i < NUM_CONTROLPTS; i ++ )
		{
			setcolor ( color );
			drawcurve (	&vertices[i],
							&vertices[( i + 1 ) % NUM_CONTROLPTS],
							&vertices[( i + 2 ) % NUM_CONTROLPTS],
							&vertices[( i + 3 ) % NUM_CONTROLPTS] );

			queue[Index][i] = vertices[i];
		}

		Index = ( Index + 1 ) % QUEUE_SIZE;

}

#if 0
void main ( void )
{
	int	gdriver = 9, gmode = 2, errorcode;
	int	i, color;

	printf ( "Mystify  -  B-Spline Screen Saver\n" );
	printf ( "coded by plash  [ bhouston@shl.com ]  %s %s\n", __DATE__, __TIME__ );
	delay ( 2000 );
	clrscr ();
	delay ( 100 );

	// enter vga 640x480 16 color mode (params: 9,2)
	initgraph( &gdriver, &gmode, "");
	errorcode = graphresult();
	if ( errorcode != grOk )
	{
		printf ( "\n" );
		printf ( "Graphics error : %s\n", grapherrormsg ( errorcode ) );
		printf ( "Press any key to quit..." );
		getch ();
		exit ( 1 );
	}

	randomize ();

	for ( i = 0; i < NUM_CONTROLPTS; i ++ )
		initcontrol ( &vertices[i], &deltas[i] );

	color = random ( 15 ) + 1;

	while ( ! kbhit () )
	{
		delay ( 80 );

		if ( random ( 100 ) == 0 )
			color = random ( 15 ) + 1;

		for ( i = 0; i < NUM_CONTROLPTS; i ++ )
			advancecontrol ( &vertices[i], &deltas[i] );

		for ( i = 0; i < NUM_CONTROLPTS; i ++ )
		{
			setcolor ( 0 );
			drawcurve (	&queue[index][i],
							&queue[index][( i + 1 ) % NUM_CONTROLPTS],
							&queue[index][( i + 2 ) % NUM_CONTROLPTS],
							&queue[index][( i + 3 ) % NUM_CONTROLPTS] );
		}

		for ( i = 0; i < NUM_CONTROLPTS; i ++ )
		{
			setcolor ( color );
			drawcurve (	&vertices[i],
							&vertices[( i + 1 ) % NUM_CONTROLPTS],
							&vertices[( i + 2 ) % NUM_CONTROLPTS],
							&vertices[( i + 3 ) % NUM_CONTROLPTS] );

			queue[index][i] = vertices[i];
		}

		index = ( index + 1 ) % QUEUE_SIZE;
	}

	// clean up
	getch ();
	clearviewport ();
	delay ( 100 );
	closegraph ();
	delay ( 200 );
}
#endif

void	initcontrol ( POINT2 *vertex, POINT2 *delta )
{
	vertex->x = Random ( MAX_SCREEN_X - 20 ) + 10;
	vertex->y = Random ( MAX_SCREEN_Y - 20 ) + 10;

	delta->x = Random ( MAX_DELTA ) + 1;
	delta->y = Random ( MAX_DELTA ) + 1;
}

void	advancecontrol ( POINT2 *vertex, POINT2 *delta )
{
	float	x, y;

	x = vertex->x + delta->x;
	y = vertex->y + delta->y;

	if ( x < 0 )
		delta->x = ( Random ( MAX_DELTA ) + 1 );
	if ( x >= MAX_SCREEN_X )
		delta->x = -( Random ( MAX_DELTA ) + 1 );

	if ( y < 0 )
		delta->y = ( Random ( MAX_DELTA ) + 1 );
	if ( y >= MAX_SCREEN_Y )
		delta->y = -( Random ( MAX_DELTA ) + 1 );

	vertex->x += delta->x;
	vertex->y += delta->y;
}

void	drawcurve ( POINT2 *a, POINT2 *b, POINT2 *c, POINT2 *d )
{
	float i, controlpts[4][2], pt[2], coeffvector[4];

	controlpts[0][0] = a->x;
	controlpts[0][1] = a->y;
	controlpts[1][0] = b->x;
	controlpts[1][1] = b->y;
	controlpts[2][0] = c->x;
	controlpts[2][1] = c->y;
	controlpts[3][0] = d->x;
	controlpts[3][1] = d->y;

	getbsplinept_2 ( 0, controlpts, pt );
	moveto ( pt[0], pt[1] );

	for ( i = 1; i <= 20; i ++ )
	{
		getcoeffvector ( i * 0.05, bsplinebais, coeffvector );
		getweightedpt_2 ( coeffvector, controlpts, pt );
		lineto ( pt[0], pt[1] );
	}
}
