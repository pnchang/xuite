# MinGW TinyPTC  SDL 
#export SDLDIR='/D/DEMOS/SDL/SDL-devel-1.2.15-mingw32/SDL-1.2.15/'
export PTCDIR='TinyPTC/'
# NASM v2.08.02 
nasm -o "$PTCDIR""mmx.obj" -f win32  "$PTCDIR""mmx.asm"
gcc -fno-exceptions -static -D"MINGW"  -I"$PTCDIR" -I"$SDLDIR""Include" -L"$SDLDIR""lib" -o CGG.exe  CG.C AZRMATH.CPP  "$PTCDIR"convert.c "$PTCDIR"ddraw.c "$PTCDIR"mmx.obj "$PTCDIR"tinyptc.c  -lstdc++ -mwindows 