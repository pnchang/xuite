/*

*/

#define	_USE_MATH_DEFINES

#include <math.h>
#include <stdio.h>	// stderr
#include <stdbool.h>	// bool
#include <stdint.h>	// Standard Integer Types


#ifdef SDL
#include <SDL.h>
#else
#include <windows.h>
#ifdef __cplusplus 
extern "C" {
#endif 
#include "tinyptc.h"
#ifdef __cplusplus 
}
#endif
#endif	

#define	FWIDTH		800
#define	FHEIGHT		600
#ifdef __GNUC__

#else 
typedef uint8_t	bool;	// for c language
#endif

#ifdef SDL
SDL_Window *sdlWindow;	// SDL2
SDL_Surface *sdlscreen;
int g_rgb;

//	Prototype
void sdl_update(uint32_t *FrameBuffer);

#endif

uint8_t	BackBuffer[FWIDTH * FHEIGHT];	// 8-bit depth frame buffer	
uint32_t	FrameBuffer[FWIDTH * FHEIGHT];	// 32-bit depth frame buffer 
char pal[512*3];        //Use 512 colours 4 the palette (only 256 visible at a time)

#ifndef M_PI
#define  M_PI   3.14159265358979323846 /* pi */ 
#endif
#define CLIENT_WIDTH    FWIDTH
#define CLIENT_HEIGHT   FHEIGHT

#include "mystify.cpp"

int Xoff, Yoff, Zoff;

char progName[]="Bezier Curve Demo 1997 - Ben Houston";
char SINTAB[256];
uint32_t	nTicks;
int sub;
int idx;
int	bEntryFlag = 1;


void demomain(void)
{
#ifdef SDL	
	SDL_Event event;
#endif	

	static bool Quitting = false;
int16_t i;

Init();

i=0;
do
{
//		
//	memset(FrameBuffer,0x00,sizeof(FrameBuffer));
	Demo();	//
		// Copy to the display
//		memcpy(FrameBuffer, BackBuffer, sizeof(BackBuffer));

#ifdef SDL
sdl_update(FrameBuffer);
#else
ptc_update(FrameBuffer);
#endif
	
	i++;
	i=i%512;
	/* notice that colour 0 is not rotated, that is because I don't */
	/* want the backgroundcolor to change */
	
#ifdef SDL
		//update SDL events
		while (SDL_PollEvent(&event)) 
		{
			switch (event.type) 
			{
			case SDL_KEYDOWN:
				break;
			case SDL_KEYUP:
				// If escape is pressed, return (and thus, quit)
				if (event.key.keysym.sym == SDLK_ESCAPE)
					Quitting = true;
				break;
			case SDL_QUIT:
				Quitting = true;
			}
		}
#endif
}while(!Quitting);       


}

#ifdef SDL

void sdl_update(uint32_t *FrameBuffer)
{
	int x, y;
	int yofs, ofs;
	uint32_t *pdst;
	uint32_t colour;
    char *psrcc;
	
  // Lock surface if needed
  if (SDL_MUSTLOCK(sdlscreen)) 
	  if (SDL_LockSurface(sdlscreen) < 0) 
		  return;
  // Draw to screen
  yofs = 0;
  for (y = 0; y < FHEIGHT; y++) {
	  for (x = 0, ofs = yofs; x < FWIDTH; x++, ofs++) {
            pdst = &((uint32_t*)sdlscreen->pixels)[ofs];
			psrcc = (char *) &FrameBuffer[y*FWIDTH+x];
			colour = SDL_MapRGB( sdlscreen->format, psrcc[2], psrcc[1], psrcc[0] );
			*pdst = colour;			

	  }
	  yofs += sdlscreen->pitch / 4;
  }

  // Unlock if needed
  if (SDL_MUSTLOCK(sdlscreen)) 
	  SDL_UnlockSurface(sdlscreen);

  // Tell SDL to update the whole screen
  //SDL_UpdateRect(sdlscreen, 0, 0, 640, 480);	SDL
  SDL_UpdateWindowSurface(sdlWindow);	// SDL2
}

int main(int argc, char *argv[]) {

	SDL_Event event;
	unsigned int sdl_flags = SDL_SWSURFACE;
	//const SDL_VideoInfo *videoInfo;

	g_rgb = 0;

	if(SDL_Init(SDL_INIT_VIDEO) < 0) {
		fprintf(stderr, "Video initialization failed: %s\n",
			SDL_GetError());
		return 0;
	}

	if (argc>1) {
		sdl_flags |= SDL_WINDOW_FULLSCREEN;
		if (argv[1][0]=='r')
			g_rgb = 1;
	} else {
		//printf("options: f - fullscreen, bgr/rgb - color mapping.\n")
	}
	// Attempt to create a 640x480 window with 32bit pixels.
//	screen = SDL_SetVideoMode(640, 480, 32, sdl_flags);	// SDL
// Window mode 
    sdlWindow = SDL_CreateWindow(progName,
                          SDL_WINDOWPOS_UNDEFINED,
                          SDL_WINDOWPOS_UNDEFINED,
                          FWIDTH, FHEIGHT,
						  sdl_flags);
//Get window surface
	sdlscreen = SDL_GetWindowSurface( sdlWindow );

	// If we fail, return error.
	if ( sdlscreen == NULL ) {
		fprintf(stderr, "Unable to set %4dx%4d video: %s\n", FWIDTH, FHEIGHT, SDL_GetError());
		return 0;
	}
    demomain();

	//Free Surface
	if (sdlscreen)	SDL_FreeSurface(sdlscreen);
	//Destroy window
	if (sdlWindow)	SDL_DestroyWindow( sdlWindow );	
	//Quit SDL subsystems
    SDL_Quit();	

  return 0;
}

#else

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
  int ret = ptc_open(progName, FWIDTH, FHEIGHT);
  if (!ret) {
	MessageBox(0,"failed to init ptc","error",MB_OK);
	return 0;
  }
    demomain( );  

  return 0;
}

#endif
