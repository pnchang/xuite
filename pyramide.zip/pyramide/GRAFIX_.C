/***************************************************/
/* Written by Alexei A. Frounze on 12 of jan  1999 */
/*                                                 */
/* Compiler: DJGPP                                 */
/*                                                 */
/* E-mail: alexfru@chat.ru                         */
/* Homepage: http://www.chat.ru/~alexfru           */
/*           http://members.xoom.com/alexfru       */
/***************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <dos.h>

#include <dpmi.h>
#include <go32.h>
#include <sys/movedata.h>
#include "grafix.h"

char *VGAAddr = NULL;
unsigned short VGA_sel = 0;

void initgraph() {
  union REGS r;

  r.x.ax = 0x13;
  int86(0x10, &r, &r);
}

void closegraph() {
  union REGS r;

  r.x.ax = 3;
  int86(0x10, &r, &r);
}

void clearscreen (char color) {
  if (VGAAddr)
    memset (VGAAddr, color, Screen_Height*Screen_Width);
  else {
    __asm__ __volatile__ ("
      pushw   %%es
      movw    %1, %%ax
      movw    %%ax, %%es
      xorl    %%edi, %%edi
      movl    %2, %%ecx
      movb    %0, %%al
      cld
      rep
      stosb
      popw    %%es"
      :
      : "g" (color), "g" (VGA_sel), "g" (Screen_Height*Screen_Width)
      : "eax", "ecx", "edi"
    );
  };
}

void border (char color) {
  union REGS r;

  r.x.ax = 0x1001;
  r.h.bh = color;
  int86(0x10, &r, &r);
}

void putpixel (long x, long y, char color) {
  if (VGAAddr)
    *(VGAAddr+x+y2addr(y)) = color;
  else {
    __asm__ __volatile__ ("
      pushw   %%es
      movw    %3, %%ax
      movw    %%ax, %%es
      movl    %1, %%edi
      shl     $6, %%edi
      movl    %%edi, %%eax
      shl     $2, %%eax
      addl    %%eax, %%edi
      addl    %0, %%edi
      movb    %2, %%al
      stosb
      popw    %%es"
      :
      : "g" (x), "g" (y), "g" (color), "g" (VGA_sel)
      : "eax", "edi"
    );
  };
}

char getpixel (long x, long y) {
  char color;

  if (VGAAddr)
    color = *(VGAAddr+x+y2addr(y));
  else {
    __asm__ __volatile__ ("
      pushw   %%es
      movw    %3, %%ax
      movw    %%ax, %%es
      movl    %2, %%edi
      shl     $6, %%edi
      movl    %%edi, %%eax
      shl     $2, %%eax
      addl    %%eax, %%edi
      addl    %1, %%edi
      movb    %%es:(%%edi), %%al
      movb    %%al, %0
      popw    %%es"
      : "=g" (color)
      : "g" (x), "g" (y), "g" (VGA_sel)
      : "eax", "ecx", "edi"
    );
  };

  return color;
}

void lineh (long x, long y, long l, char color) {
  if (VGAAddr)
    memset (VGAAddr+x+y2addr(y), color, l);
  else {
    __asm__ __volatile__ ("
      pushw   %%es
      movw    %3, %%ax
      movw    %%ax, %%es
      movl    %1, %%edi
      shl     $6, %%edi
      movl    %%edi, %%eax
      shl     $2, %%eax
      addl    %%eax, %%edi
      addl    %0, %%edi
      movb    %2, %%al
      mov     %4, %%ecx
      rep
      stosb
      popw    %%es"
      :
      : "g" (x), "g" (y), "g" (color), "g" (VGA_sel), "g" (l)
      : "eax", "ecx", "edi"
    );
  };
}

void linev (long x, long y, long h, char color) {
  char *addr;

  if (VGAAddr) {
    addr = VGAAddr + x + y2addr(y);
    while (h--) {
      *addr = color;
      addr += Screen_Width;
    }
  }
  else {
    __asm__ __volatile__ ("
      pushw   %%es
      movw    %3, %%ax
      movw    %%ax, %%es
      movl    %1, %%edi
      shl     $6, %%edi
      movl    %%edi, %%eax
      shl     $2, %%eax
      addl    %%eax, %%edi
      addl    %0, %%edi
      movb    %2, %%al
      mov     %4, %%ecx
0:
      mov     %%al, %%es:(%%edi)
      add     $320, %%edi
      loop    0b
      popw    %%es"
      :
      : "g" (x), "g" (y), "g" (color), "g" (VGA_sel), "g" (h)
      : "eax", "ecx", "edi"
    );
  };
}

void box (long x, long y, long l, long h, char color, int fill_flag) {
  if (fill_flag) {
    while (h--)
      lineh (x, y++, l, color);
  } else {
    lineh (x, y, l, color);
    linev (x+l-1, y, h, color);
    lineh (x, y+h-1, l, color);
    linev (x, y, h, color);
  };
}

void line (long x1, long y1, long x2, long y2, char color) {
  int sx, sy, dx1, dy1, dx2, dy2, x, y, m, n, k=0, cnt;

  sx = x2-x1;
  sy = y2-y1;

  if (sx > 0) dx1 = 1;
  else if (sx < 0) dx1 = -1;
  else dy1 = 0;

  if (sy > 0) dy1 = 1;
  else if (sy < 0) dy1 = -1;
  else dy1 = 0;

  m = abs (sx);
  n = abs (sy);

  dx2 = dx1;
  dy2 = 0;

  if (m < n) {
    m = abs (sy);
    n = abs (sx);
    dx2 = 0;
    dy2 = dy1;
  };

  x = x1; y = y1;
  cnt = m+1;
  while (cnt--) {
    putpixel (x, y, color);
    k += n;
    if (k < m) {
      x += dx2;
      y += dy2;
    }
    else {
      k -= m;
      x += dx1;
      y += dy1;
    };
  };
}

void *loadPCX256 (char *name, long *l, long *h, char *pal) {
  PCXHeader Hd;
  FILE *f;
  int sz, size, i, cnt;
  char *buf;
  char *tmp1, *tmp2;
  void *result;
  char rep, repb;

  *l=*h=0;
  buf=result=NULL;
  if ((f = fopen (name, "rb")) == NULL) {
lerr:
    if (buf) free (buf);
    if (result) free (result);
    return NULL;
  };
  if (fread(&Hd,1,sizeof(Hd),f)!=sizeof(Hd)) goto lerr;
  if ((Hd.BitsPerPixel != 8) || (Hd.Planes != 1)) goto lerr;
  *l = Hd.X2 - Hd.X1 + 1;
  *h = Hd.Y2 - Hd.Y1 + 1;
  size = (*l)*(*h);
  result = (void *) malloc (size);
  if (fseek(f,-768L,SEEK_END)!=0) goto lerr;
  if (fread(pal,1,768,f)!=768) goto lerr;
  sz = ftell(f)-768-sizeof(Hd)-1;
  buf = (char *) malloc (sz);
  if (fseek(f,sizeof(Hd),SEEK_SET)) goto lerr;
  if (fread(buf,1,sz,f)!=sz) goto lerr;
  fclose (f);
  for (i=0;i<768;i++)
    pal[i]>>=2;
  tmp1 = result;
  tmp2 = buf;
  for (i=0;i<*h;i++) {
    cnt=0;
cycle:
    if (((rep=repb=*tmp2++) & 0xC0) == 0xC0) {
      rep&=0x3F;
      repb=*tmp2++;
      while (rep--)
        if (cnt++<*l) *tmp1++=repb;
    } else {
      if (cnt++<*l) *tmp1++=repb;
    };
    if (cnt<Hd.BytesPerLine) goto cycle;
  };

  free (buf);
  return result;
}

void getCRGB (char C, char *R, char *G, char *B) {
  outp (0x3C7, C);
  *R = inp (0x3C9);
  *G = inp (0x3C9);
  *B = inp (0x3C9);
}

void setCRGB (char C, char R, char G, char B) {
  outp (0x3C8, C);
  outp (0x3C9, R);
  outp (0x3C9, G);
  outp (0x3C9, B);
}

void getpal (void *pal) {
  int c;
  char *p=pal;

  for (c=0;c<256;c++) {
    outp (0x3C7, c);
    *p++=inp (0x3C9);
    *p++=inp (0x3C9);
    *p++=inp (0x3C9);
  };
}

void setpal (void *pal) {
  int c;
  char *p=pal;

  for (c=0;c<256;c++) {
    outp (0x3C8, c);
    outp (0x3C9, *p++);
    outp (0x3C9, *p++);
    outp (0x3C9, *p++);
  };
}

void wait_vr() {
  while (inp(0x3DA) & 8) {};
  while (!(inp(0x3DA) & 8)) {};
}

void flip() {
  if (VGAAddr)
    dosmemput (VGAAddr, Screen_Width*Screen_Height, 0xA0000);
}

