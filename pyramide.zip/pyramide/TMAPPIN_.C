/***************************************************/
/* Written by Alexei A. Frounze on                 */
/*                  12 of jan  1999 ... 5 mar 2000 */
/*                                                 */
/* Compiler: DJGPP 2.95.2                          */
/*                                                 */
/* E-mail  : alexfru@chat.ru                       */
/* Homepage: http://www.chat.ru/~alexfru           */
/*           http://members.xoom.com/alexfru       */
/***************************************************/

// See Mark Feldman's article about texture mapping:
// "http://www.geocities.com/SiliconValley/2151"
// and Mikael Kalms' article about texture mapping:
// "http://www.lysator.liu.se/~mikaelk/doc/perspectivetexture/"

#include <math.h>

#include "tmapping.h"
#include "vectors.h"
#include "grafix.h"

extern void span (char *scr, char *txt, int n,
                  int *u, int *v, int du, int dv);

#define SUB_BITS        4
#define SUB_CNT         (1 << SUB_BITS)
#define FP_BITS         12

                        /* ORIGINAL POLYGON DATA */

// Number of polygon vertices
int     VCNT;
// Verices of a polygon in a 3d space
Vector  Vertices[Max_Edges+1];
// Appropriate u and v values
double  tu[Max_Edges+1], tv[Max_Edges+1];

                        /* TEMPORARY POLYGON DATA */

// Number of Vertices at the screen
int     _VCNT;
// Clipped polygon Vertices
Vector  _Vertices[Max_Edges+1];
// Appropriate u and v values
double  _tu[Max_Edges+1], _tv[Max_Edges+1];
// Screen verices of a polygon
double  XR[Max_Edges+1], YR[Max_Edges+1];
// Buffers for projecting a polygon. Left & right screen boundaries:
int     Scan_Buf_L[Screen_Height], Scan_Buf_R[Screen_Height];
double  inv_z_L[Screen_Height], u_div_z_L[Screen_Height], v_div_z_L[Screen_Height];
double  inv_z_R[Screen_Height], u_div_z_R[Screen_Height], v_div_z_R[Screen_Height];
double  Scan_Buf_L2[Screen_Height], Scan_Buf_R2[Screen_Height];

                        /* OTHER VARIABLES */

// Minimal & maximal screen X and Y (integer) of a polygon:
int     YminI, YmaxI, XminI, XmaxI;

// Boolean array for tmapper. It is used to clip polygons with
// Z=ZClose plain
int Behind[Max_Edges+1];

// Linear interpolation choosing (0=none,1=16pxls)
int SubDiv=1;

                        /* FUNCTIONS */


// This one finds screen min & max X for each Y of polgon's edge
void Scan_Edge (int N) {
  double X, DX;
  int IsLeftEdge;
  double X1R, Y1R, X2R, Y2R;
  int Y1I, Y2I, XI, YI;

  double iz1, iz2, uz1, uz2, vz1, vz2;
  double iz, uz, vz, diz, duz, dvz;
  double ddd;
  int M;

  M = (N+1)%_VCNT;

  X1R = XR[N]; Y1R = YR[N];
  iz1 = (double)1/_Vertices[N].Z;
  uz1 = _tu[N] * iz1;
  vz1 = _tv[N] * iz1;

  X2R = XR[M]; Y2R = YR[M];
  iz2 = (double)1/_Vertices[M].Z;
  uz2 = _tu[M] * iz2;
  vz2 = _tv[M] * iz2;

  IsLeftEdge = Y2R < Y1R;

  ddd = Y1R - Y2R;
  DX  = (X1R - X2R) / ddd;
  diz = (iz1 - iz2) / ddd;
  duz = (uz1 - uz2) / ddd;
  dvz = (vz1 - vz2) / ddd;

  if (IsLeftEdge) {
    Y2I = ceil(Y2R); Y1I = ceil(Y1R)-1;
    if (Y2I > Y1I) return;
    ddd = Y2I - Y2R;
    X  = X2R + ddd * DX;
    iz = iz2 + ddd * diz;
    uz = uz2 + ddd * duz;
    vz = vz2 + ddd * dvz;
    YI = Y1I; Y1I = Y2I; Y2I = YI;
  } else {
    Y1I = ceil(Y1R); Y2I = ceil(Y2R)-1;
    if (Y1I > Y2I) return;
    ddd = Y1I - Y1R;
    X  = X1R + ddd * DX;
    iz = iz1 + ddd * diz;
    uz = uz1 + ddd * duz;
    vz = vz1 + ddd * dvz;
  };

  if (Y1I < 0) {
    X  -= Y1I*DX;
    iz -= Y1I*diz;
    uz -= Y1I*duz;
    vz -= Y1I*dvz;
    Y1I = 0;
  };
  if (Y2I > Screen_Height-1)
    Y2I = Screen_Height-1;

  if (IsLeftEdge)
    for (YI=Y1I;YI<=Y2I;YI++) {
      Scan_Buf_L2[YI] = X;
      XI = ceil(X);
      Scan_Buf_L[YI] = XI;
      X += DX;
      inv_z_L[YI] = iz;
      iz += diz;
      u_div_z_L[YI] = uz;
      uz += duz;
      v_div_z_L[YI] = vz;
      vz += dvz;
    }
   else
    for (YI=Y1I;YI<=Y2I;YI++) {
      Scan_Buf_R2[YI] = X;
      XI = ceil(X)-1;
      Scan_Buf_R[YI] = XI;
      X += DX;
      inv_z_R[YI] = iz;
      iz += diz;
      u_div_z_R[YI] = uz;
      uz += duz;
      v_div_z_R[YI] = vz;
      vz += dvz;
    };
}

/**********************************/
/* MAIN TEXTURE MAPPING FUNCTIONS */
/**********************************/

// Maps a texture onto an arbitrary polygon
void T_Map (char *texture) {
  double NX, NY, IZ;
  int IndexMin, IndexMax, IndexMinX, IndexMaxX, i, j, k;
  int xl, xr;
  double uz, vz, duz, dvz;
  double iz, diz;
  int u, v;
  int zzz;
  char *scr;
  double iiz;
  int u1, v1, u2, v2, du, dv, n;
  int tmp1, tmp2;
  int sub_bits = SUB_BITS;
  int CONST = 1 << (SUB_BITS + FP_BITS);
  double sss;

  for(i=0;i<VCNT;i++)
    Behind[i] = (Vertices[i].Z < ZClose);

  _VCNT=0;
  for (i=0;i<VCNT;i++) {
    if (!Behind[i]) {
      XR[_VCNT] = Vertices[i].X / Vertices[i].Z;
      YR[_VCNT] = Vertices[i].Y / Vertices[i].Z;
      _Vertices[_VCNT] = Vertices[i];
      _tu[_VCNT] = tu[i];
      _tv[_VCNT] = tv[i];
      _VCNT++;
    };
    k = (i+1)%VCNT;
    if (Behind[i] != Behind[k]) {
      IZ = (ZClose-Vertices[i].Z) / (Vertices[k].Z-Vertices[i].Z);
      NX = Vertices[i].X + (Vertices[k].X-Vertices[i].X) * IZ;
      NY = Vertices[i].Y + (Vertices[k].Y-Vertices[i].Y) * IZ;
      XR[_VCNT] = NX / ZClose;
      YR[_VCNT] = NY / ZClose;
      _Vertices[_VCNT].X = NX;
      _Vertices[_VCNT].Y = NY;
      _Vertices[_VCNT].Z = ZClose;
      _tu[_VCNT] = tu[i] + (tu[k]-tu[i]) * IZ;
      _tv[_VCNT] = tv[i] + (tv[k]-tv[i]) * IZ;
      _VCNT++;
    };
  };

  if (_VCNT < 3) return;

  // Computing XR[] and YR[] screen TVertices for a polygon

  for (i=0;i<_VCNT;i++) {
    XR[i] *= KP; XR[i] += Center_X;
    YR[i] *= KP; YR[i] += Center_Y;
  };

  // Done. Computing minimal Y and maximal Y at screen for a polygon

  IndexMin = IndexMax = IndexMinX = IndexMaxX = 0;
  for (i=0;i<_VCNT;i++) {
    if (YR[i] < YR[IndexMin]) IndexMin = i;
    if (YR[i] > YR[IndexMax]) IndexMax = i;
    if (XR[i] < XR[IndexMinX]) IndexMinX = i;
    if (XR[i] > XR[IndexMaxX]) IndexMaxX = i;
  };

  // Getting integer values of min Y and max Y

  YminI = ceil(YR[IndexMin]);
  YmaxI = ceil(YR[IndexMax])-1;
  XminI = ceil(XR[IndexMinX]);
  XmaxI = ceil(XR[IndexMaxX])-1;

  // Is polygon visible at screen?

  if ((YminI > YmaxI) || (XminI > XmaxI)) return;
  tmp1 = 0;
  tmp2 = Screen_Height-1;

  if ((YminI > tmp2) || (YmaxI < tmp1) ||
     (XminI >= Screen_Width) ||
     (XmaxI < 0)) return;

  if (YminI < tmp1) YminI = tmp1;
  if (YmaxI > tmp2) YmaxI = tmp2;

  // It's visible. Finding left and right screen boundaries per each y-line.
  // It's done for all edges of a polygon

  for (i=0;i<_VCNT;i++)
    Scan_Edge (i);

  for (i=YminI;i<=YmaxI;i++) {
    xl=Scan_Buf_L[i];
    xr=Scan_Buf_R[i];
    if (xl > xr) continue;

    tmp1 = 0;
    tmp2 = Screen_Width-1;
    if ((xl > tmp2) || (xr < tmp1)) continue;

    iz = inv_z_L[i];
    uz = u_div_z_L[i];
    vz = v_div_z_L[i];
/*
    sss = Scan_Buf_R2[i]-Scan_Buf_L2[i];
    diz = (inv_z_R[i] - inv_z_L[i]) / sss;
    duz = (u_div_z_R[i] - u_div_z_L[i]) / sss;
    dvz = (v_div_z_R[i] - v_div_z_L[i]) / sss;
*/
    __asm__ __volatile__ ("
      fld1
      fldl  (%0)
      fsubl (%1)"
    :
    : "g" (&Scan_Buf_R2[i]), "g" (&Scan_Buf_L2[i])
    );
    __asm__ __volatile__ ("
      fdivrp
      fld     %%st
      fld     %%st
      fldl    (%0)
      fsubl   (%1)
      fmulp
      fstpl   (%2)"
    :
    : "g" (&inv_z_R[i]), "g" (&inv_z_L[i]), "g" (&diz)
    );
    __asm__ __volatile__ ("
      fldl    (%0)
      fsubl   (%1)
      fmulp
      fstpl   (%2)
      fldl    (%3)
      fsubl   (%4)
      fmulp
      fstpl   (%5)"
    :
    : "g" (&u_div_z_R[i]), "g" (&u_div_z_L[i]), "g" (&duz), "g" (&v_div_z_R[i]), "g" (&v_div_z_L[i]), "g" (&dvz)
    );
/*
    sss = xl - Scan_Buf_L2[i];
    iz += diz * sss;
    uz += duz * sss;
    vz += dvz * sss;
*/
    __asm__ __volatile__ ("
      fildl   (%0)
      fsubl   (%1)
      fld     %%st
      fld     %%st
    "
    :
    : "g" (&xl), "g" (&Scan_Buf_L2[i])
    );
    __asm__ __volatile__ ("
      fmull (%0)
      faddl (%1)
      fstpl (%1)
      fmull (%2)
      faddl (%3)
      fstpl (%3)
      fmull (%4)
      faddl (%5)
      fstpl (%5)
    "
    :
    : "g" (&diz), "g" (&iz), "g" (&duz), "g" (&uz), "g" (&dvz), "g" (&vz)
    );

    if (xl < tmp1) {
/*
      iz += diz*(tmp1-xl);
      uz += duz*(tmp1-xl);
      vz += dvz*(tmp1-xl);
*/
      __asm__ __volatile__ ("
        fildl   (%0)
        fisubl  (%1)
        fld     %%st
        fld     %%st"
      :
      : "g" (&tmp1), "g" (&xl)
      );

      __asm__ __volatile__ ("
        fmull   (%0)
        faddl   (%1)
        fstpl   (%1)
        fmull   (%2)
        faddl   (%3)
        fstpl   (%3)
        fmull   (%4)
        faddl   (%5)
        fstpl   (%5)"
      :
      : "g" (&diz), "g" (&iz), "g" (&duz), "g" (&uz), "g" (&dvz), "g" (&vz)
      );

      xl = tmp1;
    };
    if (xr > tmp2) xr = tmp2;

    zzz = xr-xl+1;
    scr = VGAAddr + xl + y2addr (i);

if (SubDiv) {
/*
    diz *= SUB_CNT;
    duz *= SUB_CNT;
    dvz *= SUB_CNT;
*/
    __asm__ __volatile__ ("
      fildl (%0)
      fldl  (%1)
      fscale
      fstpl (%1)
      fldl  (%2)
      fscale
      fstpl (%2)
      fldl  (%3)
      fscale
      fstpl (%3)
      fistpl (%0)"
    :
    : "g" (&sub_bits), "g" (&diz), "g" (&duz), "g" (&dvz)
    );
/*
    iiz = (1 << (SUB_BITS + FP_BITS)) / iz;
    u1 = (int)(uz * iiz);
    v1 = (int)(vz * iiz);
*/
    __asm__ __volatile__ ("
      fildl   (%0)
      fdivl   (%1)
      fld     %%st
      fmull   (%2)
      fistpl  (%4)
      fmull   (%3)
      fistpl  (%5)"
    :
    : "g" (&CONST), "g" (&iz), "g" (&uz), "g" (&vz), "g" (&u1), "g" (&v1)
    );
    iz += diz;
    uz += duz;
    vz += dvz;
/*
    iiz = (1 << (SUB_BITS + FP_BITS)) / iz;
    u2 = (int)(uz * iiz);
    v2 = (int)(vz * iiz);
*/
    __asm__ __volatile__ ("
      fildl   (%0)
      fdivl   (%1)
      fld     %%st
      fmull   (%2)
      fistpl  (%4)
      fmull   (%3)
      fistpl  (%5)"
    :
    : "g" (&CONST), "g" (&iz), "g" (&uz), "g" (&vz), "g" (&u2), "g" (&v2)
    );
    du = u2 - u1;
    dv = v2 - v1;
//  sar du, SUB_BITS
//  sar dv, SUB_BITS
    __asm__ __volatile__ ("
      sarl %2, (%0)
      sarl %2, (%1)"
      :
      : "g" (&du), "g" (&dv), "g" (SUB_BITS)
    );
    while (1) {
      n = SUB_CNT;
      zzz -= SUB_CNT;
      if (zzz<0) n+=zzz;

//      iz += diz;
//      iiz = (1 << (SUB_BITS + FP_BITS)) / iz;

      __asm__ __volatile__ ("
        fldl    (%1)
        faddl   (%2)
        fstl    (%1)
        fidivrl (%0)"
        :
        : "g" (&CONST), "g" (&iz), "g" (&diz)
      );

      span (scr, texture, n, &u1, &v1, du, dv);

      if (zzz<=0) {
        __asm__ __volatile__ ("
          fstpl (%0)"
          :
          : "g" (&iiz)
        );
        break;
      };

      scr += n;

      u1 = u2;
      v1 = v2;
//      iz += diz;
      uz += duz;
      vz += dvz;
/*
      iiz = (1 << (SUB_BITS + FP_BITS)) / iz;
      u2 = (int)(uz * iiz);
      v2 = (int)(vz * iiz);
*/
      __asm__ __volatile__ ("
        fld     %%st
        fmull   (%0)
        fistpl  (%2)
        fmull   (%1)
        fistpl  (%3)"
      :
      : "g" (&uz), "g" (&vz), "g" (&u2), "g" (&v2)
      );
      du = u2 - u1;
      dv = v2 - v1;
//    sar du, SUB_BITS
//    sar dv, SUB_BITS
      __asm__ __volatile__ ("
        sarl %2, (%0)
        sarl %2, (%1)"
        :
        : "g" (&du), "g" (&dv), "g" (SUB_BITS)
      );
    };
} else {
    while (zzz--) {
      u = ((int)(uz / iz))&255;
      v = ((int)(vz / iz))&255;
      *scr++ = *(texture+(v<<8)+u);
      iz += diz;
      uz += duz;
      vz += dvz;
    };
};
  };
}

