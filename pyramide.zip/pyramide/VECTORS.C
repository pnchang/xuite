/***************************************************/
/* Written by Alexei A. Frounze on 12 of jan  1999 */
/*                                                 */
/* Compiler: DJGPP                                 */
/*                                                 */
/* E-mail: alexfru@chat.ru                         */
/* Homepage: http://www.chat.ru/~alexfru           */
/*           http://members.xoom.com/alexfru       */
/***************************************************/

#include <math.h>

#include "vectors.h"

double SinTab[360], CosTab[360];

void Vector_Add (Vector *a, Vector *b, Vector *c) {
  c->X = a->X + b->X;
  c->Y = a->Y + b->Y;
  c->Z = a->Z + b->Z;
}

void Vector_Sub (Vector *a, Vector *b, Vector *c) {
  c->X = a->X - b->X;
  c->Y = a->Y - b->Y;
  c->Z = a->Z - b->Z;
}

double Vector_Length (Vector *a) {
  return sqrt (a->X*a->X + a->Y*a->Y + a->Z*a->Z);
}

void Vector_Unit (Vector *a) {
  double l;

  l = Vector_Length(a);
  a->X/=l;
  a->Y/=l;
  a->Z/=l;
}

double Dot_Product (Vector *a, Vector *b) {
  return a->X*b->X + a->Y*b->Y + a->Z*b->Z;
}

void Cross_Product (Vector *a, Vector *b, Vector *c) {
  c->X = a->Y*b->Z - a->Z*b->Y;
  c->Y = a->Z*b->X - a->X*b->Z;
  c->Z = a->X*b->Y - a->Y*b->X;
}

void Rotate_Vector_X (Vector *v, int angle) {
  Vector vv;

  vv.Y = v->Y*CosTab[angle] + v->Z*SinTab[angle];
  vv.Z = v->Z*CosTab[angle] - v->Y*SinTab[angle];
  vv.X = v->X;
  *v = vv;
}

void Rotate_Vector_Y (Vector *v, int angle) {
  Vector vv;

  vv.Z = v->Z*CosTab[angle] + v->X*SinTab[angle];
  vv.X = v->X*CosTab[angle] - v->Z*SinTab[angle];
  vv.Y = v->Y;
  *v = vv;
}

void Rotate_Vector_Z (Vector *v, int angle) {
  Vector vv;

  vv.X = v->X*CosTab[angle] + v->Y*SinTab[angle];
  vv.Y = v->Y*CosTab[angle] - v->X*SinTab[angle];
  vv.Z = v->Z;
  *v = vv;
}

void Build_Trig_Tables() {
  int i;
  double angle;

  for(i=0;i<360;i++) {
    angle = i*PI/180;
    CosTab[i] = cos(angle);
    SinTab[i] = sin(angle);
  };
}

