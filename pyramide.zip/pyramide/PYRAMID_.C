/***************************************************/
/* Written by Alexei A. Frounze on                 */
/*                  12 of jan  1999 ... 5 mar 2000 */
/*                                                 */
/* Compiler: DJGPP 2.95.2                          */
/*                                                 */
/* E-mail  : alexfru@chat.ru                       */
/* Homepage: http://www.chat.ru/~alexfru           */
/*           http://members.xoom.com/alexfru       */
/***************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <dos.h>
#include <time.h>

#include <dpmi.h>
#include <go32.h>
#include "grafix.h"
#include "tmapping.h"

#define A       50                      // pyramide side length

int main() {
  long l, h, i, j;                      // some integers
  char *pic, *p, *p2;                   // pointers for a teture
  char pal[768];                        // texture/screen palette

  double  distance = 30;                // distance to the pyramide

  int     facevert[4][3] = {            // vertex set for each face
                            {1,2,3},
                            {2,0,3},
                            {0,1,3},
                            {2,1,0}};
  Vector  overts[4] = {                 // original vertices
                          {   0,               0,A/sqrt(3)},
                          { A/2,               0,-A*sqrt(1.0/12.0)},
                          {-A/2,               0,-A*sqrt(1.0/12.0)},
                          {   0,-A*sqrt(2.0/3.0),0}};
  Vector  verts[4];                     // vertices for rotation
  Vector M, N, Normal;                  // vectors for face removal
  int v0, v1, v2;                       // vertice's numbers for a face
  int angle_x=0, angle_y=0, angle_z=0;  // rotation angles
  char c;                               // character from the keyboard
  int wait4retrace=0;                   // wait for vert. retrace flag

  time_t t1, t0;
  double elapsed;
  int frames=0;
  char *texture_base=NULL;
  char *texture_data=NULL;
  unsigned long QQQ;

  texture_base = (char *) malloc (2*65536);
  if (texture_base==NULL) return 0;
  QQQ = (long) texture_base;
  QQQ = (0x10000 - (QQQ & 0xFFFF)) & 0xFFFF;
  texture_data = texture_base + QQQ;

  for (j=0;j<=3;j++)
    overts[j].Y += A/4;                 // centrate

  if (!(pic = loadPCX256 ("texture.pcx", &l, &h, pal))) {// load texture bitmap
    free (texture_base);
    printf ("'texture.pcx' file not found or an error occured.\n");
    return 0;
  };
  if ((l!=256) || (h!=256)) {
    free (texture_base);
    free (pic);
    printf ("'texture.pcx' file must have size of 256x256.\n");
    return 0;
  };
  memcpy (texture_data, pic, 65536);
  free (pic);

  printf ("The Pyramide.\n\n");
  printf ("A demo of an universal perspective correct texturemapper.\n");
  printf ("by Alexei A. Frounze (c) 2000\n\n");
  printf ("  A    move pyramide farther\n");
  printf ("  Z    move pyramide closer\n");
  printf ("  O    switch optimizations (default on)\n");
  printf ("  V    switch vertical retrace waiting (default off)\n");
  printf ("SPACE  pause\n");
  printf (" ESC   quit\n\n");
  printf ("press any key to continue...\n"); getch();

  VGA_sel = __dpmi_segment_to_descriptor (0xA000);      // alloc descr/sel
  VGAAddr = (char *) malloc (320*200);                  // alloc video buffer
  initgraph();                                          // init gfx
  clearscreen (BLACK);                                  // :)

  setpal (pal);

  VCNT = 3;                     // 3 vertices per a face

  tu[0] = 128; tv[0] =   0;
  tu[1] = 256; tv[1] = 256;
  tu[2] =   0; tv[2] = 256;     // U and V for each vertex of a face

  Build_Trig_Tables();                          // initialize sin/cos tables

  time(&t0);
  do {
    clearscreen (BLACK);

    for (i=0;i<=3;i++) {                        // faces

      v0 = facevert[i][0];
      v1 = facevert[i][1];
      v2 = facevert[i][2];                      // vertices making up the face

      for (j=0;j<=3;j++)                        // new vertices = old vertices
        verts[j] = overts[j];

      for (j=0;j<=3;j++) {                      // pyramide rotation
        Rotate_Vector_X (&verts[j], angle_x);
        Rotate_Vector_Y (&verts[j], angle_y);
        Rotate_Vector_Z (&verts[j], angle_z);
      };

      Vector_Sub (&verts[v2], &verts[v0], &M);
      Vector_Sub (&verts[v2], &verts[v1], &N);
      Cross_Product (&M, &N, &Normal);          // finding a normal vector

      if (Normal.Z > 0) {                       // hidden face removal
        Vertices[0] = verts[v0];
        Vertices[1] = verts[v1];
        Vertices[2] = verts[v2];
        for (j=0;j<=3;j++)
          Vertices[j].Z += distance;
        T_Map (texture_data);
      };
    };
    if (wait4retrace) wait_vr();
    flip();                                     // flip a frame to the screen
    frames++;

    if (kbhit()) {
      c=getch();
      switch (c) {
        case 0x20:
          getch();                              // pause
        break;
        case 'a':
        case 'A':
          if (distance < 300)
            distance += 5;                      // move pyramide farther
        break;
        case 'z':
        case 'Z':
          if (distance > 30)
            distance -= 5;                      // move pyramide closer
        break;
        case 'o':
        case 'O':
          SubDiv = 1 - SubDiv;                  // optimization on/off
        break;
        case 'v':
        case 'V':
          wait4retrace = 1 - wait4retrace;      // wait for retrace on/off
        break;
      };
    } else c=0;

    angle_x = (angle_x + 1) % 360;
    angle_y = (angle_y + 3) % 360;
    angle_z = (angle_z + 5) % 360;              // increase angles

  } while (c!=0x1b);
  time(&t1);
  elapsed = difftime(t1, t0);
  while (kbhit()) getch();

  closegraph();
  free (VGAAddr);
  free (texture_base);

  printf ("FPS: %f\n", (double)frames/elapsed);
  printf ("The Pyramide.\n\n");
  printf ("A demo of an universal perspective correct texturemapper.\n");
  printf ("by Alexei A. Frounze (c) 2000\n\n");
  printf ("e-mail  : alexfru@chat.ru\n");
  printf ("homepage: http://alexfru.chat.ru\n");
  printf ("mirror  : http://members.xoom.com/alexfru\n");
  return 0;
}

