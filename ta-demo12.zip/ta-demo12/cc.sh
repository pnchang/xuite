gcc -no-pie `sdl-config --cflags` `pkg-config libpng --cflags` -O2 -s -o flubberg flubber_.cpp texture.cpp timer.cpp vga.cpp -lstdc++ -lm `sdl-config --libs` `pkg-config libpng --libs` 
