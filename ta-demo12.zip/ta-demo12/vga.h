/*
 *                          The Art Of
 *                      D E M O M A K I N G
 *
 *
 *                     by Alex J. Champandard
 *                          Base Sixteen
 *
 *                  Modified by Paulo Pinto (Moondevil)
 *                         for using with SDL
 *
 *
 *                http://www.flipcode.com/demomaking
 *
 *                This file is in the public domain.
 *                      Use at your own risk.
 */


#ifndef __VGA_H_
#define __VGA_H_

#define	FWIDTH		800	//640
#define	FHEIGHT		600	//480

// Forward declarations
struct SDL_Surface;

class VGA
{
   public:

// constructor
   VGA();
// destructor
   ~VGA();
// dumps temporary buffer to the screen
   void Update();
// draw a pixel in temporary buffer
   void PutPixel( int x, int y, unsigned c );
// set a color in the palette
   void SetColour( unsigned char i, unsigned char r, unsigned char g, unsigned char b );
// clear temp buf
   void Clear();
// lock the surface so that we can draw on it
   void Lock();
// release the surface
   void Unlock();
 // Gets the surface pixel data
   Uint8 *GetSurfaceData();
 // Copies a buffer of data to the screen
   void Blit(Uint8 *data, size_t len);
private:

// pointer to the video memory
   SDL_Surface *video_buffer;

};

#endif
