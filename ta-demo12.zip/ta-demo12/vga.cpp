/*
 *                          The Art Of
 *                      D E M O M A K I N G
 *
 *
 *                     by Alex J. Champandard
 *                          Base Sixteen
 *
 *                     Modified by Paulo Pinto (Moondevil)
 *                         for using with SDL
 *
 *
 *                http://www.flipcode.com/demomaking
 *
 *                This file is in the public domain.
 *                      Use at your own risk.
 */


#include <SDL.h>
#include <malloc.h>
#include <string.h>
#include <stdlib.h>
#include <iostream>
#include "vga.h"

using namespace std;

/*
 * initialize mode 320x200x8 and prepare the double buffering
 */
VGA::VGA()
{
  // Set 320x200x8 video mode
  video_buffer = SDL_SetVideoMode( FWIDTH, FHEIGHT, 8, SDL_SWSURFACE | SDL_DOUBLEBUF );
  if (video_buffer < 0) {
    cerr << "Error while initializing video mode: " << SDL_GetError () << endl;
    // This is a bit drastic but the caller isn't expecting an error
    exit(-1);
  }
};

/*
 * set a colour in the palette
 */
void VGA::SetColour( unsigned char i, unsigned char r, unsigned char g, unsigned char b )
{
  // Initialize the color structure
  SDL_Color colors;
  colors.r = r;
  colors.g = g;
  colors.b = b;

  // set the color
  SDL_SetPalette( video_buffer, SDL_LOGPAL|SDL_PHYSPAL, &colors, i, 1 );
};

/*
 * return to text mode, and clean up
 */
VGA::~VGA()
{
  // nothing to do
};

/*
 * flip the double buffer to the screen
 */
void VGA::Update()
{
// Tell SDL to change page
  SDL_Flip( video_buffer );
};

/*
 * draw a pixel in the temporary buffer
 */
void VGA::PutPixel( int x, int y, unsigned c )
{
// clipping: check if pixel is out of the screen
// remove this for extra speed, and if you are sure x and y are always valid
   if ((x<0) || (x>FWIDTH-1) || (y<0) || (y>FHEIGHT-1)) return;

// set the memory
   Uint8 *page_draw = (Uint8 *)video_buffer->pixels;
   page_draw[y*FWIDTH+x] = c;  // same as y*320+x, but slightly quicker
}

/*
 * clear the double buffer
 */
void VGA::Clear()
{
  SDL_FillRect( video_buffer, NULL, SDL_MapRGB( video_buffer->format, 0, 0, 0 ));
}

/*
 * Locks the buffer.
 * Don't forget to call afterwards.
 */
void VGA::Lock()
{ 

  if ( SDL_MUSTLOCK( video_buffer ) ) {
    if ( SDL_LockSurface( video_buffer ) < 0 ) {
      cerr << "Can't lock screen: " << SDL_GetError() << endl;
      return;
    }
  }
}

/*
 * Release the surface
 */
void VGA::Unlock()
{
  SDL_UnlockSurface( video_buffer );
}

/*
 * Gets the surface pixel data.
 * You should only call this between Lock()/Unlock() pairs
 */
Uint8 *VGA::GetSurfaceData()
{
  return (Uint8*) video_buffer->pixels;
}

/*
 * Copies the data to the video memory
 */
void VGA::Blit(Uint8 *data, size_t len)
{
  Lock();
  memcpy( video_buffer->pixels, data, len );
  Unlock();
}
