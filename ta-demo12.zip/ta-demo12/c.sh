# MinGW  SDL 
export SDLDIR='/D/DEMOS/SDL/SDL-devel-1.2.15-mingw32/SDL-1.2.15/'
export PNGDIR="PNG/"
export LDIR='/local/'
gcc -fno-exceptions -fpermissive -ffast-math -D"MINGW" -I"$SDLDIR""Include\SDL" -I"$LDIR""include" -L"$SDLDIR""lib" -L"$LDIR""lib" -o flubberG.exe  flubber.cpp texture.cpp timer.cpp vga.cpp  -lm -lmingw32 -lSDLmain -lSDL "$PNGDIR""lib\libpng.lib" "$PNGDIR""lib\zlib.lib"  -lstdc++ -mwindows  

