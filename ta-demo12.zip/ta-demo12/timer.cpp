/*
 *                          The Art Of
 *                      D E M O M A K I N G
 *
 *
 *                     by Alex J. Champandard
 *                          Base Sixteen
 *
 *                  Modified by Paulo Pinto (Moondevil)
 *                         for using with SDL
 *
 *
 *                http://www.flipcode.com/demomaking
 *
 *                This file is in the public domain.
 *                      Use at your own risk.
 */


#include <SDL.h>      // has the SDL_GetTicks() we need
#include "timer.h"


/*
 * constructor, in our case nothing needs to be done
 */
TIMER::TIMER()
{
   startTime = SDL_GetTicks();
};

/*
 * destructor, also nothing to do
 */
TIMER::~TIMER()
{
};

/*
 * hmm, this is pretty simple :)
 */
long long TIMER::getCount()
{
    return (SDL_GetTicks()-startTime) * 1000;
};

