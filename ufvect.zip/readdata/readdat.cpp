/*
for UltraForce Used
*/
#include <stdio.h>
#include <string.h>	/* strrchr() */
#include <memory.h>
#ifdef __GNUC__
#include <sys/types.h>
#include <sys/stat.h>	/* mkdir() */
#endif
#if defined(_MSC_VER)||defined(MINGW)
#include <direct.h> 	/* _mkdir() */
#endif

#ifndef	MAX_PATH
#define	MAX_PATH	256
#endif

#define	s8		char
#define	u8		unsigned char
#define	s16		short
#define	u16		unsigned short
#define s32		int
#define	u32		unsigned int
#define	s64		signed long int 

#define	byte	unsigned char
#define	ushort	unsigned short



FILE	*inFile, *outFile;
char	SrcFilename[MAX_PATH];
char	DstFilename[MAX_PATH];
long	nFileSize;
int	result;

// Limitation
#define	CODESIZE	8*1024*1024
#define	DATASIZE	8*1024*1024
#define	RAWSIZE		8*1024*1024

//	Read data from the file unreal
u32 DIRSize;
u8	Directory[512*512];
u8	DATABuf[DATASIZE];	// DATA
u8	CODEBuf[CODESIZE];	// CODE
u8	RAWBuf[RAWSIZE];	// Original Data 


#define	TGASIZE	1024*1024
u32	TGASize;
u32 TGAOffset;
u8	TGABuf[TGASIZE];	// PIX DATA

#ifndef MY_TGA

#define MY_TGA

#define TGA_INTERLACED(a)       ( (a) & 0xc0 )
#define TGA_FLIP(a)             ( ((a) & 0x20) ? 0 : 1)
#define TGA_MAPPED              1
#define TGA_RGB                 2
#define TGA_RLE_MAPPED          9
#define TGA_RLE_RGB             10

/*
 * Targa header.
 */
typedef struct {
        byte   num_id;
        byte   cmap_type;
        byte   image_type;
        ushort cmap_orign;
        ushort cmap_length;
        byte   cmap_entry_size;
        ushort xorig, yorig;
        ushort xsize, ysize;
        byte   pixel_size;
        byte   image_descriptor;
} tga_hdr;

#endif       /* MY_TGA */

/*
  Read Data From File
  Return:
     0: Pass
	xx: Fail
*/
s32 ReadFile(char *FileName, u32 FileOffset, u8 *DATBuf, u32 *DATSize)
{
	FILE	*hFile;
	u32 FileSize;
	u32	numRead;
	s32	result = -1;
	
	hFile = fopen( FileName, "rb");

	/* Open for read (will fail if file does not exist) */
	if( hFile == NULL )
	{
		printf( "The file %s was not opened\n", FileName);
	}
	else
	{
		FileSize = -1;	// Default Size
 
		result	= fseek(hFile, 0L, SEEK_END);	//	SEEK_END End of File
		if (result)
		{
			// Error Handle
		}
		else
		{
			FileSize = ftell(hFile);	// Get a Right File Size
			result = result|0x0001;
			if (FileSize<*DATSize)
			{
				// ERROR if Buffer Size is bigger than File Size
				*DATSize =  FileSize;	// Set a Right Data Size
			}
			
			
				result = fseek(hFile, FileOffset, SEEK_SET);	//	SEEK_SET Set Offset of File
				numRead = fread(DATBuf, 1, *DATSize, hFile);	
				result = fclose(hFile);
				// Pass 
				if (numRead==*DATSize)
				{
					result = 0;	// PASS
					
				}
				*DATSize = numRead;	// Set
			
		}
	}
	
	return	result;
}

// Write Data To File
s32 WriteFile(char *FileName, u8 * DATBuf, u32 DATSize)
{
	FILE	*hFile;
	u32	numWritten;
	s32	result=-1;


		hFile = fopen( FileName, "w+b");
		/* Open for write */
		if( hFile == NULL )
		{
			printf( "The file %s was not created\n", FileName);
		}
		else
		{
			numWritten = fwrite( DATBuf, sizeof( char ), DATSize, hFile);

			if (numWritten==DATSize)
				printf( " %10d bytes >>", DATSize);
			
			/* Close stream */
			result = fclose(hFile);
			if( result )
				printf( "The file %s was not closed\n", FileName);
		}

		return	result;
}

/*
; Compute next random number
; New := 8088405H * Old + 1
*/
u32 RandSeed;
u32 NextRand()
{
	RandSeed = 134775813*RandSeed + 1;
	return	RandSeed;
}

u16	RandInt(u16 Range)
{
	u32	Value;
	
	Value = NextRand();
	if (Range)
	{
		Value = (Value<<16)|(Value>>16);	// Swap Low Word  and High Word
		Value = Value%Range;
	}
	return	Value;
}

/*
Decode U4C Data   20 bytes Tag, 1 byte data type and n bytes codes
*/
s32 U4CDecode(u8 Type, u8 *Buf, s32 Size, u8 *DstBuf, u32 *DstSize)
{
	u32	Status;

	s32	i, j;
	u32	numRead, numWritten;
	u8 *Ptr;
	u32	Offset;
	u32 DstOffset;
	s16	Length;	// -127 and 0 to 127
	u8	Value;	
	u8	Bit;
	u8	EndFlag = 0;

	// Initialize
		Ptr = (u8*)(Buf);
		Offset = 0;
		DstOffset = 0;
//		printf("%04x, %04x\n ", Size, *(Ptr+1) );
		
	if (Type==0)
	{

		
		EndFlag = 1;	// true
		do 
		{
			Length= ((u16)(*Ptr)^RandInt(256));
			Length=Length-128;
			Ptr++;
			Offset = Offset +1;
			if (Length>=0)
			{
				Value = (*Ptr);
				Ptr++;
				Offset = Offset +1;
				Length = Length +1;
				memset(DstBuf+DstOffset, Value, Length);
				DstOffset = DstOffset+Length;
				
			}
			else if (Length==-127)
				{
					EndFlag = 0;	 // False				

				}
				else 
				{
					Length = -Length;
					memcpy(DstBuf+DstOffset, Ptr, Length);
					Ptr = Ptr + Length;
					Offset = Offset + Length;
					DstOffset = DstOffset + Length;
				}

		}while (EndFlag);
		
		*DstSize = DstOffset;	// Original Data Size
	}
	else
	{
		if (Type==1)
		{
			for(i=0;i<Size;i++)
			{
				Value = (*Ptr)^RandInt(256);
				Ptr++;
				Offset = Offset +1;
				*(DstBuf+DstOffset) = Value;
				DstOffset = DstOffset +1;
			}
			*DstSize = DstOffset;	// Original Data Size
		}
	}
		printf(" %2d  %08x :%06x %06x %06x \t", Type, Ptr-Buf, Size, Offset, DstOffset);
		
	return	0;
}

s32 BLDDecode(u8 *Buf, s32 Size)
{
	u32	Status;

	s32	i, j;
	u32	numRead, numWritten;
	u16 *Ptr;
	u8	Bit;
	
	
	Size=Size>>1;
	Size--;
	Ptr = (u16*)(Buf);
	printf("%04x, %04x\n ", Size, *(Ptr+1) );
	do 
	{
		Bit=Size&0x0f;	// 4-bit
		(*Ptr)=(((*Ptr)>>Bit)|(*Ptr)<<(16-Bit));
		Ptr++;
		Size--;
	}while (Size>=0);
	return	0;
}

u16 CheckSum(s8* String)
{
	s32	i;
	u16	sum;
	
	sum = 0;
	for(i=0;i<strlen(String);i++)
		sum=sum+String[i];
	
	return	sum;
}

/*

*/
s32 WriteTGA(s8 *PLTFilename, s8 *BLDFilename)
{	
	FILE	hFile;
	s8	Filename[128];
	u32	Status;

	s32	i, j;
	u32	numRead, numWritten;
	tga_hdr	tga;
	
	TGAOffset = 0;
	// Set TGA Header 
  /*
   * Bytes are in reverse order so ...
   */
	tga.num_id	= 0x00;
	tga.cmap_type	= 0x01;
	tga.image_type	= 0x01;
	tga.cmap_orign	= 0x0000;	// 2 bytes
	tga.cmap_length = 256;		// 2 bytes
	tga.cmap_entry_size = 24;	// 1 byte
	tga.xorig = 0x0000;
	tga.yorig = 0x0000;
	tga.xsize = 320;
	tga.ysize = 200;
	tga.pixel_size = 8;     /* we'll use it directly */
	tga.image_descriptor = 0x20;
	memcpy(TGABuf+TGAOffset, &tga, sizeof(tga));
	TGAOffset = TGAOffset+sizeof(tga);
  
	// Read Palette File .PLT
	strcpy(Filename,PLTFilename);
	strcat(Filename,".PLT");
	numRead = DATASIZE;	// Set Maximal Value
	Status = ReadFile(Filename, 0L, DATABuf, &numRead);	// Read DATA File
	
	if (Status==0)
	{
			u16 numColors;	// number of Colors
			u16 CIdx;	// Color Index
		// UFGOLD.PLT  fix up Palette
			numColors = 256;
			for(i=0;i<(numColors);i++)
			{
				DATABuf[i*3+1] = DATABuf[i*3+2]>>1; // Blue/2 to Green
				DATABuf[i*3+2] = DATABuf[i*3+0]>>1; // Red/2 to Blue
				DATABuf[i*3+0] = 0;	// 0 to Red
				//DATABuf[i] =  
			}
			
		// RGB to BGR 
		for(i=0;i<(numRead/3);i++)
		{
			u8	tmp;
			tmp = DATABuf[i*3+0];	// Red 
			DATABuf[i*3+0] = DATABuf[i*3+2];	// Blue 
			DATABuf[i*3+2] = tmp;	//  
		}

			
		memcpy(TGABuf+TGAOffset,DATABuf, numRead);
		TGAOffset = TGAOffset+numRead;
		
		// Read .BLD PIX File
		strcpy(Filename,BLDFilename);
		strcat(Filename,".BLD");
		numRead = DATASIZE;	// Set Maximal Value
		Status = ReadFile(Filename, 0L, DATABuf, &numRead);	// Read DATA File		
		if (Status==0)
		{
			// Have to decode data
			u32	TagSize = 66;
			numRead = numRead-TagSize;
			Status = BLDDecode(DATABuf+TagSize, numRead);
			if (Status==0)
			{
					memcpy(TGABuf+TGAOffset,DATABuf+TagSize, numRead);
					TGAOffset = TGAOffset+numRead;
					
					TGASize = TGAOffset;
					// Write .TGA File
					strcpy(Filename,BLDFilename);
					strcat(Filename,".TGA");
					WriteFile(Filename, TGABuf, TGASize);
			}
		}

	}
	return	0;
}

u32	SeedTable[9]={
0x0,	// 000
0x075673D3,	// 001
0x075673D3,	// 002
0x07567393,	// 003
0x0,	// 004
0x07567353,	// 005
0x07567453,	// 006
0x07567453,	// 007 
0x00CA414B	// X
};	

s32 LoadU4C(s8 *Filename, int SeedNo)
{

	u32	Status;

	s32	i, j;
	u32	numRead, numWritten;
	u32 Offset;
	u32	Size;
	u8	TagName[128];
	u8	TagSize;
	u32 CodeSize;
	u8	CodeType;
	u32 RAWSize;

	numRead = DATASIZE;
	Status = ReadFile( Filename, 0L, DATABuf, &numRead);	// Read CODE File
	if (Status==0)
	{
		Size = numRead;
		printf("%s %8d\t", Filename, Size);
		Offset = 0;
		TagSize = 20;		
		memcpy(TagName, DATABuf+Offset, TagSize);
		TagName[TagSize]='\0';
		Offset = Offset+TagSize;
		CodeType = DATABuf[Offset];	// CodeType
		Offset = Offset + 1;
		CodeSize = Size - Offset;
		RandSeed = SeedTable[SeedNo];
		printf("%s %d %6d %08x \t", TagName, CodeType ,CodeSize, RandSeed);
		Status = U4CDecode(CodeType, DATABuf+Offset, CodeSize, RAWBuf, &RAWSize);
		Offset = Offset + CodeSize;
		if (Status==0)
		{
			WriteFile( DstFilename, RAWBuf, RAWSize);
		}
	}
	
	return	0;
}



/* main program */
int main(int argc, char* argv[])
{
	FILE	*hFile;
	s8	BLDFilename[256];
	s8	Filename[128];
	s8	FileNo;
	s8  SeedNo;
	u32	Status;

	s32	i, j;
	u32	numRead, numWritten;
	u32	Sum;



	char	Str[]="UltraForce is a Dutch group that consists of 6 members;";
	


	if (argc==2)
	{
		sscanf(argv[1], "%d", &FileNo);	//FileNo = atoi(argv[1]);
		sprintf(Filename, "vect_%03d.u4c", FileNo);
		sprintf(DstFilename, "VECT_%03d.DAT", FileNo);
		SeedNo = FileNo;
	}
	else
	{
		printf("Syntax: %s U4CFILENO \n", argv[0]);
		return	-1;	
	}
/*
	RandSeed = 0x07567453;
	
	for(i=0;i<10;i++)
	{
		printf("%3d " , RandInt(256) );
	}
*/
	LoadU4C(Filename, SeedNo);
//	if (Status==0)	printf("%s  %8d\n", SrcFilename, numRead);
	
	
	return 0;
}

	
