# MinGW BGI Borland Graphics Interface v1.5
export OPENBGI_DIR='/D/DEMOS/OPENBGI/'
# Generate OpenBGI Object Files
#gcc -Wall -g -c -x c -I"${OPENBGI_DIR}library" "${OPENBGI_DIR}library/BGI.C"
#gcc -Wall -g -c -x c -I"${OPENBGI_DIR}library" "${OPENBGI_DIR}library/Client.c"
#gcc -Wall -g -c -x c -I"${OPENBGI_DIR}library" "${OPENBGI_DIR}library/graphics.c"
#gcc -Wall -g -c -x c -I"${OPENBGI_DIR}library" "${OPENBGI_DIR}library/IPC.C"
#gcc -Wall -g -c -x c -I"${OPENBGI_DIR}library" "${OPENBGI_DIR}library/Server.c"
# Generate Samples
gcc -Wall -g -c -I"./" "CAMERA.CPP" 
gcc -Wall -g -c -I"./" "MATRIX3D.CPP" 
gcc -Wall -g -c -I"${OPENBGI_DIR}library" "CUBE_.CPP" 

gcc -static -o CUBEG.exe CUBE_.o CAMERA.o MATRIX3D.o BGI.o IPC.o Client.o Server.o graphics.o  -lgdi32 -lwinmm -lstdc++

