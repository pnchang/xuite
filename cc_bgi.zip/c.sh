# MinGW BGI Borland Graphics Interface v1.5
export OPENBGI_DIR='/D/DEMOS/OPENBGI/'
# Generate OpenBGI Object Files
gcc -Wall -g -c -x c -I"${OPENBGI_DIR}library" "${OPENBGI_DIR}library/BGI.C"
gcc -Wall -g -c -x c -I"${OPENBGI_DIR}library" "${OPENBGI_DIR}library/Client.c"
gcc -Wall -g -c -x c -I"${OPENBGI_DIR}library" "${OPENBGI_DIR}library/graphics.c"
gcc -Wall -g -c -x c -I"${OPENBGI_DIR}library" "${OPENBGI_DIR}library/IPC.C"
gcc -Wall -g -c -x c -I"${OPENBGI_DIR}library" "${OPENBGI_DIR}library/Server.c"
# Generate Samples
gcc -Wall -g -c -I"./" "CAMERA.CPP" 
gcc -Wall -g -c -I"./" "MATRIX3D.CPP" 
gcc -Wall -g -c -I"${OPENBGI_DIR}library" "CUBE.CPP" 
gcc -Wall -g -c -I"${OPENBGI_DIR}library" "CUBE2.CPP" 
gcc -Wall -g -c -I"${OPENBGI_DIR}library" "CUBE3.CPP" 
gcc -Wall -g -c -I"${OPENBGI_DIR}library" "CUBE4.CPP" 
gcc -Wall -g -c -I"${OPENBGI_DIR}library" "CUBE5.CPP" 
gcc -Wall -g -c -I"${OPENBGI_DIR}library" "CUBE6.CPP" 

gcc -static -o CUBEG.exe CUBE.o CAMERA.o MATRIX3D.o BGI.o IPC.o Client.o Server.o graphics.o  -lgdi32 -lwinmm -lstdc++
gcc -static -o CUBE2G.exe CUBE2.o CAMERA.o MATRIX3D.o BGI.o IPC.o Client.o Server.o graphics.o  -lgdi32 -lwinmm -lstdc++
gcc -static -o CUBE3G.exe CUBE3.o CAMERA.o MATRIX3D.o BGI.o IPC.o Client.o Server.o graphics.o  -lgdi32 -lwinmm -lstdc++
gcc -static -o CUBE4G.exe CUBE4.o CAMERA.o MATRIX3D.o BGI.o IPC.o Client.o Server.o graphics.o  -lgdi32 -lwinmm -lstdc++
gcc -static -o CUBE5G.exe CUBE5.o CAMERA.o MATRIX3D.o BGI.o IPC.o Client.o Server.o graphics.o  -lgdi32 -lwinmm -lstdc++
gcc -static -o CUBE6G.exe CUBE6.o CAMERA.o MATRIX3D.o BGI.o IPC.o Client.o Server.o graphics.o  -lgdi32 -lwinmm -lstdc++
