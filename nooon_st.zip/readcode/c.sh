# MinGW  
#export DXDIR='/C/Program Files (x86)/Microsoft DirectX SDK (June 2010)/'
gcc -fpack-struct=1 -fexceptions -fpermissive -static -D"MINGW"  -o READDATG.exe READCOD.CPP -lstdc++  