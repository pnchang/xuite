/*
1995\n\nooon_st
nooon
*/
#include <stdio.h>
#include <string.h>	/* strrchr() */
#include <memory.h>
#ifdef __GNUC__
#include <sys/types.h>
#include <sys/stat.h>	/* mkdir() */
#endif
#if defined(_MSC_VER)||defined(MINGW)
#include <direct.h> 	/* _mkdir() */
#endif

#include "common.h"

#define	DBG		0x0000


#ifndef	MAX_PATH
#define	MAX_PATH	256
#endif

#define	s8		char
#define	u8		unsigned char
#define	s16		short
#define	u16		unsigned short
#define s32		int
#define	u32		unsigned int
#define	s64		signed long int 

//#define	byte	unsigned char
#define	ushort	unsigned short

#include "udiet.cc"

FILE	*inFile, *outFile;
char	SrcFilename[MAX_PATH];
char	DstFilename[MAX_PATH];
long	nFileSize;
int	result;

// Limitation
#define	CODESIZE	8*1024*1024
#define	DATASIZE	8*1024*1024
#define	RAWSIZE		8*1024*1024

//	Read data from the file unreal
u32 DIRSize;
u8	Directory[512*512];
u8	DATABuf[DATASIZE];	// DATA
u8	CODEBuf[CODESIZE];	// CODE 
u8	RAWBuf[RAWSIZE];	// Original Data 

#define	TGASIZE	1024*1024
u32	TGASize;
u32 TGAOffset;
u8	TGABuf[TGASIZE];	// PIX DATA
u8	Palette[256*3];

#ifndef MY_TGA

#define MY_TGA

#define TGA_INTERLACED(a)       ( (a) & 0xc0 )
#define TGA_FLIP(a)             ( ((a) & 0x20) ? 0 : 1)
#define TGA_MAPPED              1
#define TGA_RGB                 2
#define TGA_RLE_MAPPED          9
#define TGA_RLE_RGB             10

/*
 * Targa header.
 */
typedef struct {
        byte   num_id;
        byte   cmap_type;
        byte   image_type;
        ushort cmap_orign;
        ushort cmap_length;
        byte   cmap_entry_size;
        ushort xorig, yorig;
        ushort xsize, ysize;
        byte   pixel_size;
        byte   image_descriptor;
} tga_hdr;

#endif       /* MY_TGA */

/*
  Read Data From File
  Return:
     0: Pass
	xx: Fail
*/
s32 ReadFile(char *FileName, u32 FileOffset, u8 *DATBuf, u32 *DATSize)
{
	FILE	*hFile;
	u32 FileSize;
	u32	numRead;
	s32	result = -1;
	
	hFile = fopen( FileName, "rb");

	/* Open for read (will fail if file does not exist) */
	if( hFile == NULL )
	{
		printf( "The file %s was not opened\n", FileName);
	}
	else
	{
		FileSize = -1;	// Default Size
 
		result	= fseek(hFile, 0L, SEEK_END);	//	SEEK_END End of File
		if (result)
		{
			// Error Handle
		}
		else
		{
			FileSize = ftell(hFile);	// Get a Right File Size
			result = result|0x0001;
			if (FileSize<*DATSize)
			{
				// ERROR if Buffer Size is bigger than File Size
				*DATSize =  FileSize;	// Set a Right Data Size
			}
			
			
				result = fseek(hFile, FileOffset, SEEK_SET);	//	SEEK_SET Set Offset of File
				numRead = fread(DATBuf, 1, *DATSize, hFile);	
				result = fclose(hFile);
				// Pass 
				if (numRead==*DATSize)
				{
					result = 0;	// PASS
					
				}
				*DATSize = numRead;	// Set
			
		}
	}
	
	return	result;
}

// Write Data To File
s32 WriteFile(char *FileName, u8 * DATBuf, u32 DATSize)
{
	FILE	*hFile;
	u32	numWritten;
	s32	result=-1;


		hFile = fopen( FileName, "w+b");
		/* Open for write */
		if( hFile == NULL )
		{
			printf( "The file %s was not created\n", FileName);
		}
		else
		{
			numWritten = fwrite( DATBuf, sizeof( char ), DATSize, hFile);

			if (numWritten==DATSize)
				printf( " %10d bytes >>", DATSize);
			
			/* Close stream */
			result = fclose(hFile);
			if( result )
				printf( "The file %s was not closed\n", FileName);
		}

		return	result;
}

/*
Write TGA File
*/
s32 WriteTGAFile(char *FileName, u16 Width, u16 Height, u8 *Palette, u8 *DATBuf, u32 DATSize)
{
	tga_hdr	tga;
	u16	CI;	// Color Index 
	u16	numColors;	// number of Colors
	u32	Size;
	u32	TGAOffset;
	u8	TGAPalette[256*3];
	s32	i;
	
		// Initialize 	
		TGAOffset = 0;
		
	// Set TGA Header 
		
	/*
	* Bytes are in reverse order so ...
	*/
		tga.num_id	= 0x00;
		tga.cmap_type	= 0x01;
		tga.image_type	= 0x01;
		tga.cmap_orign	= 0x0000;	// 2 bytes
		tga.cmap_length = 256;		// 2 bytes
		tga.cmap_entry_size = 24;	// 1 byte
		tga.xorig = 0x0000;
		tga.yorig = 0x0000;
		tga.xsize = Width;
		tga.ysize = Height;
		tga.pixel_size = 8;     /* we'll use it directly */
		tga.image_descriptor = 0x20;
		memcpy(TGABuf+TGAOffset, &tga, sizeof(tga));
		TGAOffset = TGAOffset+sizeof(tga);
		
			// RGB to BGR 
			numColors = 256;	//
			for(i=0;i<(numColors);i++)
			{
				u8	tmp;
				tmp = *(Palette+i*3+0)<<2 ;	// Red 
				TGAPalette[i*3+0] = *(Palette+i*3+2)<<2;	// Blue 
				TGAPalette[i*3+1] = *(Palette+i*3+1)<<2;	// Green
				TGAPalette[i*3+2] = tmp;	// Red 
			}
			// Palette Data
			Size = numColors*3;
			memcpy(TGABuf+TGAOffset, TGAPalette, Size);
			TGAOffset = TGAOffset + Size;
			
			// Pixels Data
			Size = Width*Height;
			memcpy(TGABuf+TGAOffset, DATBuf, Size);
			TGAOffset = TGAOffset + Size;
			
			WriteFile(FileName, TGABuf, TGAOffset);
	return 	0;
}


u16 CheckSum(s8* String)
{
	s32	i;
	u16	sum;
	
	sum = 0;
	for(i=0;i<strlen(String);i++)
		sum=sum+String[i];
	
	return	sum;
}

typedef	struct _dataInfo
{
	u32	No;
	s32	Offset;	// from the end of file
	u32	Size;
} dataInfo;

s32 LoadDAT(u8 *Buf, u32 BufBase, u32 BufSize)
{
	s8	Filename[128];

	tga_hdr	tga;
	u16	CI;	// Color Index 
	u16	numColors;	// number of Colors
	u8	Maximum;
	s32	i;
	u32	Base;
	u32	Offset;
	u32	Size;
	u16	Width, Height;
	u32	numData;	// number of data
	dataInfo	DataInfo;
	s32	Ofs;
	u32	DATSize;
	u32	RAWSize;

			
		// Initialize
		Base = BufBase;


			Size = BufSize;	
			numData = 0x3a;	// the number of the DataInfo
			Size = numData*sizeof(dataInfo);
			printf("%3d %08x %08x\n", numData, sizeof(dataInfo), Size);

			Size = sizeof(dataInfo);
			for(i=1;i<=numData;i++)
			{
				Offset = BufSize-i*Size;	// the offset of the i-th DataInfo
				memcpy(&DataInfo, Buf+Offset, Size);

				Ofs = BufSize + DataInfo.Offset;		// the offset of compressed data from the begin of file
				//DataInfo.Size;	// the size of compressed data
				sprintf(Filename, "%08d.DAT", DataInfo.No);

				printf("\t %s: %08x - %08x %08x %08x  %08x" , Filename, Offset, Ofs, DataInfo.Offset, DataInfo.Size, (Ofs+DataInfo.Size));
				memcpy(DATABuf, Buf+Ofs, DataInfo.Size);	
				
				unsigned int csize;
				unsigned int dsize;
				uint16_t crc;
				if (get_dlz_info ((char*)DATABuf, csize, dsize, crc))
				{
					//	decode DLZ data
					printf("\t %08x %08x %04x", csize, dsize, crc);
					dlz_decoder_c d ((char*)DATABuf+DLZ_HEADER_SIZE, csize);
					d.decode ((char*)RAWBuf, dsize);
					RAWSize = dsize;
					if (RAWSize==64768)
					{
						char GFXFilename[80];
						sprintf(GFXFilename,"%08x.TGA", DataInfo.No);
						WriteTGAFile(GFXFilename,320,200,RAWBuf,RAWBuf+768,320*200);
					}
				}
				else
				{
					RAWSize = DataInfo.Size;
					memcpy(RAWBuf, DATABuf, RAWSize);
				}
				WriteFile(Filename, RAWBuf, RAWSize);	// Write data to file
				printf("\n");
				Offset = Offset+Size;	// Next DataInfo
			}
			



	return	0;
}


/* main program */
int main(int argc, char* argv[])
{
	FILE	*hFile;
	s8	Filename[128];
	u32	FileBase;
	u32	FileOffset;
	u32	numRead, numWritten;
	u32	Base, Offset;	
	u32	Status;


	if (argc==2)
	{
		strcpy(SrcFilename, argv[1]);
	}
	else
	{
		printf("Syntax: %s FILENAME.EXE \n", argv[0]);
		return	-1;	
	}

	numRead = CODESIZE;
	Status = ReadFile( SrcFilename, 0L, CODEBuf, &numRead);	// Read CODE File
	if (Status==0)
	{
		printf("%s\t%12d\n", SrcFilename, numRead);

	
		
		IMAGE_DOS_HEADER *ImageDOSHeader = (IMAGE_DOS_HEADER *)CODEBuf;
		if (ImageDOSHeader)
		{
			Base = ImageDOSHeader->e_cparhdr;
			Base = Base <<4;	// Base of CODE

			Status = LoadDAT(CODEBuf, Base, numRead);
	
		}

	}
	

//	if (Status==0)	printf("%s  %8d\n", SrcFilename, numRead);
	
	
	return 0;
}

	
