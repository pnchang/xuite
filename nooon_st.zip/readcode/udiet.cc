// Tim Felgentreff tombexcavator
#include <stdexcept>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include "types.h"

#define	DBG		0x04
#define	test	0

/*
   CRC-16

   16 bit, non-reflected CRC using the polynomial 0x8005
   and the initial and final xor values shown below.
   in other words, the CCITT standard CRC-16
*/

#define CRC16_INIT_VALUE	0x0000	// 0xffff
#define CRC16_XOR_VALUE		0x0000

static uint16_t crctable[256];

/*
   Generate a table for a byte-wise 16-bit CRC calculation on the polynomial:
   x^16 + x^15 + x^2 + x^0
*/

void make_crc_table( void ) 
{
	int i, j;
	uint16_t poly, c, crc;
	/* terms of polynomial defining this crc (except x^16): */
	static const byte p[] = {0,2,15};
	/* make exclusive-or pattern from polynomial (0xA001) */
	poly = 0L;
	for ( i = 0; i < sizeof( p ) / sizeof( byte ); i++ ) {
		poly |= 1L << (15-p[i]);
	}

	for ( i = 0; i < 256; i++ ) {
		c = i;
		crc = 0;
		for ( j = 0; j < 8; j++ ) {
			crc = ( (crc ^c) & 0x0001 ) ? poly ^ ( crc >> 1 ) : ( crc >> 1 );
			c = c >> 1;	// right shift
		}
		crctable[i] = crc;
	}
}


void CRC16_InitChecksum( uint16_t &crcvalue ) {
	crcvalue = CRC16_INIT_VALUE;
}

void CRC16_Update( uint16_t &crcvalue, const byte data ) {
	crcvalue = ( crcvalue << 8 ) ^ crctable[ ( crcvalue >> 8 ) ^ data ];
}

void CRC16_UpdateChecksum( uint16_t &crcvalue, const void *data, int length ) {
	uint16_t crc;
	const unsigned char *buf = (const unsigned char *) data;

	crc = crcvalue;
	while( length-- ) {
		crc = ( crc >> 8 ) ^ crctable[ ( crc ^ *buf++) & 0xff ];
	}
	crcvalue = crc;
}

void CRC16_FinishChecksum( unsigned short &crcvalue ) {
	crcvalue ^= CRC16_XOR_VALUE;
}

unsigned short CRC16_BlockChecksum( const void *data, int length ) {
	unsigned short crc;

	CRC16_InitChecksum( crc );
	CRC16_UpdateChecksum( crc, data, length );
	CRC16_FinishChecksum( crc );
	return crc;
}





// =========================================================================
static const long DLZ_HEADER_SIZE = 0x11;
// 4+2+3+1+2+2+3
typedef	struct _dlzHeader{
	char	iCode[4];	// MOV AH,4Ch,INT 21h
	uint16_t	nCode;	// 'DI'+'ET'=899Dh
	char	Signature[3];	// dlz
	char	cSizeH:4;	// 4-bit low nibble 
	char	flag:4;		// 4-bit high nibble compressed Type
	uint16_t	cSizeL;	// 20-bit length compressed Size (cSizeH and cSizeL)
	uint16_t	CRC;	// Cyclic Redundancy Check 16  8005 
	uint8_t		dSizeH;	// one byte
	uint16_t	dSizeL;	// 24-bit length decompressed Size (dSizeH and dSizeL) 
} dlzHeader;

bool get_dlz_info (const char* buf, unsigned int& csize,
		   unsigned int& dsize,
		   uint16_t& crc)
{
	dlzHeader	*pHeader = (dlzHeader*)buf;
	int	size;
	
	if ( (pHeader == NULL) )
	{
		return false;
	}
	if (memcmp((*pHeader).Signature, "dlz", 3) !=0 )
	{
		return false;
    }

	size = ((*pHeader).cSizeH << 16);
	size = size | ((*pHeader).cSizeL & 0xFFFF);
	csize = size;
	crc = (*pHeader).CRC;
	size = ((*pHeader).dSizeH << 14);
	size = size | ((*pHeader).dSizeL & 0xFFFF);
	dsize = size; 

	return true;
}
// --------------------------------------------------------------------
class dlz_decoder_c
{
public:
  dlz_decoder_c (const char* ibuff, size_t ibuff_size);
  void decode (char* obuff, size_t obuff_size);
private:
  bool _get_control_bit ();
  byte _loadb ();
  void _storeb ();
private:
  const char*    m_ibuff;
  const size_t   m_ibuff_size;
  char*          m_obuff;
  uint32_t       m_obuff_ptr;
  size_t         m_obuff_size;
  size_t         m_work_buff_ptr;
  uint16_t       m_code_word;
  byte           m_bits;
  byte           m_data;
  const char*    m_test;	// for testing used
};

dlz_decoder_c::dlz_decoder_c (const char* ibuff, size_t ibuff_size)
  : m_ibuff          (ibuff),
    m_ibuff_size     (ibuff_size),
    m_obuff          (0),
    m_obuff_ptr      (0),
    m_obuff_size     (0),
    m_work_buff_ptr  (0),
    m_code_word      (0),
    m_bits           (1),
    m_data           (0),
    m_test           (0)
{
  
}
// -------------------------------------------------------------------
byte dlz_decoder_c::_loadb ()
{
  if (m_work_buff_ptr >= m_ibuff_size)
    {
      printf ("offset too big\n");
      throw std::runtime_error ("offset too big");
    }
  m_data = (byte) m_ibuff [m_work_buff_ptr];
  m_work_buff_ptr++;
  return m_data; 
}
// -------------------------------------------------------------------
void dlz_decoder_c::_storeb ()
{
  m_obuff [m_obuff_ptr] = (char) m_data;
  m_obuff_ptr++;
}
// -------------------------------------------------------------------
bool dlz_decoder_c::_get_control_bit ()
{
  bool lsb = ( (m_code_word & 0x1) == 0x1);
  m_code_word = m_code_word >> 1;
  m_bits--;

  if (m_bits == 0)
    {
      _loadb ();
      byte a = m_data;
      _loadb ();
      byte b = m_data;

      reg16_t r;
      R_LOW  (r) = a;
      R_HIGH (r) = b;
      m_code_word = r.data;

      m_bits = 0x10;
    }
  return lsb;
}
// --------------------------------------------------------------------
bool rcl (byte& x, bool cf)
{
  const byte mask = 1 << 7;
  bool temp_cf = ((x & mask) == mask);
  x = ((x << 1) + (cf & 0x1));
  return temp_cf;
}
// --------------------------------------------------------------------
void dlz_decoder_c::decode (char* obuff, size_t obuff_size)
{

  reg16_t bx;
  reg16_t cx;
  byte dh = 0;
  bool c;
  
  size_t offset;

  m_obuff = obuff;
  m_obuff_size = obuff_size;
  _get_control_bit (); // loads code word

 u11:; 
  cx.data = 0;
  while (true)
    {
      c = _get_control_bit ();
      if (!c) break;
      _loadb ();
      _storeb ();
    }

 
  c = _get_control_bit ();
  
  R_LOW  (bx) = _loadb ();
  R_HIGH (bx) = 0xFF;

  if (c) 
    {
      c = _get_control_bit ();
      rcl (R_HIGH (bx), c);

      c = _get_control_bit ();
      if (!c) 
	{
	  dh = 2;
	  R_LOW (cx) = 3;
	  while (true)
	    {
	      c = _get_control_bit ();
	      if (!c) 
		{
		  c = _get_control_bit ();
		  rcl (R_HIGH (bx), c);
		  dh = dh << 1;
		  cx.data --;
		  if (cx.data == 0) break;
		}
	      else
		{
		  break;
		}
	    }
	  R_HIGH (bx) = R_HIGH (bx) - dh;
	}
      dh = 2;
      R_LOW (cx) = 4;
    u3:; 
      while (true)
	{
	  dh++;
	  c  = _get_control_bit ();
	  if (!c) 
	    {
	      cx.data --;
	      if (cx.data != 0)
		{
		  goto u3;
		}
	      else
		{
		  c = _get_control_bit ();
		  if (!c) 
		    {
		      c = _get_control_bit (); 
		      if (c) 
			{
			  R_LOW (cx) = _loadb ();
			  cx.data += 0x11;
			}
		      else
			{
			  R_LOW (cx) = 3;
			  dh = 0;
		      
			  for (int i=0; i<cx.data; i++)
			    {
			      c = _get_control_bit ();
			      rcl (dh, c);
			    }
			  cx.data = 0;
		      
			  dh += 9;
			  R_LOW (cx) = dh;
			}
		      goto u10;
		    }
		  dh++;
		  c = _get_control_bit ();
		  if (c) 
		    {
		      dh++;
		    }
		}
	  
	    }
	  R_LOW (cx) = dh;
	  break;
      
	}
      goto u10;
    }

  c = _get_control_bit ();
  if (c) 
    {
      for (int i=0; i<3; i++)
	{
	  c = _get_control_bit ();
	  rcl (R_HIGH (bx), c);
	}
      R_HIGH (bx)--;
      cx.data = 2;
    }
  else
    {
      if (R_LOW (bx) != R_HIGH (bx))
	{
	  R_LOW (cx) = 2;
	}
      else
	{
	  c = _get_control_bit ();
	  if (c) goto u11;
	  goto up;
	}
    }

 u10:; 
  for (int i=0; i<cx.data; i++)
    {
      int32_t s_bx = 0xFFFF0000 | (bx.data & 0xFFFF);
      offset = m_obuff_ptr + s_bx;
      m_data = (byte)obuff [offset];
      _storeb ();
    }
  cx.data = 0;
  goto u11;
  
 up:;
#if (DBG&0x08)
  printf ("decode>>\n", );
#endif
}

#if test
// --------------------------------------------------------------------
int main (int argc, char* argv [])
{
  if (argc != 3)
    {
      printf ("USAGE : %s <fname> <fname>\n", argv [0]);
      return 1;
    }
  char* fname = argv [1];

  unsigned int csize;
  unsigned int dsize;
  uint16_t crc;

  
  FILE* f = fopen (fname, "rb");
  char DLZHeader[DLZ_HEADER_SIZE];
  fseek (f, 0, SEEK_SET);
  fread (DLZHeader, DLZ_HEADER_SIZE, 1, f);    
  
  if (!get_dlz_info (DLZHeader, csize, dsize, crc))
    {
      printf ("BAD DLZ\n");
      return 1;
    }
	
#if (DBG&0x04)
  printf ("Compressed Size   : %d\n", csize);
  printf ("Decompressed Size : %d\n", dsize);
  printf ("CRC               : %X\n", crc);
#endif

  const size_t ibuff_size = csize;
  char* ibuff = new char [ibuff_size];

  const size_t obuff_size = dsize;
  char* obuff = new char [obuff_size];

  fread (ibuff, ibuff_size, 1, f);
  fclose (f);

  
  try
    {
      dlz_decoder_c d (ibuff, ibuff_size);
      d.decode (obuff, obuff_size);
		f = fopen (argv [2], "wb+");
		fwrite (obuff, obuff_size, 1, f);
		fclose (f);	  
    }
  catch (std::exception& e)
    {
      printf ("EXCEPTION: %s\n", e.what ());
    }
  make_crc_table ();
  uint16_t mycrc = CRC16_BlockChecksum (ibuff, ibuff_size);
#if (DBG&0x04)  
  printf ("CRC = %X\n", mycrc);
#endif
  return 0;
}
#endif
