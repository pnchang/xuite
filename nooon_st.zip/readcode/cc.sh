# linux 
#export LD_LIBRARY_PATH=/usr/local/lib 
gcc -fpack-struct=1 -fexceptions -fpermissive -static -D"__STDC_LIMIT_MACROS" -o readcodg  readcod.cpp -lstdc++  
