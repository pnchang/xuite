/*
	COMMON.H
	
	Author: Pingnan Chang
	Last change: 11/12/2014
*/

#ifndef __COMMON__
#define __COMMON__

#include <stdint.h>	/* standard integer */

#if defined(_MSC_VER)||defined(MINGW)
#include <windows.h>

/*
#define	s8		char
#define	u8		unsigned char
#define	s16		short
#define	u16		unsigned short
#define s32		int
#define	u32		unsigned int
#define	s64		signed long int 

#define	byte	unsigned char
#define	ushort	unsigned short
*/
#define	ENDIAN	0	/* little-endian */


#else
// UNIX-like
#ifndef	USHORT
#define	USHORT	uint16_t	
#endif
#ifndef	WORD
#define	WORD	uint16_t
#endif
#ifndef	LONG
#define	LONG	int32_t	
#endif

#define	ENDIAN	0	/* little-endian */

#pragma pack(push)	/* push current alignment to stack */
#pragma pack(1)	/* set alignment to 1 byte boundary */

// winnt.h
#if (ENDIAN==0)
#define IMAGE_DOS_SIGNATURE                 0x5A4D      // MZ
#define IMAGE_OS2_SIGNATURE                 0x454E      // NE
#define IMAGE_OS2_SIGNATURE_LE              0x454C      // LE
#define IMAGE_VXD_SIGNATURE                 0x454C      // LE
#define IMAGE_NT_SIGNATURE                  0x00004550  // PE00
#else
#define IMAGE_DOS_SIGNATURE                 0x4D5A      // MZ
#define IMAGE_OS2_SIGNATURE                 0x4E45      // NE
#define IMAGE_OS2_SIGNATURE_LE              0x4C45      // LE
#define IMAGE_NT_SIGNATURE                  0x50450000  // PE00
#endif

typedef struct _IMAGE_DOS_HEADER {      // DOS .EXE header
    WORD   e_magic;                     // Magic number
    WORD   e_cblp;                      // Bytes on last page of file
    WORD   e_cp;                        // Pages in file
    WORD   e_crlc;                      // Relocations
    WORD   e_cparhdr;                   // Size of header in paragraphs
    WORD   e_minalloc;                  // Minimum extra paragraphs needed
    WORD   e_maxalloc;                  // Maximum extra paragraphs needed
    WORD   e_ss;                        // Initial (relative) SS value
    WORD   e_sp;                        // Initial SP value
    WORD   e_csum;                      // Checksum
    WORD   e_ip;                        // Initial IP value
    WORD   e_cs;                        // Initial (relative) CS value
    WORD   e_lfarlc;                    // File address of relocation table
    WORD   e_ovno;                      // Overlay number
    WORD   e_res[4];                    // Reserved words
    WORD   e_oemid;                     // OEM identifier (for e_oeminfo)
    WORD   e_oeminfo;                   // OEM information; e_oemid specific
    WORD   e_res2[10];                  // Reserved words
    LONG   e_lfanew;                    // File address of new exe header
  } IMAGE_DOS_HEADER, *PIMAGE_DOS_HEADER;

  
#pragma pack(pop)	/* restore original alignment from stack */

#endif

/*
    MZ: Mark Zbikowski 

*/

#endif
