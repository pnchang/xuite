#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>	/* bool, falae, true */
#include <math.h>
#include "grafix.h"


#ifdef SDL
#include <SDL.h>
#else
#include <windows.h>
#ifdef __cplusplus 
extern "C" {
#endif 
#include "tinyptc.h"
#ifdef __cplusplus 
}
#endif
#endif	


#define PI      3.14159265359
#define fixpf   8
#define fixp    (1<<fixpf)
#define Dist    28<<fixpf
#define rl      10<<fixpf

typedef struct VECTOR {
  int x, y, z;
} VECTOR;

typedef struct zbufpoint {
  short color, dist;
} zbufpoint;

VECTOR cverts[8] = { {-rl,-rl,-rl}, {rl,-rl,-rl}, {rl,-rl,rl}, {-rl,-rl,rl},
                     {-rl, rl,-rl}, {rl, rl,-rl}, {rl, rl,rl}, {-rl, rl,rl} };
VECTOR verts[8];
int polys[6][4] = { {0,1,5,4}, {1,2,6,5}, {2,3,7,6}, {3,0,4,7}, 
                    {3,2,1,0}, {4,5,6,7} };

int sintab[360];
int costab[360];

zbufpoint zbuf[Screen_Width*Screen_Height];
char	VGAAddr[Screen_Width * Screen_Height];	// 8-bit depth frame buffer 
uint32_t	FrameBuffer[Screen_Width * Screen_Height];	// 32-bit depth frame buffer 
static int Quitting = false;
int Pausing = false;

#ifdef SDL
SDL_Window *sdlWindow;	// SDL2
SDL_Surface *screen;
SDL_Event event;
int g_rgb;

//	Prototype
void sdl_update(uint32_t *FrameBuffer);

#endif


int filesize (FILE *f) {
  int curpos, size;
  
  curpos = ftell (f);
  fseek (f, 0, SEEK_END);
  size = ftell (f);
  fseek (f, curpos, SEEK_SET);
  return size;
};

void *loadfile (char name[], int *size) {
  FILE  *f;
  char  *buf;

  if ( !(f = fopen (name, "rb")) ) return NULL;
  else {
    *size = filesize (f);
    buf = (char *) malloc (*size);
    fread (buf, 1, *size, f);
    fclose (f);
    return buf;
  };
}

void compute_tables() {
  int i;
  for (i=0;i<360;i++) {
    sintab[i] = (int) (fixp * sin(i*PI/180));
    costab[i] = (int) (fixp * cos(i*PI/180));
  };
}

void zclear (char color) {
  int no=Screen_Width*Screen_Height;
  while (no--) {
    zbuf[no].dist = 0x7FFF;
    zbuf[no].color = color;
  };
}

void zputpixel (int x, int y, int z, char color) {
  int n;
  n = (y*Screen_Width) + x;
  if (zbuf[n].dist > z) {
    zbuf[n].dist = z;
    zbuf[n].color = color;
  };
}

void zdraw()
{
	
}


void vector_mul (VECTOR *a, VECTOR *b, VECTOR *c) {
  int x, y, z;
  z = (a->x*b->y - a->y*b->x);
  x = (a->y*b->z - a->z*b->y);
  y = (a->z*b->x - a->x*b->z);
  z = z / fixp;
  x = x / fixp;
  y = y / fixp;  
  c->z=z;
  c->x=x;
  c->y=y;
}

int scantab[Screen_Height][2];
int ymin, ymax;

void scanline (int x1, int y1, int x2, int y2) {
  int sx, sy, dx1, dy1, dx2, dy2, m, n, cnt;
  register int x, y, k=0;

  sx = x2-x1;
  sy = y2-y1;

  if (sx > 0) dx1 = 1;
  else if (sx < 0) dx1 = -1;
  else dy1 = 0;

  if (sy > 0) dy1 = 1;
  else if (sy < 0) dy1 = -1;
  else dy1 = 0;

  m = abs (sx);
  n = abs (sy);

  dx2 = dx1;
  dy2 = 0;

  if (m < n) {
    m = abs (sy);
    n = abs (sx);
    dx2 = 0;
    dy2 = dy1;
  };

  x = x1; y = y1;
  cnt = m+1;
  while (cnt--) {
    if ((y >= 0) && (y <= Screen_Width-1)) {
      if (x < scantab[y][0]) scantab[y][0] = x;
      if (x > scantab[y][1]) scantab[y][1] = x;
    };
    k += n;
    if (k < m) {
      x += dx2;
      y += dy2;
    }
    else {
      k -= m;
      x += dx1;
      y += dy1;
    };
  };
}

void scanpoly (int x1, int y1, int x2, int y2,
               int x3, int y3, int x4, int y4) {
  register int i;
  
  for (i=0; i<=Screen_Height-1; i++) {
    scantab[i][0] = 32767;		// init min
    scantab[i][1] = -32767;		// init max
  };

  ymin = y1;
  if (y2 < ymin) ymin = y2;
  if (y3 < ymin) ymin = y3;
  if (y4 < ymin) ymin = y4;
  ymax = y1;
  if (y2 > ymax) ymax = y2;
  if (y3 > ymax) ymax = y3;
  if (y4 > ymax) ymax = y4;

  scanline (x1, y1, x2, y2);
  scanline (x2, y2, x3, y3);
  scanline (x3, y3, x4, y4);
  scanline (x4, y4, x1, y1);
}

void tmap (VECTOR *P, VECTOR *M, VECTOR *N, char *texture) {
  VECTOR PM, NP, MN;
  int x1, y1, x2, y2, x3, y3, x4, y4, x, y, i, j, xl, xr, cnt, yoffs, xoffs;
  int delta, deltau, deltav, u, v, ds, dus, dvs, dj, duj, dvj;
  char color;
  int z, zz;

  vector_mul (P, M, &PM);
  vector_mul (N, P, &NP);
  vector_mul (M, N, &MN);

  x1 = (P->x << 8) / P->z;
  y1 = (P->y << 8) / P->z;
  x2 = ((P->x+M->x) << 8) / (P->z+M->z);
  y2 = ((P->y+M->y) << 8) / (P->z+M->z);
  x3 = ((P->x+M->x+N->x) << 8) / (P->z+M->z+N->z);
  y3 = ((P->y+M->y+N->y) << 8) / (P->z+M->z+N->z);
  x4 = ((P->x+N->x) << 8) / (P->z+N->z);
  y4 = ((P->y+N->y) << 8) / (P->z+N->z);

  scanpoly (x1+Center_X, y1+Center_Y, x2+Center_X, y2+Center_Y,
            x3+Center_X, y3+Center_Y, x4+Center_X, y4+Center_Y);

  if ((ymin>Screen_Height-1) || (ymax<0)) return;
  if (ymin < 0) ymin = 0;
  if (ymax > Screen_Height-1) ymax = Screen_Height-1;

  j = (ymin-Center_Y);
  dj = MN.y;
  duj = NP.y;
  dvj = PM.y;
  ds = (MN.z<<8) + j*dj;
  dus = (NP.z<<8) + j*duj;
  dvs = (PM.z<<8) + j*dvj;
  yoffs = (ymin*Screen_Height*4) + (int)zbuf;

  for (y=ymin; y<=ymax; y++) {
    i = scantab[y][0]-Center_X;
    delta  = (ds + i*MN.x);
    deltau = (dus + i*NP.x);
    deltav = (dvs + i*PM.x);
    ds += dj;
    dus += duj;
    dvs += dvj;
    if ((xl=i+Center_X) < 0) xl=0;
    if ((xr=scantab[y][1]) > Screen_Width-1) xr=Screen_Width-1;
    xoffs = xl<<2;
    x = xl;
    cnt = xr-xl+1;
    while (cnt--) {
      u = (deltau<<6) / delta;
      v = (deltav<<6) / delta;
      if (u < 0) u = 0;
      else if (u > 63) u = 63;
      if (v < 0) v = 0;
      else if (v > 63) v = 63;
      color = texture[(v<<6)+u];
      zz = P->z + M->z*u/64 + N->z*v/64;

      zputpixel (x, y, zz, color);

      delta  += MN.x;
      deltau += NP.x;
      deltav += PM.x;
      xoffs += 4;
	  x++;
    };
    yoffs += Screen_Width*4;
  };
}

void rotate_vector_x (int no, int angle) {
  VECTOR v;
  v.y = (verts[no].y * costab[angle]  +  verts[no].z * sintab[angle]);
  v.z = (verts[no].z * costab[angle]  -  verts[no].y * sintab[angle]);
  v.x = verts[no].x;
  v.y = v.y / fixp;
  v.z = v.z / fixp;
 
  verts[no] = v;
}
void rotate_vector_y (int no, int angle) {
  VECTOR v;
  v.z = (verts[no].z * costab[angle]  +  verts[no].x * sintab[angle]);
  v.x = (verts[no].x * costab[angle]  -  verts[no].z * sintab[angle]);
  v.y = verts[no].y;
  v.z = v.z / fixp;
  v.x = v.x / fixp;

  verts[no] = v;
}
void rotate_vector_z (int no, int angle) {
  VECTOR v;
  v.x = (verts[no].x * costab[angle]  +  verts[no].y * sintab[angle]);
  v.y = (verts[no].y * costab[angle]  -  verts[no].x * sintab[angle]);
  v.z = verts[no].z;
  v.x = v.x / fixp;
  v.y = v.y / fixp;

  verts[no] = v;
}

void rotate_cube (int anglex, int angley, int anglez) {
  int i;

  for (i=0;i<8;i++) {
    verts[i] = cverts[i];
    rotate_vector_x (i, anglex);
    rotate_vector_y (i, angley);
    rotate_vector_z (i, anglez);
    verts[i].z += Dist;
  };
}

void vector_sub (VECTOR *a, VECTOR *b, VECTOR *c) {
  c->x = a->x - b->x;
  c->y = a->y - b->y;
  c->z = a->z - b->z;
}

void draw_cube (char *texture) {
  int i;
  VECTOR P, M, N, Normal;

  for (i=0;i<6;i++) {
    P = verts[polys[i][0]];
    vector_sub (&verts[polys[i][1]], &verts[polys[i][0]], &M);
    vector_sub (&verts[polys[i][3]], &verts[polys[i][0]], &N);
    vector_mul (&M, &N, &Normal);
    if (Normal.z > 0) tmap (&P, &M, &N, texture);  // hidden face removing
  };
}

int biostime() {
//40:6C	dword	Daily timer counter, equal to zero at midnight;
	int counter;
	counter	= 0;
  return counter;
}

void demomain() {
  char *texture1, *texture2, *palette;
  int t1size, t2size, psize;
  int xa=0, ya=0, za=0;
  char key=0xFF;
  int t0, t1, frames=0, cubes=2;
  int i, j;

  texture1 = loadfile ("TEXTURE1.DAT", &t1size);
  if (!texture1) {
    printf ("Unable to open TEXTURE1.DAT file.\n");
    return;
  };
  texture2 = loadfile ("TEXTURE2.DAT", &t2size);
  if (!texture2) {
    printf ("Unable to open TEXTURE2.DAT file.\n");
    free (texture1);
    return;
  };
  palette = loadfile ("PALETTE.DAT", &psize);
  if (!palette) {
    printf ("Unable to open PALETTE.DAT file.\n");
    free (texture1);
    free (texture2);
    return;
  };

  compute_tables();

  t1 = t0 = biostime();
  while (!Quitting) {
	
    zclear (BLACK);
    rotate_cube (xa, ya, za);
    draw_cube (texture1);
	
    if (cubes == 2) {
      rotate_cube (ya, za, xa);
      draw_cube (texture2);
    };
	
    zdraw();
// 8-bit to 32-bit depth
for(j=0;j<Screen_Height;j++)
{
	int ofs=j*Screen_Width;
	for(i=0;i<Screen_Width;i++)
	{
		unsigned short int c;
		unsigned int colour;
		unsigned char r,g,b;
		c= zbuf[ofs+i].color;
		r=palette[c*3+0];
		g=palette[c*3+1];
		b=palette[c*3+2];
		colour=(r<<18)|(g<<10)|(b<<2);
		FrameBuffer[j*Screen_Width+i]=colour;
	}
}
#ifdef SDL
sdl_update(FrameBuffer);
#else
ptc_update(FrameBuffer);
#endif		
	if (!Pausing)
	{
    xa=(xa+2)%360;
    ya=(ya+4)%360;
    za=(za+6)%360;
	}
    if (t1-t0 < 18*5*60) {			// average at 5 min
      t1 = biostime();
      frames++;
    }
#ifdef SDL
		//update SDL events
		while (SDL_PollEvent(&event)) 
		{
			switch (event.type) 
			{
			case SDL_KEYDOWN:
				break;
			case SDL_KEYUP:
				// If escape is pressed, return (and thus, quit)
				if (event.key.keysym.sym!=SDLK_SPACE)	Pausing = false;
				switch (event.key.keysym.sym)
				{
					case SDLK_SPACE:
						Pausing = !Pausing;	// pause
						break;	
					case SDLK_a:
						//if (distance < 300)
						//distance += 5;		// move pyramide farther
						break;
					case SDLK_z:
						//if (distance > 30)
						//distance -= 5;		// move pyramide closer
						break;						
					case SDLK_c:
						cubes = 3 - cubes;	// cube
						break;	
					case SDLK_ESCAPE:
						Quitting = true;
						break;
				}
				break;
			case SDL_QUIT:
				Quitting = true;
			}
		}
#endif	
  };

//  printf ("%d fps\n", frames*18/(t1-t0));
  free (texture1);
  free (texture2);
  free (palette);
}


#ifdef SDL

void sdl_update(uint32_t *FrameBuffer)
{
	int x, y;
	int yofs, ofs;
	uint32_t *pdst;
	uint32_t colour;
    char *psrcc;
	
  // Lock surface if needed
  if (SDL_MUSTLOCK(screen)) 
	  if (SDL_LockSurface(screen) < 0) 
		  return;
  // Draw to screen
  yofs = 0;
  for (y = 0; y < Screen_Height; y++) {
	  for (x = 0, ofs = yofs; x < Screen_Width; x++, ofs++) {
            pdst = &((uint32_t*)screen->pixels)[ofs];
			psrcc = (char *) &FrameBuffer[y*Screen_Width+x];
			colour = SDL_MapRGB( screen->format, psrcc[2], psrcc[1], psrcc[0] );
			*pdst = colour;			

	  }
	  yofs += screen->pitch / 4;
  }

  // Unlock if needed
  if (SDL_MUSTLOCK(screen)) 
	  SDL_UnlockSurface(screen);

  // Tell SDL to update the whole screen
  //SDL_UpdateRect(screen, 0, 0, 640, 480);	SDL
  SDL_UpdateWindowSurface(sdlWindow);	// SDL2
}

int main(int argc, char *argv[]) {

	SDL_Event event;
	unsigned int sdl_flags = SDL_SWSURFACE;
	//const SDL_VideoInfo *videoInfo;

	g_rgb = 0;

	if(SDL_Init(SDL_INIT_VIDEO) < 0) {
		fprintf(stderr, "Video initialization failed: %s\n",
			SDL_GetError());
		return 0;
	}

	if (argc>1) {
		sdl_flags |= SDL_WINDOW_FULLSCREEN;
		if (argv[1][0]=='r')
			g_rgb = 1;
	} else {
		//printf("options: f - fullscreen, bgr/rgb - color mapping.\n")
	}
	// Attempt to create a 640x480 window with 32bit pixels.
//	screen = SDL_SetVideoMode(640, 480, 32, sdl_flags);	// SDL
// Window mode 
    sdlWindow = SDL_CreateWindow("ZBUF",
                          SDL_WINDOWPOS_UNDEFINED,
                          SDL_WINDOWPOS_UNDEFINED,
                          Screen_Width, Screen_Height,
						  sdl_flags);
//Get window surface
	screen = SDL_GetWindowSurface( sdlWindow );

	// If we fail, return error.
	if ( screen == NULL ) {
		fprintf(stderr, "Unable to set %4dx%4d video: %s\n", Screen_Width, Screen_Height, SDL_GetError());
		return 0;
	}
    demomain();

	//Free Surface
	if (screen)	SDL_FreeSurface(screen);
	//Destroy window
	if (sdlWindow)	SDL_DestroyWindow( sdlWindow );	
	//Quit SDL subsystems
    SDL_Quit();	

  return 0;
}

#else

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
  int ret = ptc_open("ZBUF", Screen_Width, Screen_Height);
  if (!ret) {
	MessageBox(0,"failed to init ptc","error",MB_OK);
	return 0;
  }
    demomain( );  

  return 0;
}

#endif
