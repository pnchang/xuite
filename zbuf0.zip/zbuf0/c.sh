# MinGW TinyPTC  SDL2 
#export SDLDIR='/D/DEMOS/SDL/SDL2-2.0.2-MinGW/i686-w64-mingw32/'
export PTCDIR='TinyPTC/'
gcc -fno-exceptions -fpermissive -I"$PTCDIR" -I"$SDLDIR""Include" -L"$SDLDIR""lib" -o ZBUFG.EXE  ZBUF.C  "$PTCDIR"convert.c "$PTCDIR"ddraw.c "$PTCDIR"mmx.obj "$PTCDIR"tinyptc.c  -lstdc++ -mwindows 