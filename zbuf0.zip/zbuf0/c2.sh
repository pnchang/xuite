# MinGW  TinyPTC / SDL2 
export SDLDIR='/D/DEMOS/SDL/SDL2-2.0.2-MinGW/i686-w64-mingw32/'
#export PTCDIR='TinyPTC/'
gcc -x c -fno-exceptions -fpermissive -D"USE_C" -D"SDL" -I"$SDLDIR""Include/SDL2" -L"$SDLDIR""lib" -o ZBUFSG.EXE  ZBUF.C  -lm -lmingw32 -lSDL2main -lSDL2 -mwindows 