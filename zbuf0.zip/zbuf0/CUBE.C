#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <conio.h>	/* kbhit(), getch() */
#include <string.h>	/* memset(), memcpy() */
#include "grafix.h"

#define PI      3.14159265359
#define fixpf   8
#define fixp    (1<<fixpf)
#define Dist    48<<fixpf
#define rl      10<<fixpf

typedef struct VECTOR {
  int x, y, z;
} VECTOR;

char *vscr;

VECTOR cverts[8] = { {-rl,-rl,-rl}, {rl,-rl,-rl}, {rl,-rl,rl}, {-rl,-rl,rl},
                     {-rl, rl,-rl}, {rl, rl,-rl}, {rl, rl,rl}, {-rl, rl,rl} };
VECTOR verts[8];
int polys[6][4] = { {0,1,5,4}, {1,2,6,5}, {2,3,7,6}, {3,0,4,7}, 
                    {3,2,1,0}, {4,5,6,7} };

int sintab[360];
int costab[360];

int filesize (FILE *f) {
  int curpos, size;
  
  curpos = ftell (f);
  fseek (f, 0, SEEK_END);
  size = ftell (f);
  fseek (f, curpos, SEEK_SET);
  return size;
};

void *loadfile (char name[], int *size) {
  FILE  *f;
  char  *buf;

  if ( !(f = fopen (name, "rb")) ) return NULL;
  else {
    *size = filesize (f);
    buf = (char *) malloc (*size);
    fread (buf, 1, *size, f);
    fclose (f);
    return buf;
  };
}

void compute_tables() {
  int i;
  for (i=0;i<360;i++) {
    sintab[i] = (int) (fixp * sin(i*PI/180));
    costab[i] = (int) (fixp * cos(i*PI/180));
  };
}

void vector_mul (VECTOR *a, VECTOR *b, VECTOR *c) {
  int x, y, z;
  z = (a->x*b->y - a->y*b->x);
  x = (a->y*b->z - a->z*b->y);
  y = (a->z*b->x - a->x*b->z);
  x = x >> fixpf;
  y = y >> fixpf;
  z = z >> fixpf;
/*
  _asm{
    sar   z, fixpf
    sar   x, fixpf
    sar   y, fixpf
  };
*/
  c->z=z;
  c->x=x;
  c->y=y;
}

int scantab[200][2];
int ymin, ymax;

void scanline (int x1, int y1, int x2, int y2) {
  int sx, sy, dx1, dy1, dx2, dy2, m, n, cnt;
  register int x, y, k=0;

  sx = x2-x1;
  sy = y2-y1;

  if (sx > 0) dx1 = 1;
  else if (sx < 0) dx1 = -1;
  else dy1 = 0;

  if (sy > 0) dy1 = 1;
  else if (sy < 0) dy1 = -1;
  else dy1 = 0;

  m = abs (sx);
  n = abs (sy);

  dx2 = dx1;
  dy2 = 0;

  if (m < n) {
    m = abs (sy);
    n = abs (sx);
    dx2 = 0;
    dy2 = dy1;
  };

  x = x1; y = y1;
  cnt = m+1;
  while (cnt--) {
    if ((y >= 0) && (y <= 199)) {
      if (x < scantab[y][0]) scantab[y][0] = x;
      if (x > scantab[y][1]) scantab[y][1] = x;
    };
    k += n;
    if (k < m) {
      x += dx2;
      y += dy2;
    }
    else {
      k -= m;
      x += dx1;
      y += dy1;
    };
  };
}

void scanpoly (int x1, int y1, int x2, int y2,
               int x3, int y3, int x4, int y4) {
  register int i;
  
  for (i=0; i<=199; i++) {
    scantab[i][0] = 32767;		// init min
    scantab[i][1] = -32767;		// init max
  };

  ymin = y1;
  if (y2 < ymin) ymin = y2;
  if (y3 < ymin) ymin = y3;
  if (y4 < ymin) ymin = y4;
  ymax = y1;
  if (y2 > ymax) ymax = y2;
  if (y3 > ymax) ymax = y3;
  if (y4 > ymax) ymax = y4;

  scanline (x1, y1, x2, y2);
  scanline (x2, y2, x3, y3);
  scanline (x3, y3, x4, y4);
  scanline (x4, y4, x1, y1);
}

void tmap (VECTOR *P, VECTOR *M, VECTOR *N, char *texture) {
  VECTOR PM, NP, MN;
  int x1, y1, x2, y2, x3, y3, x4, y4, x, y, i, j, xl, xr, cnt, yoffs, xoffs;
  int delta, deltau, deltav, u, v, ds, dus, dvs, dj, duj, dvj;
  char color;
  int z, zz;

  vector_mul (P, M, &PM);
  vector_mul (N, P, &NP);
  vector_mul (M, N, &MN);

  x1 = (P->x << 8) / P->z;
  y1 = (P->y << 8) / P->z;
  x2 = ((P->x+M->x) << 8) / (P->z+M->z);
  y2 = ((P->y+M->y) << 8) / (P->z+M->z);
  x3 = ((P->x+M->x+N->x) << 8) / (P->z+M->z+N->z);
  y3 = ((P->y+M->y+N->y) << 8) / (P->z+M->z+N->z);
  x4 = ((P->x+N->x) << 8) / (P->z+N->z);
  y4 = ((P->y+N->y) << 8) / (P->z+N->z);

  scanpoly (x1+160, y1+100, x2+160, y2+100,
            x3+160, y3+100, x4+160, y4+100);

  if ((ymin>199) || (ymax<0)) return;
  if (ymin < 0) ymin = 0;
  if (ymax > 199) ymax = 199;

  j = (ymin-100);
  dj = MN.y;
  duj = NP.y;
  dvj = PM.y;
  ds = (MN.z<<8) + j*dj;
  dus = (NP.z<<8) + j*duj;
  dvs = (PM.z<<8) + j*dvj;
  yoffs = (ymin<<8) + (ymin<<6) + (int)vscr;

  for (y=ymin; y<=ymax; y++) {
    i = scantab[y][0]-160;
    delta  = (ds + i*MN.x);
    deltau = (dus + i*NP.x);
    deltav = (dvs + i*PM.x);
    ds += dj;
    dus += duj;
    dvs += dvj;
    if ((xl=i+160) < 0) xl=0;
    if ((xr=scantab[y][1]) > 319) xr=319;
    xoffs = xl;
    cnt = xr-xl+1;
    while (cnt--) {
      u = (deltau<<6) / delta;
      v = (deltav<<6) / delta;
      if (u < 0) u = 0;
      else if (u > 63) u = 63;
      if (v < 0) v = 0;
      else if (v > 63) v = 63;
      color = texture[(v<<6)+u];
/*
      _asm{
        mov   ebx, yoffs
        add   ebx, xoffs
        mov   ax, word ptr color
        mov   [ebx], ax
      };
*/
      memset((char*)yoffs+xoffs, color, 2);
      delta  += MN.x;
      deltau += NP.x;
      deltav += PM.x;
      xoffs++;
    };
    yoffs += 320;
  };
}

void rotate_vector_x (int no, int angle) {
  VECTOR v;
  v.y = (verts[no].y * costab[angle]  +  verts[no].z * sintab[angle]);
  v.z = (verts[no].z * costab[angle]  -  verts[no].y * sintab[angle]);
  v.x = verts[no].x;
  v.y = v.y >> fixpf;
  v.z = v.z >> fixpf;
/*
  _asm{
    sar   dword ptr v+4, fixpf
    sar   dword ptr v+8, fixpf
  };
*/
  verts[no] = v;
}
void rotate_vector_y (int no, int angle) {
  VECTOR v;
  v.z = (verts[no].z * costab[angle]  +  verts[no].x * sintab[angle]);
  v.x = (verts[no].x * costab[angle]  -  verts[no].z * sintab[angle]);
  v.y = verts[no].y;
  v.z = v.z >> fixpf;
  v.x = v.x >> fixpf;
/*
  _asm{
    sar   dword ptr v+8, fixpf
    sar   dword ptr v+0, fixpf
  };
*/
  verts[no] = v;
}
void rotate_vector_z (int no, int angle) {
  VECTOR v;
  v.x = (verts[no].x * costab[angle]  +  verts[no].y * sintab[angle]);
  v.y = (verts[no].y * costab[angle]  -  verts[no].x * sintab[angle]);
  v.z = verts[no].z;
  v.x = v.x >> fixpf;
  v.y = v.y >> fixpf;
/*
  _asm{
    sar   dword ptr v+0, fixpf
    sar   dword ptr v+4, fixpf
  };
*/
  verts[no] = v;
}

void rotate_cube (int anglex, int angley, int anglez) {
  int i;

  for (i=0;i<8;i++) {
    verts[i] = cverts[i];
    rotate_vector_x (i, anglex);
    rotate_vector_y (i, angley);
    rotate_vector_z (i, anglez);
    verts[i].z += Dist;
  };
}

void vector_sub (VECTOR *a, VECTOR *b, VECTOR *c) {
  c->x = a->x - b->x;
  c->y = a->y - b->y;
  c->z = a->z - b->z;
}

void draw_cube (char *texture) {
  int dist[6], order[6];
  int i, j, m, t;
  VECTOR P, M, N, Normal;

  for (i=0;i<6;i++) {
    order[i] = i;
    dist[i] = (verts[polys[i][3]].z + verts[polys[i][1]].z) / 2;
  };

  for (i=0; i<5; i++) {                         // face deth sorting
    for (j=m=i; j<6; j++) {
      if (dist[j] > dist[m]) m = j;
    };
    if (dist[i] < dist[m]) {
      t = order[i]; order[i] = order[m]; order[m] = t;
      t = dist[i]; dist[i] = dist[m]; dist[m] = t;
    };
  };

  for (i=0;i<6;i++) {
    j = order[i];
    P = verts[polys[j][0]];
    vector_sub (&verts[polys[j][1]], &verts[polys[j][0]], &M);
    vector_sub (&verts[polys[j][3]], &verts[polys[j][0]], &N);
    vector_mul (&M, &N, &Normal);
    if (Normal.z > 0)                           // hidden face removing
      tmap (&P, &M, &N, texture);
  };
}

int biostime() {
  int *counter = (int *) 0x46C;
  return *counter;
}

void main() {
  char *texture1, *texture2, *palette;
  int t1size, t2size, psize;
  int xa=0, ya=0, za=0;
  char key=0xFF;
  int t0, t1, frames=0;

  texture1 = loadfile ("TEXTURE1.DAT", &t1size);
  if (!texture1) {
    printf ("Unable to open TEXTURE1.DAT file.\n");
    return;
  };
  texture2 = loadfile ("TEXTURE2.DAT", &t2size);
  if (!texture2) {
    printf ("Unable to open TEXTURE2.DAT file.\n");
    free (texture1);
    return;
  };
  palette = loadfile ("PALETTE.DAT", &psize);
  if (!palette) {
    printf ("Unable to open PALETTE.DAT file.\n");
    free (texture1);
    free (texture2);
    return;
  };

  if (!(vscr=malloc(320*200))) {
    printf ("Unable to allocate 64K for a virtual screen.\n");
    free (texture1);
    free (texture1);
    free (palette);
    return;
  };

  compute_tables();
  initgraph();
  setpal (palette);

  t1 = t0 = biostime();
  while (1) {
    if (kbhit() && ((key=getch())==27)) break;
/*    
    _asm{
      mov   edi, vscr
      mov   ecx, 16000
      xor   eax, eax
      cld
      rep   stosd
    };
*/
    memset(vscr, 0, 64000);
    rotate_cube (xa, ya, za);
    draw_cube (texture1);
/*
    _asm{
      mov   edi, 0xA0000
      mov   esi, vscr
      mov   ecx, 16000
      cld
      rep   movsd
    };
*/
    memcpy((char*)0xA0000, vscr, 64000);
    xa=(xa+2)%360;
    ya=(ya+4)%360;
    za=(za+6)%360;
    if (t1-t0 < 18*5*60) {			// average at 5 min
      t1 = biostime();
      frames++;
    }
  };
  while (kbhit()) getch();

  closegraph();
  printf ("%d fps\n", frames*18/(t1-t0));
  free (texture1);
  free (texture2);
  free (palette);
  free (vscr);
}
