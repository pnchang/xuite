#linux
gcc -no-pie -DSDL -Wall -O2 -ffast-math `sdl2-config --cflags` -o zbufg  zbuf.c   `sdl2-config --libs` -lm -lstdc++
