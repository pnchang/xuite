
#define Screen_Width    640
#define Screen_Height   480
#define Center_X        (Screen_Width/2)
#define Center_Y        (Screen_Height/2)

#define BLACK      0
#define BLUE       1
#define GREEN      2
#define CYAN       3
#define RED        4
#define MAGENTA    5
#define BROWN      6
#define LGRAY      7
#define GRAY       8
#define LBLUE      9
#define LGREEN    10
#define LCYAN     11
#define LRED      12
#define LMAGENTA  13
#define YELLOW    14
#define WHITE     15

#define y2addr(y)       (Screen_Width*y)

// Pointer to the screen buffer. By default it equals VGA constant
extern char VGAAddr[];

int _scanbuf[Screen_Height][2];

void initgraph() {
// INT 10H 00H: Set Video Mode 
}

void closegraph() {
// INT 10H 00H: Set Video Mode 
}

void putpixel (int x, int y, char c) {
    *(VGAAddr+x+y2addr(y)) = c;
}

void line (int x1, int y1, int x2, int y2, char color) {
  int sx, sy, dx1, dy1, dx2, dy2, x, y, m, n, k=0, cnt;

  sx = x2-x1;
  sy = y2-y1;

  if (sx > 0) dx1 = 1;
  else if (sx < 0) dx1 = -1;
  else dy1 = 0;

  if (sy > 0) dy1 = 1;
  else if (sy < 0) dy1 = -1;
  else dy1 = 0;

  m = abs (sx);
  n = abs (sy);

  dx2 = dx1;
  dy2 = 0;

  if (m < n) {
    m = abs (sy);
    n = abs (sx);
    dx2 = 0;
    dy2 = dy1;
  };

  x = x1; y = y1;
  cnt = m+1;
  while (cnt--) {
    putpixel (x, y, color);
    k += n;
    if (k < m) {
      x += dx2;
      y += dy2;
    }
    else {
      k -= m;
      x += dx1;
      y += dy1;
    };
  };
}

/* K&R function declaration is obsolete */
void _scanline (int x1, int y1, int x2, int y2)
{
  int sx, sy, dx1, dy1, dx2, dy2, x, y, m, n, k=0, cnt;

  sx = x2-x1;
  sy = y2-y1;

  if (sx > 0) dx1 = 1;
  else if (sx < 0) dx1 = -1;
  else dy1 = 0;

  if (sy > 0) dy1 = 1;
  else if (sy < 0) dy1 = -1;
  else dy1 = 0;

  m = abs (sx);
  n = abs (sy);

  dx2 = dx1;
  dy2 = 0;

  if (m < n) {
    m = abs (sy);
    n = abs (sx);
    dx2 = 0;
    dy2 = dy1;
  };

  x = x1; y = y1;
  cnt = m+1;
  while (cnt--) {
    if ((y >= 0) && (y < Screen_Height)) {
      if (_scanbuf[y][0] > x) _scanbuf[y][0] = x;
      if (_scanbuf[y][1] < x) _scanbuf[y][1] = x;
    };
    k += n;
    if (k < m) {
      x += dx2;
      y += dy2;
    }
    else {
      k -= m;
      x += dx1;
      y += dy1;
    };
  };
}

void fillpoly (int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4, char color)
{
  int i, ymin, ymax, xl, xr;
  
  ymin = ymax = y1;
  if (ymin > y2) ymin = y2;
  if (ymin > y3) ymin = y3;
  if (ymin > y4) ymin = y4;
  if (ymax < y2) ymax = y2;
  if (ymax < y3) ymax = y3;
  if (ymax < y4) ymax = y4;

  if (ymin < 0) ymin = 0;
  if (ymax > Screen_Height-1) ymax = 0;
  if ((ymin > Screen_Height-1) || (ymax < 0)) return;

  for (i=0;i<Screen_Height;i++) {
    _scanbuf[i][0] = Screen_Width;
    _scanbuf[i][1] = -1;
  };
  _scanline (x1, y1, x2, y2);
  _scanline (x2, y2, x3, y3);
  _scanline (x3, y3, x4, y4);
  _scanline (x4, y4, x1, y1);

  for (i=ymin;i<=ymax;i++) {
    if ((xl = _scanbuf[i][0]) < 0) xl = 0;
    if ((xr = _scanbuf[i][1]) > Screen_Width-1) xr = Screen_Width-1;
    if ((xl > Screen_Width-1) || (xr < 0)) continue;
    line (xl, i, xr, i, color);
  };
}

void setpal (char *pal) {
// SET 256 3 primary colors PALETTE REGISTERS 
}
