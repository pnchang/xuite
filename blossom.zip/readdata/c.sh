# MinGW  
#export DXDIR='/C/Program Files (x86)/Microsoft DirectX SDK (June 2010)/'
gcc -fno-exceptions -fpermissive -static -D"MINGW"  -o READDATG.exe READDAT.CPP -lstdc++  