# MinGW  
export ZLIBDIR='./'
gcc -fpack-struct=1 -fno-exceptions -fpermissive -static -D"__STDC_LIMIT_MACROS" -D"MINGW" -I"$ZLIBDIR" -L"$ZLIBDIR" -o READDATG.exe  IMAGE.CPP READDAT.CPP  -lstdc++  