struct pmw1_header
{
	uint32_t id;                  // 0x31574D50 'PMW1'
	uint16_t version;             // Version Number Lo=Major, Hi=Minor
	uint16_t flags;               // Info Flags
	uint32_t cs_eip_object;       // Initial CS:EIP Object
	uint32_t cs_eip_offset;       // Initial CS:EIP Offset
	uint32_t ss_esp_object;       // Initial SS:ESP Object
	uint32_t ss_esp_offset;       // Initial SS:ESP Offset
	uint32_t objtbl_offset;       // Object Table Offset
	uint32_t objtbl_entries;      // Object Table Entries
	uint32_t rt_offset;           // Relocation Table Offset (RT)
	uint32_t data_offset;         // Data Pages Offset
}pmw1header;

struct pmw1_objtbl
{
	uint32_t virtualsize;         // Virtual Size Of Object
	uint32_t actualsize;          // Actual Size Of Object On Disk
	uint32_t flags;               // Object Flags
	uint32_t rt_offset;           // Beginning Offset From The Start Of RT
	uint32_t rt_blocks;           // Number Of Relocation Blocks
	uint32_t uactualsize;         // Uncompressed Actual Size
}pmw1objtbl[50];

struct pmw1_rtitem
{
	uint8_t type;                 // Relocation Type
	int32_t sourceoff;            // Source Offset
	uint8_t targetobj;            // Target Object
	int32_t targetoff;            // Target Offset
}pmw1rtitem;

struct pmw1_rtblock
{
	uint16_t size;
	uint16_t usize;
}pmw1rtblock;
