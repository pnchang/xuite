
/* 
Portable Executable for Window

*/
#include <stdint.h>	/* standard integer */
#include "pe.h"	/* PE.H */

/*
Do PE File(s)
Portable Executable Module
BufBase: should be a size of DOS extender.
EXESize: size of DOS extender and portable executable.
*/
int32_t DoPE(char *FileName, uint8_t *Buf, uint32_t BufBase, uint32_t BufSize, uint32_t *EXESize)
{
	int32_t	Status = -1;
	char	Filename[128];
	uint32_t	Base, Offset, Size;	
	uint32_t	numData;	// number of Data 
	uint32_t	sizeEXE;	// Size of All Executable Files
	IMAGE_NT_HEADERS32	*NTHeaders;
	IMAGE_SECTION_HEADER	*SectionHeader;
	int32_t	i;	
	
	sizeEXE = BufBase;	// size of DOS extender
	Offset = BufBase;	// 
	Size = sizeof(IMAGE_NT_HEADERS32);
	NTHeaders = (IMAGE_NT_HEADERS32*)(Buf+Offset);	
	if (NTHeaders->Signature==IMAGE_NT_SIGNATURE)
	{
		uint8_t	*p;
		
#if (DBG&0x02)
		printf("\tPE %08x %08x %08x %08x\n", Offset, sizeof(IMAGE_NT_HEADERS32), sizeof(IMAGE_FILE_HEADER), sizeof(IMAGE_OPTIONAL_HEADER32));
		printf("\t%04x %04x %08x %08x %08x %04x %04x\n", 
			NTHeaders->FileHeader.Machine, NTHeaders->FileHeader.NumberOfSections, 
			NTHeaders->FileHeader.TimeDateStamp, NTHeaders->FileHeader.PointerToSymbolTable, NTHeaders->FileHeader.NumberOfSymbols, 
			NTHeaders->FileHeader.SizeOfOptionalHeader, NTHeaders->FileHeader.Characteristics);
		printf("\t %04x %2d.%d %08x\n",
			NTHeaders->OptionalHeader.Magic, NTHeaders->OptionalHeader.MajorLinkerVersion, NTHeaders->OptionalHeader.MinorLinkerVersion,
			NTHeaders->OptionalHeader.SizeOfCode);
#endif 	

		Offset = Offset+Size;
		Size = sizeof(IMAGE_SECTION_HEADER);
		numData = NTHeaders->FileHeader.NumberOfSections;
//		printf("\t%08x %08x\n", Offset, numData*Size);
		for(i=0;i<numData;i++)
		{
			uint32_t	EntryOffset;
			
			EntryOffset = Offset;
			SectionHeader = (IMAGE_SECTION_HEADER*)(Buf+Offset);
			Offset = Offset+Size;	// Next Section Header
#if 0
			sprintf(Filename, "%08x.BIN", Offset);
			Status = WriteBFile(Filename, p, Size);	// write out the data directory.			
#endif
#if (DBG&0x02)
			printf("\t%2d %08x %8s  %08x %08x %08x\n", i, EntryOffset, SectionHeader->Name, 
				SectionHeader->SizeOfRawData, SectionHeader->PointerToRawData, (SectionHeader->PointerToRawData+SectionHeader->SizeOfRawData));
#endif			
			sizeEXE = SectionHeader->PointerToRawData+SectionHeader->SizeOfRawData;	
		}
		printf(" %08x %08x\t", Offset, sizeEXE);
		*EXESize = sizeEXE;
		
		Status = 0;
	}
		
	return	Status;
}
