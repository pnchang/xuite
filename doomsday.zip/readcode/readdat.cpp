/*
1997\d\dsd_wish  I Wish I Was A Skijumper
1997\b\boostfin
doomsday\dsd_boost_win
doomsday\dsd_elektron_win
doomsday\dsd_i_wish_win
doomsday\dsd_juhla5_win
doomsday\dsd_lotto_win
doomsday\dsd_off_win
doomsday\dsd_shingles_win
doomsday\dsd_stigma_win
Doomsday
Finland
*/
#include <stdio.h>
#include <stdlib.h>	/* free() */
#include <string.h>	/* strrchr() */
#include <memory.h>
#ifdef __GNUC__
#include <sys/types.h>
#include <sys/stat.h>	/* mkdir() */
#endif
#ifdef _MSC_VER
#include <direct.h>	/* _mkdir() */
#endif
#include <stdint.h>	/* standard integer */

#include "common.h"
#include "image.h"	/* image */
//#include "zlib.h"	/* uncompress() */

#define	DBG		0x0000
#ifndef	UINT32_MAX
#define UINT32_MAX  4294967295UL
#endif 

#ifndef	MAX_PATH
#define	MAX_PATH	256
#endif

// Limitation
#define	RAWSIZE		8*1024*1024


#pragma pack(push)	/* push current alignment to stack */
#pragma pack(1)	/* set alignment to 1 byte boundary */

/*
36 bytes Length Data Information Header 
in little endian
*/
typedef	struct _infoHeader{
	uint8_t	Name[16];	// FPFS 0000 -MRI-.
	uint32_t	x;	//
	uint32_t	Offset;	// Offset of Driectory
	uint32_t	Size;	// Size of Data and Directory
	uint32_t	Number;	// Number of Data
	uint32_t	Type;	// Uncompressed(0)/Compressed(1)
} infoHeader;
/*
72 bytes Length Directory Entry 
64 bytes filename, 4 bytes Offset and 4 bytes type.
*/
typedef	struct _directoryEntry{	
	uint8_t	Name[64];	// Name
	uint32_t	Offset;	// Offset of Compressed Data
	uint32_t	Type;	// Data Type
} directoryEntry;
/*
8 bytes Length Data Header 
 4 bytes compressed Size and 4 bytes Size of Uncompressed Data
*/
typedef	struct _dataHeader{
	uint32_t	compressedSize;	// Size of Compressed Data
	uint32_t	Size;	// Size of Data
} dataHeader;


typedef	struct _pixInfo{
	uint32_t	Base;
	uint32_t	Offset;
	uint32_t	Size;
	uint16_t	Width;
	uint16_t	Height;
	uint8_t	Plane;
	uint8_t	PaletteInfoNo;
} pixInfo;


typedef	struct _paletteInfo{
	uint32_t	Base;
	uint32_t	Offset;
	uint32_t	Size;
	uint8_t	ColorNo;
} paletteInfo;

/* 8-byte length */
typedef	struct _pixHeader{
	uint16_t	Width;
	uint16_t	Height;
	uint8_t	u[4];
} pixHeader;

/* Program segmentation */
typedef	struct _programInfo{
	uint32_t	Offset;
	uint32_t	Size;
} programInfo;	

#pragma pack(pop)	/* restore original alignment from stack */

/*
Pix File
W definition:
0: Header of Pix 
otherwise, it is a width of picture
Palette: 256 colors * 3 channels RGB
*/
int32_t PixFile(char *FileName, uint8_t *Buf, uint32_t BufSize, uint16_t W, uint8_t *Palette)
{
	int32_t	Status=-1;
	char	Filename[1024];

	uint32_t	Base, Offset, Size;
	uint8_t		*Pix;
	uint32_t	PixSize;
	uint16_t	Width, Height, Plane;	
	uint32_t	PaletteOfs, PaletteSize;
	pixHeader	PixHeader;	
	//RIX_HEAD	RIXHeader;
	raw_file	RawPix;	

	if (W)
	{
		// By Argument W
		Offset = 0;	// Offset of Pix Data
		Size = 0;	// Size of Pix Header
		PixHeader.Width = W;
		PixHeader.Height = BufSize/PixHeader.Width;		
	}
	else
	{
		// Default
		Offset = 0;	// Offset of Pix Header
		Size = sizeof(pixHeader);	// Size of Pix Header
		memcpy(&PixHeader, Buf, Size);
		Offset = Offset+Size;	// Offset of Pix Data
	}
		Width = PixHeader.Width;
		Height = PixHeader.Height;
		PixSize = Width*Height*1;

				Pix = Buf+Offset;				
				RawPix.w = Width;
				RawPix.h = Height;
				RawPix.c = 256;
				RawPix.bpp = 8;
				RawPix.bpc = 6;
				RawPix.palette = Palette;
				RawPix.bitmap = Pix;
		
				sprintf(Filename, "%s.TGA", FileName);	
				printf("\t %12s: %08x %08x %6d x %6d %6d colors" , Filename, Offset, Size, RawPix.w, RawPix.h, RawPix.c);

					WriteTGAFile(Filename, &RawPix);	
					printf("\n");

					
	return	Status;	
}

#include "lzssdec.c"

/*
Data in Executable File
*/
int32_t Data(uint8_t *Buf, uint32_t BufBase, uint32_t BufSize, uint32_t EXESize)
{
	int32_t	Status=-1;
	char	Filename[128];
	char	DstFilename[128];
	uint8_t	Maximum;
	int32_t	i;
	uint8_t	*p;
	uint32_t	Base, Offset, Size;
	infoHeader	*InfoHeader;
	directoryEntry	*de;
	uint32_t	DirectoryOffset, DirectorySize;
	uint16_t	numData;	// number of Data
	uint32_t	DataBase, DataOffset, DataSize;
	uint32_t	DataType;
	uint32_t	cSize, dSize;	// compressed/ decompressed data
	uint16_t	numPix;	// number of Picture
	uint8_t		*Pix;	
	uint16_t	Width, Height, Plane;
	uint32_t	PlaneSize;
	uint16_t	numPlane;
	uint32_t	Length;
	uint32_t	RAWSize;
	uint8_t	Palette[256*3];
	uint32_t PaletteOffset, PaletteSize;	
	//RIX_HEAD	RIXHeader;
	raw_file	RawPix;
	uint8_t	Tag[32];

// EXE
	programInfo	ProgramInfoTable[]={
			{ 0x00000000, 0x00003500},	// Seg000 CODE
		};

	uint32_t	DataSizeTable[]={
			0x000300,
		};
	

		// Initialize
		Base = BufBase;	// DOS Header Size
		Offset = EXESize;	// Offset of Data
		Size = sizeof(infoHeader);
		InfoHeader = (infoHeader*)(Buf+Offset);
		sprintf((char*)Tag,"FPFS %04d -MRI-\32", 0);	// 16 bytes length name 
		Status = memcmp(InfoHeader->Name, Tag, 16);
		if (Status==0)
		{
			DataBase  = Offset;	// Offset of Data
			Offset = DataBase+InfoHeader->Offset;	// Offset of Compressed Directory
			DirectoryOffset = Offset;
			DirectorySize = InfoHeader->Size-InfoHeader->Offset;	// Size of Compressed Directory 
			numData = InfoHeader->Number;
			DataType = InfoHeader->Type;
			switch (DataType)
			{
				case 0:
					// No compressed
					dSize = numData*sizeof(directoryEntry);
					cSize = dSize;
					break;
				case 1:
					// LZSS
					Size = sizeof(uint32_t);
					cSize = *(uint32_t*)(Buf+Offset);	// Size of Compressed Directory
					Offset = Offset+Size;
					dSize = *(uint32_t*)(Buf+Offset);	// Size of Uncompressed Directory
					Offset = Offset+Size;	// Offset of Compressed Directory
				
			}
			printf("%6x %08x %08x %08x %04x  %08x %08x\t", numData, DataBase, DirectoryOffset, DirectorySize, DataType, cSize, dSize);
			p = new uint8_t[dSize];
			if (p)
			{
				if (DataType==1)
				{
					// LZSS
					LZSSDecode(Buf+Offset, cSize-8, p, &Size);
					if (dSize!=Size);
						printf("%08x\t", Size);
				}
				if (DataType==0)
					memcpy(p, Buf+Offset, dSize);
				
#if 0			
				sprintf(Filename,"%02d.BIN", 0);
				Status = WriteBFile(Filename, p, dSize);	// write data to a binary file.
#endif			
				printf("\n");
				Offset = 0;
				Size = sizeof(directoryEntry);
				for(i=0;i<numData;i++)
				{
					uint32_t	n, EntryOffset, cSize=0, dSize;
					directoryEntry	*de;
					dataHeader	*dh;
					uint8_t	*data;
					
					EntryOffset = Offset;
					de = (directoryEntry*)(p+Offset);
					Offset = Offset+sizeof(directoryEntry);	// Offset of Next Directory Entry
					n=sprintf(Filename,"%s", de->Name);
					Filename[n] = '\0';	// Null terminator
					DataType = de->Type;
					DataOffset = DataBase+de->Offset;	//
					if (DataType==0)
					{
						directoryEntry*	de2;
						if (i<numData-1)
						{
							de2 = (directoryEntry*)(p+Offset);
							cSize = de2->Offset-DataOffset;
						}
						else
						{
							cSize = DirectoryOffset-DataOffset;
						}
						dSize = cSize;
						DataSize = dSize;
					}
					if (DataType==1)
					{
						dh = (dataHeader*)(Buf+DataOffset);
						cSize = dh->compressedSize;	// 4 bytes length Size of Compressed Data					
						dSize = dh->Size;	// 4 bytes length Size of Decompressed Data
						DataOffset = DataOffset+sizeof(dataHeader);	// Offset of Compressed Data
						DataSize = dSize;
					}
					printf("\t%3d %08x %48s %08x %04x %08x %08x %08x %08x \t", i, EntryOffset, Filename, de->Offset, DataType, cSize, DataSize, DataOffset, (DataOffset+cSize-8));
					
					data = new uint8_t[dSize];
					if (data)
					{
						if (DataType==1)
						{
							// LZSS
							LZSSDecode(Buf+DataOffset, cSize-8, data, &dSize);
							if (DataSize!=dSize)
								printf("%08x\t", dSize);
						}
						if (DataType==0)
						{
							// No Compressed Data
							memcpy(data, Buf+DataOffset, dSize);
						}
						Status = MakeDir(Filename);
						Status = WriteBFile(Filename, data, DataSize);	// write data to a binary file.
						delete	data;
					}
					printf("\n");
					
				};
				printf(" number of data: %3d\n", numData);
				
				delete	p;
			}
			
			Status = 0;
		}
		

	return	Status;
}

/*
Do Executable File(s)
BufBase: should be 0.
EXEBase: start address of code
EXESize: size of all executable files
*/
int32_t DoEXE(char *FileName, uint8_t *Buf, uint32_t BufBase, uint32_t BufSize, uint32_t *EXEBase, uint32_t *EXESize)
{
	int32_t	Status;
	char	Filename[128];
	uint32_t	Base, Offset, Size;	
	uint32_t	numEXE;	// number of EXE Files	
	uint32_t	sizeEXE;	// Size of All Executable Files
	IMAGE_DOS_HEADER *ImageDOSHeader;
	
	// Initialize
	Status = -1;
		*EXEBase = 0;	// zero code base
		
		numEXE	=0;
		sizeEXE	= 0;		
		Offset = BufBase;	// Start Address of Buffer
		ImageDOSHeader = (IMAGE_DOS_HEADER*)(Buf+Offset);
			// Check Signature 'MZ' 
			while ((*ImageDOSHeader).e_magic==IMAGE_DOS_SIGNATURE)
			{
				Base = (ImageDOSHeader->e_cparhdr)<<4;	// Base of CODE
				if (numEXE==0)	*EXEBase = Base;	// get Address of Code in First Executable File
				Size = ImageDOSHeader->e_cblp;
				if (Size)	Size = 512-Size;	// n bytes left on last page
				Size = (ImageDOSHeader->e_cp)*512-Size;
				printf("\t%3d  %08x %08x\t", numEXE, Offset, Size);
				sprintf(Filename, "%s%02d.EXE", FileName, numEXE);
				Status = WriteBFile(Filename, Buf+Offset, Size);	// write out the execute file.
				printf("\n");
				// if it is a pack execute file, crunch it. 
				Offset = Offset+Size;
				numEXE++;
				if (Offset>=BufSize)	break;	//	Excess 
				ImageDOSHeader = (IMAGE_DOS_HEADER*)(Buf+Offset);
			}
		
		if (numEXE)
		{
			// Find Executable File(s)
			*EXESize = Offset;
			printf("\t%3d  %08x %08x\n", numEXE, *EXEBase, *EXESize);
			Status = 0;
		}
		
	return	Status;
}

// little endian
#define	LIB_	0x3A42494C

/*
Do Data File(s)
*/
int32_t DoDATA(uint8_t *Buf, uint32_t BufSize)
{
	int32_t	Status=-1;
	char	Filename[128];	
	uint32_t	Base, Offset, Size;	
	uint32_t	numData;	// number of Data Files	
	uint32_t	i, k;
	uint8_t	*p;
	infoHeader	*InfoHeader;
	uint32_t	DirectoryOffset, DirectorySize;
	uint32_t	DataBase, DataOffset, DataSize;
	uint32_t	DataType;
	uint32_t	cSize, dSize;	// compressed/ decompressed data
	
	
		Offset = 0;	// the Offset of Data from the begin of file
		Size = sizeof(uint32_t);

	
	return	Status;
}
#include "pmw.c"
#include "pe.c"

/* main program */
int main(int argc, char* argv[])
{
	FILE	*hFile;
	char	Filename[MAX_PATH];
	uint32_t	FileBase;
	uint32_t	FileOffset;
	uint32_t	numRead, numWritten;
	uint32_t	Base, Size, Offset;	
	uint32_t	Status;
	uint8_t	*CODEBuf = NULL;	// pointer of CODE Buffer
	uint8_t	*DATABuf = NULL;	// pointer of DATA Buffer

	if (argc==2)
	{
		strcpy(Filename, argv[1]);
	}
	else
	{
		printf("Syntax: %s FILENAME.EXE \n", argv[0]);
		return	-1;	
	}

	FileOffset = 0L;
	numRead = UINT32_MAX;	// Maximum value
	Status = ReadBFile( Filename, FileOffset, &CODEBuf, &numRead);	// Read CODE File
	if (Status==0)
	{
		char	PathName[4096];
		char	FileName[2048];
		char	FileNameExtension[1024];
		char	*p;
		uint32_t	Signature;		
		uint32_t	Length;
		
		PathName[0]='\0';	// NULL character
		Length = sizeof(PathName);
		Status = GetPathName(Filename, PathName, &Length);
		if (Status==0)
		{
			// Path
			printf("%s %4d  ", PathName, Length);
		}
		sprintf(FileName, "%s", Filename+Length);	// Filename
		FileNameExtension[0]='\0';	// Null terminator 
		p = strchr(FileName, '.');	
		if (p)
		{
			// Filename extension 
			sprintf(FileNameExtension,"%s", p+1);
			*p='\0';	// Null terminator
		}
		printf("%s%s.%s\t%08x %12d(%08x)\n", PathName, FileName, FileNameExtension, FileOffset, numRead, numRead);
			Base = 0;
			Offset = 0;
			Size = 0;
			Status = DoEXE(FileName, CODEBuf, Offset, numRead, &Base, &Size);
			if (Status==0)
			{
				uint32_t	EXESize=-1;	// Size of executable
				Signature = *(uint32_t*)(CODEBuf+Size);
				// 4-byte Length
				switch	(Signature)
				{
					case PMW1_SIGNATURE:
						Status = DoPMW(FileName, CODEBuf, Size, numRead, &EXESize);
						break;
				}
				Offset = *(uint32_t*)(CODEBuf+0x3C);	// Offset of PE Header
				Signature = *(uint32_t*)(CODEBuf+Offset);
				switch	(Signature)
				{
					case IMAGE_NT_SIGNATURE:
						Status = DoPE(FileName, CODEBuf, Offset, numRead, &EXESize);					
					break;
				}
				if (Status==0)
				{
					printf("%08x\t", EXESize);
#if 1
					sprintf(Filename, "%s%1d.EXE", FileName, 1);
					Status = WriteBFile(Filename, CODEBuf, EXESize);	// write out the execute file.
#endif
					printf("\n");
				}
				Status = Data(CODEBuf, Base, numRead, EXESize);
			}
			else
			{
				Status = DoDATA(CODEBuf, numRead);
			}
/*			
			// .DAT File
			sprintf(Filename,"%s%s.DAT", PathName, "IRPARP");
			FileOffset = 0L;
			numRead = UINT32_MAX;	// Maximum value
			Status = ReadBFile( Filename, FileOffset, &DATABuf, &numRead);	// Read CODE File
			if (Status==0)
			{
				printf("%s\t%08x %12d(%08x)\n", Filename, FileOffset, numRead, numRead);
				Status = DoDATA(DATABuf, numRead);
				free(DATABuf);	// free memory
			}
*/			
				
		free(CODEBuf);	// free memory
	}
	
	
	return	Status;
}

	
