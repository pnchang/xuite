/*
	LZSS.C -- A Data Compression Program
	4/6/1989 Haruhiko Okumura
https://oku.edu.mie-u.ac.jp/~okumura/compression/1988.html
https://oku.edu.mie-u.ac.jp/~okumura/compression/lzss.c	
*/

#include <stdint.h>	/* standard integer */

#define N		 4096	/* size of ring buffer */
#define F		   18	/* upper limit for match_length */
#define THRESHOLD	2   /* encode string into position and length
						   if match_length is greater than this */
#define NIL			N	/* index for root of binary search trees */

uint8_t
		text_buf[N + F - 1];	/* ring buffer of size N,
			with extra F-1 bytes to facilitate string comparison */

void LZSSDecode(uint8_t *inBuf, uint32_t inBufSize, uint8_t *outBuf, uint32_t *outBufSize)	/* Just the reverse of Encode(). */
{
	uint32_t	i, j, k, r, c;
	uint16_t	flags;
	uint32_t	inOffset=0, outOffset=0;	
	
	for (i = 0; i < N - F; i++) text_buf[i] = 0x00;	//' ';
	r = N - F;  flags = 0;
	for ( ; ; ) {
		if (((flags >>= 1) & 256) == 0) {
			c = inBuf[inOffset++];	//getc(infile);
			if (inOffset>inBufSize)	break;
			flags = c | 0xff00;		/* uses higher byte cleverly */
		}							/* to count eight */
		if (flags & 1) {
			c = inBuf[inOffset++];	//getc(infile);
			if (inOffset>inBufSize) break;
			outBuf[outOffset++] = c;	//putc(c, outfile);
			text_buf[r++] = c;  r &= (N - 1);
		} else {
			i = inBuf[inOffset++];	//getc(infile);
			if (inOffset>inBufSize)	break;
			j = inBuf[inOffset++];	//getc(infile);
			if (inOffset>inBufSize)	break;
			i |= ((j & 0xf0) << 4);  j = (j & 0x0f) + THRESHOLD;
			for (k = 0; k <= j; k++) {
				c = text_buf[(i + k) & (N - 1)];
				outBuf[outOffset++] = c;	//putc(c, outfile);
				text_buf[r++] = c;  r &= (N - 1);
			}
		}
	}
	*outBufSize = outOffset;
#if	1
		printf("(%08x %08x)\t", inOffset, outOffset);
#endif
}
