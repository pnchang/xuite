
/* 
PMODE for Watcom C/C++ - v1.33
Charles Scheffold and Thomas Pytel.
pmw133src.zip
http://www.sid6581.net/pmodew/index.html
*/
#include <stdint.h>	/* standard integer */
#include "pmw1.h"	/* PMW1 */

#define PMW1_SIGNATURE	0x31574D50	//PMW1

/*
Do PMW1 File(s)
Linear eXecutable Module
BufBase: should be a size of DOS extender.
EXESize: size of DOS extender and linear executable.
*/
int32_t DoPMW(char *FileName, uint8_t *Buf, uint32_t BufBase, uint32_t BufSize, uint32_t *EXESize)
{
	int32_t	Status = -1;
	char	Filename[128];
	uint32_t	Base, Offset, Size;	
	uint32_t	numData;	// number of Data 
	uint32_t	sizeEXE;	// Size of All Executable Files
	int32_t	i;	
	
	sizeEXE = BufBase;	// size of DOS extender
	Offset = BufBase;	// 
	Size = sizeof(pmw1_header);
	memcpy(&pmw1header, Buf+Offset, Size);	
	if (pmw1header.id==PMW1_SIGNATURE)
	{
		uint8_t	*p;

#if (DBG&0x02)
		printf("\tPMW1 Version %2d.%d  Flags = %04x\n", pmw1header.version&0xff, (pmw1header.version>>8)&0xff, pmw1header.flags);
		printf("\tCS:EIP = %04x:%08x\n", pmw1header.cs_eip_object, pmw1header.cs_eip_offset);
		printf("\tSS:ESP = %04x:%08x\n", pmw1header.ss_esp_object, pmw1header.ss_esp_offset);
		printf("\tObject Table Offset = %08x   Entries = %08x\n", pmw1header.objtbl_offset, pmw1header.objtbl_entries);
		printf("\tRelocation Table Offset = %08x\n", pmw1header.rt_offset);
		printf("\tData Pages Offset = %08x\n", pmw1header.data_offset);
#endif 		
		sizeEXE = sizeEXE+pmw1header.data_offset;
		numData = pmw1header.objtbl_entries;
		Offset = Offset+Size;
		Size = sizeof(pmw1_objtbl)*numData;
		memcpy(&pmw1objtbl, Buf+Offset, Size);
		for(i=0;i<numData;i++)
		{

#if 0
			sprintf(Filename, "%08x.BIN", Offset);
			Status = WriteBFile(Filename, p, Size);	// write out the data directory.			
#endif
#if (DBG&0x02)
			printf("\t%2d VirtualSize=%08x, ActualSize=%08x, UncompressedActualSize=%08x\n", i, pmw1objtbl[i].virtualsize, pmw1objtbl[i].actualsize, pmw1objtbl[i].uactualsize);
#endif			
			sizeEXE = sizeEXE+pmw1objtbl[i].actualsize;	// compressedSize
	
			{
				unsigned int csize;	// size of compressed data
				unsigned int dsize;	// size of decompressed data
				uint16_t crc;
				uint8_t	*buf;	// decompressed data 
				
			}
		
		}
		Offset = Offset+Size;
		printf(" %08x %08x\t", Offset, sizeEXE);
		*EXESize = sizeEXE;
		Status = 0;
	}
		
	return	Status;
}
