// The necessary graphics functions for GSSHAPES.C.
//#include <dos.h>
#include <math.h>

#ifndef RGB
#define RGB(r,g,b)	((r<<0)|(g<<8)|(b<<16))
#endif

typedef unsigned char byte;
typedef struct
{
int X, Y;
} Point;
void PutPixel(unsigned int X, unsigned int Y, unsigned int Colour, unsigned int *FrameBuffer);
void ClearScreen(unsigned int *FrameBuffer);
void Flip64000(unsigned int *Destination, unsigned int *Source);
void GouraudShade(Point Vertices[3], byte Colours[3], unsigned int *FrameBuffer);
void SetVideoMode(int Mode);
void RotatePoint(int X, int Y, int XCenter, int YCenter, float SinAngle, float CosAngle, int *EndX, int *EndY);
void WaitForRetrace(void);
void SetRgbPal(byte Col, byte Red, byte Green, byte Blue);
//unsigned int Segment = 0xA000;
unsigned char	Palette[256][3];

void PutPixel(unsigned int X, unsigned int Y, unsigned int Colour, unsigned int *FrameBuffer)
{
	FrameBuffer[X+Y*FWIDTH]=Colour;
	return;
}

void ClearScreen(unsigned int *FrameBuffer)
{
	memset(FrameBuffer,0x00,FWIDTH*FHEIGHT*sizeof(unsigned int));
	return;
}

void Flip64000(unsigned int *Destination, unsigned int *Source)
{
	memcpy(Destination, Source, FWIDTH*FHEIGHT*sizeof(unsigned int));	
	return;
}

void GouraudShade(Point Vertices[3], byte Colours[3], unsigned int *FrameBuffer)
{ // Not highly optimised, but sufficient.
	byte StartColour, EndColour;
	int MinY = 0, MaxY = 0, Count, ColourIncSign, ColourIncCount, ColourDiff;
	int Y, LineWidth, EndVertex1, EndVertex2, StartVertex1, StartVertex2;
	int XDiff1, XDiff2, YDiff1, YDiff2, X1, X2, ColourDiff1, ColourDiff2;
	int XCalc1 = 0, XCalc2 = 0, ColourCalc1 = 0, ColourCalc2 = 0;

	for(Count = 1; Count < 3; Count++)
	{
		if(Vertices[Count].Y < Vertices[MinY].Y) MinY = Count;
		else if(Vertices[Count].Y > Vertices[MaxY].Y) MaxY = Count;
	}
	StartVertex1 = StartVertex2 = MinY;
	EndVertex1 = MinY + 2;
	if(EndVertex1 >= 3) EndVertex1 -= 3;
	EndVertex2 = MinY + 1;
	if(EndVertex2 >= 3) EndVertex2 -= 3;
	XDiff1 = Vertices[EndVertex1].X - Vertices[StartVertex1].X;
	YDiff1 = Vertices[EndVertex1].Y - Vertices[StartVertex1].Y;
	XDiff2 = Vertices[EndVertex2].X - Vertices[StartVertex1].X;
	YDiff2 = Vertices[EndVertex2].Y - Vertices[StartVertex1].Y;
	ColourDiff1 = Colours[EndVertex1] - Colours[StartVertex1];
	ColourDiff2 = Colours[EndVertex2] - Colours[StartVertex2];
	if(YDiff1 == 0) YDiff1 = 1;
	if(YDiff2 == 0) YDiff2 = 1;
	for(Y = Vertices[MinY].Y; Y <= Vertices[MaxY].Y; Y++)
	{
		X2 = Vertices[StartVertex1].X + XCalc1 / YDiff1;
		XCalc1 += XDiff1;
		X1 = Vertices[StartVertex2].X + XCalc2 / YDiff2;
		XCalc2 += XDiff2;
		EndColour = Colours[StartVertex1] + ColourCalc1 / YDiff1;
		ColourCalc1 += ColourDiff1;
		StartColour = Colours[StartVertex2] + ColourCalc2 / YDiff2;
		ColourCalc2 += ColourDiff2;
		if(EndColour > StartColour) ColourIncSign = 1;
		else ColourIncSign = -1;
		ColourDiff = abs(StartColour - EndColour);
		LineWidth = X2 - X1;
		ColourIncCount = ColourDiff - (LineWidth >> 1);
		for(Count = X1; Count < X2; Count++)
		{
			unsigned int	Colour = RGB(Palette[StartColour][0], Palette[StartColour][1], Palette[StartColour][2]);
			PutPixel(Count, Y, Colour, FrameBuffer);
			while(ColourIncCount >= 0)
			{
				StartColour += ColourIncSign;
				ColourIncCount -= LineWidth;
			}
			ColourIncCount += ColourDiff;
		}
		if(Y == Vertices[EndVertex1].Y)
		{
			StartVertex1 = EndVertex1;
			EndVertex1 = EndVertex2;
			XDiff1 = Vertices[EndVertex1].X - Vertices[StartVertex1].X;
			YDiff1 = Vertices[EndVertex1].Y - Vertices[StartVertex1].Y;
			ColourDiff1 = Colours[EndVertex1] - Colours[StartVertex1];
			if(YDiff1 == 0) YDiff1 = 1;
			XCalc1 = XDiff1;
			ColourCalc1 = ColourDiff1;
		}
		if(Y == Vertices[EndVertex2].Y)
		{
			StartVertex2 = EndVertex2;
			EndVertex2 = EndVertex1;
			XDiff2 = Vertices[EndVertex2].X - Vertices[StartVertex2].X;
			YDiff2 = Vertices[EndVertex2].Y - Vertices[StartVertex2].Y;
			ColourDiff2 = Colours[EndVertex2] - Colours[StartVertex2];
			if(YDiff2 == 0) YDiff2 = 1;
			XCalc2 = XDiff2;
			ColourCalc2 = ColourDiff2;
		}
	}
	return;
}

void SetVideoMode(int Mode)
{

	return;
}

void RotatePoint(int X, int Y, int XCenter, int YCenter, float SinAngle, float CosAngle, int *EndX, int *EndY)
{
	*EndX = (X - XCenter) * CosAngle - (Y - YCenter) * SinAngle + XCenter;
	*EndY = (Y - YCenter) * CosAngle + (X - XCenter) * SinAngle + YCenter;
	return;
}

void WaitForRetrace(void)
{

	return;
}

void SetRgbPal(byte Col, byte Red, byte Green, byte Blue)
{
	Palette[Col][0] = Red<<2;
	Palette[Col][1] = Green<<2;
	Palette[Col][2] = Blue<<2;
	return;
}
