# MinGW  TinyPTC / SDL2 
export SDLDIR='/D/DEMOS/SDL/SDL2-2.0.2-MinGW/i686-w64-mingw32/'
#export PTCDIR='TinyPTC/'
# NASM v2.08.02 
#nasm -o "$PTCDIR""mmx.obj" -f win32  "$PTCDIR""mmx.asm"
gcc -fno-exceptions -D"SDL" -I"./H" -I"$SDLDIR""Include/SDL2" -L"$SDLDIR""lib" -o CGSG.exe  CG.C  -lstdc++ -lm -lmingw32 -lSDL2main -lSDL2 -mwindows 