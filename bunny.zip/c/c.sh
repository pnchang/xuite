# MinGW  
#export DXDIR='/C/Program Files (x86)/Microsoft DirectX SDK (June 2010)/'
gcc -x c -fno-exceptions -static -D"MINGW"  -o LZHUFG.exe  LZHUF.C -lstdc++  
