// ReadDAT.CPP : the console application.
// Open Watcom C/C++32 v1.9


#include <stdio.h>
#include <string.h>	/* strrchr() */
#include <memory.h>
#ifdef __GNUC__
#include <sys/types.h>
#include <sys/stat.h>	/* mkdir() */
#endif
#if defined(_MSC_VER)||defined(MINGW)
#include <direct.h> 	/* _mkdir() */
#endif


#define	DBGLEVEL	0x0000

#define	MAX_PATH	256

#define	s8		char
#define	u8		unsigned char
#define	s16		short
#define	u16		unsigned short
#define s32		int
#define	u32		unsigned int
#define	s64		


FILE	*stream1, *stream2;
char	SrcFilename[MAX_PATH];
char	DstFilename[MAX_PATH];
long	nFileSize;
int	result;

long	DATCount;	// 32 DAT Area
long	DATSize[]={
	12465, 12508, 12446, 12486, 12524, 12533, 12516, 12540,
	12466, 12389, 12329, 12362, 12388, 12403, 12333, 12421,
	16686, 16894, 27688, 13236, 8192, 202350, 247540, 194754,
	204488, 12480, 4408, 6426, 3536, 4818, 8262, 20050
//	229376 // what data of gap
};
long	DATOffset[32+16];


//	Read data from the file unreal
u32 DIRSize;
u8	Directory[512*512];
u8	DATBuf[4*1024*1024];


#pragma pack(push,1)

// FileHeader
/*
FileType
0: uncompress data
1: unknown data
2: DLZ compressed data
3: compressed data
4: unknown data
j: JPEG data
p: PNG data
*/ 
struct _FileHeader{
	u32	OriginalFileSize;
	u32	CompressedFileSize;
	u32	FileNameLength;
	u32	FileDataOffset;
	u32	FileNameOffset;
	u32	NextFileOffset;
	u8	FileType;
} FileHeader;

#pragma pack(pop)

int CountDATOffset()
{
	long	nStatus;
	long	nCount;
	long	nOffset;
	long	nFileOffset;
	int		i;
	
	nStatus	= 0;
	DATCount = sizeof(DATSize)/sizeof(long);

	nCount = DATCount;
	nOffset = 0;	// Default Value
	for(i=0;i<nCount;i++)
	{
		nOffset = nOffset + DATSize[i];
		nFileOffset = nFileSize - nOffset;
		DATOffset[i]= nFileOffset;
		printf("%2d Offset: %08x Size: %08x\n", i, nFileOffset, DATSize[i]);
	}

	// Decode process
	for(i=nFileOffset;i<nFileSize;i++)
	{
		DATBuf[i]=DATBuf[i]^0xA5;
	}
	
	return	nStatus;
}

// Write Data To File
s32 WriteFile(char *FileName, u8 * DATBuf, u32 DATSize)
{
	FILE	*hFile;
	u32	numWritten;
	s32	result=-1;


		hFile = fopen( FileName, "w+b");
		/* Open for write */
		if( hFile == NULL )
		{
			printf( "The file %s was not created\n", FileName);
		}
		else
		{
			numWritten = fwrite( DATBuf, sizeof( char ), DATSize, hFile);

			if (numWritten==DATSize)
				printf( " %10d bytes >>", DATSize);
			
			/* Close stream */
			result = fclose(hFile);
			if( result )
				printf( "The file %s was not closed\n", FileName);
		}

		return	result;
}

/* from backslash to slash */
s32 Path(char *Name)
{
	s32	Status=-1;
	char	*pSlash;
	
		pSlash	= Name;
		do 
		{
			pSlash	= strchr(pSlash,'\\'); 
			if (pSlash)
			{
				*pSlash ='/';
				pSlash++;
			}
			
		}while(pSlash);
	Status = 0;
	
	return	Status;
}

/* main program */
int main(int argc, char* argv[])
{
	u32	Status;
	u32	i;
	u32	numRead, numWritten;
	u32	numFile;
	s8	fileType;
	s8	fileName[64];	// 32 byte filename
	s8	directoryName[64];	// 64 bytes directoryName
	s8	subdirectoryName[64];	// 64 bytes subdirectoryName
	s8	compressedfileName[64];
	u32	nameLength;
	u32	fileOffset;
	u32	fileSize;
	u32	fileOriginalSize;
	u32	fileCompressedSize;
	u32	dataOffset;
	u32	codeSize;
	u32	codeOffset;
	u32	codeBase;
	u32	decodeSize;
	u8	*pCode;
	u8	Key;


	if (argc==2)
	{
		strcpy(SrcFilename, argv[1]);	
	}
	else
	{
		printf("Syntax: %s FILENAME.EXT\n", argv[0]);
		return	-1;	
	}
	
	stream1 = fopen( SrcFilename, "rb");

	/* Open for read (will fail if file does not exist) */
	if( stream1 == NULL )
	{
		printf( "The file %s was not opened\n", SrcFilename);
	}
	else
	{
		nFileSize = -1;	// Default Size
		result	= fseek(stream1, 0L, SEEK_END);	//	SEEK_END End of File
		if (result)
		{
			// Error Handle
		}
		else
		{
			nFileSize = ftell(stream1);
		}

		fileOffset = 0L;	// The Begin of File
		numRead	= sizeof(FileHeader);
		numFile	= 0;
		printf( "The file %s was %d bytes length. Read %d bytes data! %d Files\n" , SrcFilename, nFileSize, numRead, numFile);

		if ( numRead )
		{


				u32	DIRBase;
				s8	*pDirectory;
				u32	EntryOffset	= 0x0000;
				s32	ErrNo;
				
				
				pDirectory = (s8*)Directory;
				//   First - Print filename, Offset, Size
				FileHeader.NextFileOffset = 0;
				do
				{
					// Read Header from file
					fileOffset	= FileHeader.NextFileOffset;
					numRead	= sizeof(FileHeader);
					result	= fseek(stream1, fileOffset, SEEK_SET);	//	SEEK_SET Begin of File
					numRead = fread(&FileHeader, sizeof(unsigned char), numRead, stream1);
					
					memcpy(pDirectory+numFile*32, &FileHeader, sizeof(FileHeader));	//	File Header 
					
					// Get a Filename 
					fileOffset	= FileHeader.FileNameOffset;
					numRead	= FileHeader.FileNameLength;
					result	= fseek(stream1, fileOffset, SEEK_SET);	//	SEEK_SET Begin of File
					numRead = fread(&fileName, sizeof(unsigned char), numRead, stream1);
					fileName[FileHeader.FileNameLength]	= '\0';	// Pad a null character at the end . 

					fileOriginalSize	= FileHeader.OriginalFileSize;
					fileType	= FileHeader.FileType;
					fileOffset	= FileHeader.FileDataOffset;
					fileSize	= FileHeader.CompressedFileSize;
					// Read DATA from file
					result	= fseek(stream1, fileOffset, SEEK_SET);	//	SEEK_SET Begin of File
					numRead = fread(DATBuf,sizeof(unsigned char), fileSize, stream1);
					
					//fileOffset = nFileSize - fileOffset;
					printf("%24s %02x(%c)- \t %10x %10x: %10x\t", fileName, fileType, fileType, fileOriginalSize, fileOffset, fileSize);
					
					if (numRead==fileSize)
					{
						/*  Create a hierarchy of directories */
						char *pSlash	= fileName;
						nameLength	= 0;

						while (pSlash!=NULL)
						{
							pSlash	= strchr(pSlash,'\\');
							
							if (pSlash!=NULL)
							{
								/* Get the name of subdirectory */
								if (pSlash)
									nameLength	= strlen(pSlash);
								else
									nameLength = 0;
								
								if (nameLength)
								{ 
									pSlash++;	// ignore first slash
								#if (DBGLEVEL&0x01) 
									printf("%s %d \t", pSlash, nameLength-1);
								#endif
									nameLength	= strlen(fileName)-nameLength;
									strncpy(subdirectoryName, fileName, nameLength);
									subdirectoryName[nameLength] = '\0';
								#ifdef	WIN32
									ErrNo = _mkdir(subdirectoryName);
								#else
									Path(subdirectoryName);
									//printf("%s\t", subdirectoryName);
									ErrNo = mkdir(subdirectoryName, S_IRWXU|S_IRWXG|S_IROTH|S_IXOTH);
								#endif
								}
							}	
						};

						numFile++;	// Count those files
						#ifdef	__unix__
							Path(fileName);
						#endif	
						//printf("%16s\t", fileName);						
						WriteFile(fileName, DATBuf, fileSize);

					}
					//
					printf("\n");

				}while(FileHeader.NextFileOffset<nFileSize);

				printf("The number of total files is %4d.\n", numFile);

				//	Write down the directory
				sprintf(DstFilename, "DECODE.DAT");
				DIRSize	= numFile*32;	// 32 bytes FileHeader
				result	= WriteFile(DstFilename, Directory, DIRSize);

	
		}

		/* Close stream */
		result = fclose( stream1 );
		if( result )
			printf( "The file %s was not closed\n", SrcFilename);
	}

	return 0;
}

