# linux 
#export LD_LIBRARY_PATH=/usr/local/lib 
gcc -fpack-struct=1 -fno-exceptions -static -D"_X_" -o readdatg  readdat.cpp   
