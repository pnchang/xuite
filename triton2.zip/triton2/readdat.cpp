// READDAT.CPP : for the console application.
// DJGPP Version

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define	MAX_PATH	256

#define	s8		char
#define	u8		unsigned char
#define	s16		short
#define	u16		unsigned short
#define s32		int
#define	u32		unsigned int
#define	s64		


FILE	*stream1, *stream2;
char	SrcFilename[MAX_PATH];
char	DstFilename[MAX_PATH];
long	nFileSize;
int	result;

long	DATCount;	// 32 DAT Area
long	DATSize[]={
	12465, 12508, 12446, 12486, 12524, 12533, 12516, 12540,
	12466, 12389, 12329, 12362, 12388, 12403, 12333, 12421,
	16686, 16894, 27688, 13236, 8192, 202350, 247540, 194754,
	204488, 12480, 4408, 6426, 3536, 4818, 8262, 20050
//	229376 // what data of gap
};
long	DATOffset[32+16];


//	Read data from the file unreal
u32 DIRSize;
u8	Directory[512*512];
u8	DATBuf[4*1024*1024];



int CountDATOffset()
{
	long	nStatus;
	long	nCount;
	long	nOffset;
	long	nFileOffset;
	int		i;
	
	nStatus	= 0;
	DATCount = sizeof(DATSize)/sizeof(long);

	nCount = DATCount;
	nOffset = 0;	// Default Value
	for(i=0;i<nCount;i++)
	{
		nOffset = nOffset + DATSize[i];
		nFileOffset = nFileSize - nOffset;
		DATOffset[i]= nFileOffset;
		printf("%2d Offset: %08x Size: %08x\n", i, nFileOffset, DATSize[i]);
	}

	// Decode process
	for(i=nFileOffset;i<nFileSize;i++)
	{
		DATBuf[i]=DATBuf[i]^0xA5;
	}
	
	return	nStatus;
}

// Write Data To File
s32 WriteFile(char *FileName, u8 * DATBuf, u32 DATSize)
{
	FILE	*hFile;
	u32	numWritten;
	s32	result;


		hFile = fopen( FileName, "w+b");
		/* Open for write */
		if( hFile == NULL )
		{
			printf( "The file %s was not created\n", FileName);
		}
		else
		{
			numWritten = fwrite( DATBuf, sizeof( char ), DATSize, hFile);

			if (numWritten==DATSize)
				printf( " %10d bytes >", DATSize);
			
			/* Close stream */
			result = fclose(hFile);
			if( result )
				printf( "The file %s was not closed\n", FileName);
		}

		return	result;
}

int main(int argc, char* argv[])
{
	u32	i;
	u32	numRead, numWritten;
	u16 numFile;
	s8	fileName[16];	// 1 byte filename Length + 12 byte filename
	u32 fileOffset;
	u32 fileSize;
	u32 dataOffset;
	u32	codeSize;
	u32	codeOffset;
	u32	codeBase;
	u32	decodeSize;
	u8	*pCode;
	u8	Key;

	if (argc==2)
	{
		sprintf(SrcFilename, argv[1]);
	}
	else
	{	
		printf("Syntax:  %s FILENAME.EXT\n", argv[0]);
		return	-1;
	}
	
	stream1 = fopen( SrcFilename, "rb");

	/* Open for read (will fail if file does not exist) */
	if( stream1 == NULL )
	{
		printf( "The file %s was not opened\n", SrcFilename);
	}
	else
	{
		nFileSize = -1;	// Default Size
		result	= fseek(stream1, 0L, SEEK_END);	//	End of File
		if (result)
		{
			// Error Handle
		}
		else
		{
			nFileSize = ftell(stream1);
		}

		fileOffset = nFileSize;	// Begin of File
		numRead = 4L;
		fileOffset = fileOffset - numRead;
		result	= fseek(stream1, fileOffset, SEEK_SET);	//	Begin of File
		numRead = fread(&dataOffset, sizeof(unsigned char), 4, stream1);
		numRead = 2L;
		fileOffset = fileOffset - numRead;
		result	= fseek(stream1, fileOffset, SEEK_SET);	//	Begin of File
		numRead = fread(&numFile, sizeof(unsigned char), 2, stream1);
		
		numFile = numFile^0x5555;	// XOR Operation
		DIRSize = numFile*21;		// The size of encoded File Area
		numRead	= DIRSize;
		fileOffset = fileOffset - numRead;
		result	= fseek(stream1, fileOffset, SEEK_SET);	//	Begin of File

		numRead = fread(DATBuf,sizeof(unsigned char), DIRSize, stream1);

		printf( "The file %s was %d bytes length. Read %d(%d*21) bytes data!\n" , SrcFilename, nFileSize, numRead, numFile);

		if ( numRead )
		{

			sprintf(DstFilename, "DIRAREA.DAT");
			stream2 = fopen( DstFilename, "w+b");
			/* Open for write */
			if( stream2 == NULL )
			{
				printf( "The file %s was not opened\n", DstFilename);
			}
			else
			{
				u32	DIRBase;
				
				//	First - XOR Opertion
				DIRBase = 0x0000;
				DIRSize = DIRSize-DIRBase;
				pCode = (u8 *)(DATBuf+DIRBase);
				Key = 0x55;

				printf(" %04x %04x: %04x \t", Key, (DIRSize>>0), pCode[0]);
				for(i=0;i<(DIRSize);i++)
				{
					Directory[i]=pCode[i]^Key;

					// Increment if the instruction DEC CX was
					//Key ++;
				}
				printf(" >>\n");

				// Second - Print filename, Offset, Size
				for(i=0;i<numFile;i++)
				{
					u32	EntryOffset;

					EntryOffset	= i*21;
					memset(fileName,0x00, sizeof(fileName));
					memcpy(fileName,Directory+EntryOffset+1, 12);
					memcpy(&fileOffset, Directory+EntryOffset+13, 4);
					memcpy(&fileSize, Directory+EntryOffset+17, 4);
					
					// Read DATA from file
					result	= fseek(stream1, (nFileSize-fileOffset), SEEK_SET);	//	Begin of File
					numRead = fread(DATBuf,sizeof(unsigned char), fileSize, stream1);
					
					//fileOffset = nFileSize - fileOffset;
					printf("%12s -\t %6x %6x: %6x\t", fileName, (nFileSize-fileOffset), fileOffset, fileSize);
					
					if (numRead==fileSize)
					{

						u32	FOffset,FSize;
						u32	k;
						u8	Step=0x15;
						u8	Key2;
						s8	Count;

#if (DBGLEVEL & 0x01)
						char *pDst=NULL;
						char DFilename[16], ExtFilename[8];

						strcpy(DFilename, fileName);
						pDst = strchr(DFilename, '.');
						strcpy(ExtFilename, pDst);
						*pDst='_';
						*(pDst+1)='\0';
						strcat(DFilename,ExtFilename);

						WriteFile(DFilename, DATBuf, fileSize);
#endif

						// Decode Data - XOR 5A + Key
						pCode = (u8 *)(DATBuf);
						Key=0x5A;
						FOffset	= 0x0000; 
						FSize = 0x0000;
						Key2=(FOffset>>6)*Step;	// Quotient
						Count=63-(FSize%64);		// Remainder
						for(k=0;k<(fileSize);k++)
						{
							pCode[k]=pCode[k]^Key;
							pCode[k]=pCode[k]+Key2;

							// Increment if the instruction DEC BX was
							Count--;
							if (Count<0)
							{
								Key2=Key2+0x15;
								Count=63;
								//Key ++;
							}
						}
						
						// write down 
						WriteFile(fileName, DATBuf, fileSize);
					}
					//
					printf("\n");

				}


				numWritten = fwrite( Directory, sizeof( char ), DIRSize, stream2);

				if (numWritten)
					printf( "The file %s was written %d bytes data.\n", DstFilename, numWritten);
				
				/* Close stream */
				result = fclose(stream2);
				if( result )
					printf( "The file %s was not closed\n", DstFilename);
			}
		}

		/* Close stream */
		result = fclose( stream1 );
		if( result )
			printf( "The file %s was not closed\n", SrcFilename);
	}

	return 0;
}

