/*
for DUST Used
*/
#include <stdio.h>
#include <string.h>	/* strrchr() */
#include <memory.h>
#ifdef __GNUC__
#include <sys/types.h>
#include <sys/stat.h>	/* mkdir() */
#endif
#if defined(_MSC_VER)||defined(MINGW)
#include <direct.h> 	/* _mkdir() */
#endif

#define	DBG	0x08

#ifndef	MAX_PATH
#define	MAX_PATH	256
#endif

#define	s8		char
#define	u8		unsigned char
#define	s16		short
#define	u16		unsigned short
#define s32		int
#define	u32		unsigned int
#define	s64		signed long int 

#define	byte	unsigned char
#define	ushort	unsigned short



FILE	*inFile, *outFile;
char	SrcFilename[MAX_PATH];
char	DstFilename[MAX_PATH];
long	nFileSize;
int	result;

// Limitation
#define	CODESIZE	4*1024*1024
#define	DATASIZE	4*1024*1024
#define	RAWSIZE		2*1024*1024
#define	PIXSIZE		1*1024*1024

//	Read data from the file unreal
u32 DIRSize;
u8	Directory[512*512];
u8	DATABuf[DATASIZE];	// DATA
u8	CODEBuf[CODESIZE];	// CODE
u8	RAWBuf[RAWSIZE];	// Original Data 
u8	PIXBuf[PIXSIZE];	// Picture Data
u8	P[4][80*400];


#define	TGASIZE	1024*1024
u32	TGASize;
u32 TGAOffset;
u8	TGABuf[TGASIZE];	// PIX DATA
u8	Palette[256*3];

#ifndef MY_TGA

#define MY_TGA

#define TGA_INTERLACED(a)       ( (a) & 0xc0 )
#define TGA_FLIP(a)             ( ((a) & 0x20) ? 0 : 1)
#define TGA_MAPPED              1
#define TGA_RGB                 2
#define TGA_RLE_MAPPED          9
#define TGA_RLE_RGB             10

/*
 * Targa header.
 */
typedef struct {
        byte   num_id;
        byte   cmap_type;
        byte   image_type;
        ushort cmap_orign;
        ushort cmap_length;
        byte   cmap_entry_size;
        ushort xorig, yorig;
        ushort xsize, ysize;
        byte   pixel_size;
        byte   image_descriptor;
} tga_hdr;

#endif       /* MY_TGA */

/*
  Read Data From File
  Return:
     0: Pass
	xx: Fail
*/
s32 ReadFile(char *FileName, u32 FileOffset, u8 *DATBuf, u32 *DATSize)
{
	FILE	*hFile;
	u32 FileSize;
	u32	numRead;
	s32	result = -1;
	
	hFile = fopen( FileName, "rb");

	/* Open for read (will fail if file does not exist) */
	if( hFile == NULL )
	{
		printf( "The file %s was not opened\n", FileName);
	}
	else
	{
		FileSize = -1;	// Default Size
 
		result	= fseek(hFile, 0L, SEEK_END);	//	SEEK_END End of File
		if (result)
		{
			// Error Handle
		}
		else
		{
			FileSize = ftell(hFile);	// Get a Right File Size
			result = result|0x0001;
			if (FileSize<*DATSize)
			{
				// ERROR if Buffer Size is bigger than File Size
				*DATSize =  FileSize;	// Set a Right Data Size
			}
			
			
				result = fseek(hFile, FileOffset, SEEK_SET);	//	SEEK_SET Set Offset of File
				numRead = fread(DATBuf, 1, *DATSize, hFile);	
				result = fclose(hFile);
				// Pass 
				if (numRead==*DATSize)
				{
					result = 0;	// PASS
					
				}
				*DATSize = numRead;	// Set
			
		}
	}
	
	return	result;
}

// Write Data To File
s32 WriteFile(char *FileName, u8 * DATBuf, u32 DATSize)
{
	FILE	*hFile;
	u32	numWritten;
	s32	result=-1;


		hFile = fopen( FileName, "w+b");
		/* Open for write */
		if( hFile == NULL )
		{
			printf( "The file %s was not created\n", FileName);
		}
		else
		{
			numWritten = fwrite( DATBuf, sizeof( char ), DATSize, hFile);

			if (numWritten==DATSize)
				printf( " %10d bytes >>", DATSize);
			
			/* Close stream */
			result = fclose(hFile);
			if( result )
				printf( "The file %s was not closed\n", FileName);
		}

		return	result;
}


u16 CheckSum(s8* String)
{
	s32	i;
	u16	sum;
	
	sum = 0;
	for(i=0;i<strlen(String);i++)
		sum=sum+String[i];
	
	return	sum;
}

/*
Write TGA File
*/
s32 WriteTGAFile(char *FileName, u16 Width, u16 Height, u8 *Palette, u8 *DATBuf, u32 DATSize)
{
	tga_hdr	tga;
	u16	CI;	// Color Index 
	u16	numColors;	// number of Colors
	u32	Size;
	u32	TGAOffset;
	u8	TGAPalette[256*3];
	s32	i;
	
		// Initialize 	
		TGAOffset = 0;
		
	// Set TGA Header 
		
	/*
	* Bytes are in reverse order so ...
	*/
		tga.num_id	= 0x00;
		tga.cmap_type	= 0x01;
		tga.image_type	= 0x01;
		tga.cmap_orign	= 0x0000;	// 2 bytes
		tga.cmap_length = 256;		// 2 bytes
		tga.cmap_entry_size = 24;	// 1 byte
		tga.xorig = 0x0000;
		tga.yorig = 0x0000;
		tga.xsize = Width;
		tga.ysize = Height;
		tga.pixel_size = 8;     /* we'll use it directly */
		tga.image_descriptor = 0x20;
		memcpy(TGABuf+TGAOffset, &tga, sizeof(tga));
		TGAOffset = TGAOffset+sizeof(tga);
		
			// RGB to BGR 
			numColors = 256;	//
			for(i=0;i<(numColors);i++)
			{
				u8	tmp;
				tmp = *(Palette+i*3+0)<<2 ;	// Red 
				TGAPalette[i*3+0] = *(Palette+i*3+2)<<2;	// Blue 
				TGAPalette[i*3+1] = *(Palette+i*3+1)<<2;	// Green
				TGAPalette[i*3+2] = tmp;	// Red 
			}
			// Palette Data
			Size = numColors*3;
			memcpy(TGABuf+TGAOffset, TGAPalette, Size);
			TGAOffset = TGAOffset + Size;
			
			// Pixels Data
			Size = Width*Height;
			memcpy(TGABuf+TGAOffset, DATBuf, Size);
			TGAOffset = TGAOffset + Size;
			
			WriteFile(FileName, TGABuf, TGAOffset);
	return 	0;
}

/*
dust-pre.d2
*/
s32 DecodeD2(u8 *Buf, s32 Size, u8 *DstBuf, u32 *DstSize)
{
	u32	Status;
	u8	*Ptr;
	u32	SrcOfs;
	u32	DstOfs;
	u16	Key;
	s16	Length;
	u8	x;
	s32	i, j;

	// Initialize
		Ptr = (u8*)(Buf);
		Key = ((Size&0xFF)+4)<<8;	// Low Byte
	for(i=0;i<Size;i++)
	{
		x = *(Ptr+i);
		x = x -3;
		x = x^(Key>>8);	// High Byte 
		Key = Key+0x8822;
		Key = Key^0x2205;
		*(Ptr+i) = x;
	}
	// Second Part
	Ptr = (u8*)(Buf);
	SrcOfs = 0;
	DstOfs = 0;
	while(SrcOfs<Size)
	{
		Length = *(Ptr+SrcOfs)+(*(Ptr+SrcOfs+1)<<8);
		SrcOfs = SrcOfs+2;
		if (Length<0)
		{
			// Negative
			Length = -Length+1;
			x=*(Ptr+SrcOfs); 
			SrcOfs = SrcOfs+1;
			memset(DstBuf+DstOfs, x, Length);
			DstOfs = DstOfs+Length;
		}
		else
		{
			// Positive
			Length++;
			memcpy(DstBuf+DstOfs, Ptr+SrcOfs, Length);
			SrcOfs = SrcOfs+Length;
			DstOfs = DstOfs+Length;
		}
	}
	*DstSize = DstOfs;
	
	return	0;	
}

/*
Text Pix
*/
s32 DecodePix(u8 ProgIndex, u16 DATIndex, u8 *Buf, s32 Size, u8 *DstBuf, u32 *DstSize)
{
	u32	Status;
	u8	*Ptr;
	u32	Base;
	u32	Offset;
	u32	Segment;
	u16	numPix;	// The number of Pictures
	u32	SrcOfs[64];	// The Offset of Pictures  4+5/35/
	u32	DstOfs;
	s16	Length;
	u16	Width;
	u16 Height;
	u16	x;	// 2 bytes Length
	s32	i, j, k, l;
	s8	FileName[64];

	u32	POfs;

	// Initialize
		Ptr = (u8*)(Buf);
		Offset = 0;
		numPix = *(Ptr+Offset)+(*(Ptr+Offset+1)<<8);	// First two bytes
		Offset = Offset + 2;
		Base = 2 + numPix*4;
	// Calculate Real Offset of pictures
	for(i=0;i<numPix;i++)
	{
		x=*(Ptr+Offset)+(*(Ptr+Offset+1)<<8);	// Offset : First two bytes
		Offset = Offset+2;
		SrcOfs[i]=Base+x;
		x=*(Ptr+Offset)+(*(Ptr+Offset+1)<<8);	// Segment: Second two bytes
		Offset = Offset+2;
	}
	// Decode 4 Planes 
	for(i=0;i<numPix;i++)
	{
		Offset = SrcOfs[i];
		Width = *(Ptr+Offset)+(*(Ptr+Offset+1)<<8);
		Offset = Offset+2;
		Height = *(Ptr+Offset)+(*(Ptr+Offset+1)<<8);
		Offset = Offset+2;	
		// Third 2-bytes  Unknown
		Offset = Offset+2;

#if (DBG&0x08)		
		printf("\n%3dx%3d %08x\t", Width, Height, Offset);
#endif
		
		// Run-Length
		// 4 planes Data
		for(j=0;j<4;j++)
		{
			memset(P[j], 0, 80*200);	// a pix length block fill with 0 
			POfs = 0; // Start
			Length = *(Ptr+Offset)+(*(Ptr+Offset+1)<<8);
			Offset = Offset+2;
		
			// bit 0 : added a width.
			if ((Length&0x01)==0)
			{
				x = *(Ptr+Offset)+(*(Ptr+Offset+1)<<8);
				Offset = Offset+2;
				POfs = POfs+x;	// Pixel location
			}
			Length = Length>>1;
			for(k=0;k<Length;k++)
			{
				// copy pixels from src to dst 
				x=*(Ptr+Offset)+(*(Ptr+Offset+1)<<8);
				Offset = Offset+2;
				
				for(l=0;l<x;l++)
				{
					P[j][POfs]=*(Ptr+Offset);
					Offset++;
					POfs++;
				}
				// Do not need do get the length at last time 
				if (k<Length-1)
				{
					// Get the length of the next pixel
					x = *(Ptr+Offset)+(*(Ptr+Offset+1)<<8);
					Offset = Offset+2;
					POfs = POfs+x;	// Pixel location
				}
			}
		} // 4 Planes
#if (DBG&0x08)
		printf("%08x\t", Offset);
#endif		
		// 4-plane to linear
		for(j=0;j<80*Height;j++)
		{
			for (k=0;k<4;k++)
				*(DstBuf+j*4+k)=P[k][j];
		}
		//	Write to a TGA file
		sprintf(FileName,"%1d%1d%02d.TGA", ProgIndex, DATIndex, i);
		WriteTGAFile(FileName, 320, Height, Palette, DstBuf, 320*Height);
	} // numPix
	// Second Part

	*DstSize = DstOfs;
	
	return	0;	
}

/*
4 planes 80x200 Raw Pix 
*/
s32 SavePix(u8 ProgIndex, u16 DATIndex, u8 *Buf, s32 BufSize, u8 *DstBuf, u32 *DstSize)
{
	u32	Status;
	u8	*Ptr;
	u32	Size;
	u32	Offset;
	u32	PlaneSize;

	u16	Width=320;
	u16 Height=200;
	s32	i, k;
	s8	FileName[64];	

		Ptr=(u8*)Buf;
		Size = Width*Height;	// BufSize
		PlaneSize = Width/4*Height;
		
#if 0		
		// 4-plane to linear
		for(i=0;i<PlaneSize;i++)
		{
			for (k=0;k<4;k++)
				*(DstBuf+i*4+k)=*(Ptr+k*PlaneSize+i);
		}
#endif		
		//	Write to a TGA file
		i=0;
		sprintf(FileName,"%1d%1d%02d.TGA", ProgIndex, DATIndex, i);
		WriteTGAFile(FileName, Width, Height, Palette, Buf, Width*Height);

	*DstSize = Size;
	
	return	0;	
}


/*
three programs
+0000 numCode: number of encoded data for program 0
+0001 CodeSize: Length of encoded data 0 (include size of CodeSize and MemorySize)
+0003 MemorySize: Length of decoded data 0
+0005 begin of encoded data 0
+xxx0 CodeSize: Length of encoded data 1
+xxx2 MemorySize: Length of decoded data 1
+xxx4 begin of encoded data 1
...
+yyy4 begin of encoded data n-1
...
+zzz0 numCode: number of encoded data for program 1
+zzz1 CodeSize: Length of encoded data 0 (include size of CodeSize and MemorySize)
+zzz3 MemorySize: Length of decoded data 0
+zzz5 begin of encoded data 0
...

*/
s32 LoadD(s8 *Filename)
{
	u32	Status;

	s32	i, j;
	u32	numRead, numWritten;
	u32 Offset;
	u32	Size;
	u16 numProg;	// three programs
	u16 numCode;
	u32 CodeSize;
	u32	MemorySize;
	u32	RAWSize;
	u32	PixSize;


	numRead = DATASIZE;
	Status = ReadFile( Filename, 0L, DATABuf, &numRead);	// Read CODE File
	if (Status==0)
	{
		Size = numRead;
		numProg = 3;
		Offset = 0;
		printf("%s %8d %2d\t", Filename, Size, numProg);
		for(j=0;j<numProg;j++)
		{
			numCode = DATABuf[Offset];
			printf("\n%1d %08x %2d\t", j, Offset, numCode);
			Offset = Offset + 1;		
			for (i=0;i<numCode;i=i+2)
			{
				CodeSize = DATABuf[Offset]+(DATABuf[Offset+1]<<8);
				Offset = Offset + 2;
				MemorySize = DATABuf[Offset]+(DATABuf[Offset+1]<<8);
				Offset = Offset + 2;
				printf("\n%2d%2d %08x %08x %08x \t", j, i, CodeSize, MemorySize, Offset);
				CodeSize = CodeSize-4;	//
				Status = DecodeD2(DATABuf+Offset, CodeSize, RAWBuf, &RAWSize);
				if (Status==0)
				{
#if (DBG&0x04)			
					sprintf(SrcFilename,"S%1d%02d.BIN", j, i);
					WriteFile( SrcFilename, DATABuf+Offset, CodeSize);
#endif				
					sprintf(DstFilename,"D%1d%02d.DAT", j, i);
					WriteFile( DstFilename, RAWBuf, RAWSize);
					
					// Current Palette
						if (i==0)
							memcpy(Palette,RAWBuf,RAWSize);
					if (j==0)
					{
						// program 0

						if ((i==2)||(i==4))
							Status = DecodePix(j,i,RAWBuf,RAWSize,PIXBuf,&PixSize);
					}
				
					if (j==1)
					{

						if (i==2)
							Status = DecodePix(j,i,RAWBuf,RAWSize,PIXBuf,&PixSize);
						if ((i==4)||(i==6))
							Status = SavePix(j,i,RAWBuf,RAWSize,PIXBuf,&PixSize);
					}
					if (j==2)
					{
						// 320x200 pix 
						if (i==2)
							Status = SavePix(j,i,RAWBuf,RAWSize,PIXBuf,&PixSize);
					}
				}
				Offset = Offset + CodeSize;			
			} // End of FOR i Loop
		} // FOR j Loop 
	}
	
	return	0;
}



/* main program */
int main(int argc, char* argv[])
{
	FILE	*hFile;
	s8	Filename[128];
	u32	Status;

	s32	i, j;
	u32	numRead, numWritten;
	u32	Sum;


	if (argc==2)
	{
		sprintf(Filename, "%s", argv[1]);
	}
	else
	{
		printf("Syntax: %s FILENAME.EXT \n", argv[0]);
		return	-1;	
	}

	LoadD(Filename);
//	if (Status==0)	printf("%s  %8d\n", SrcFilename, numRead);
	
	
	return 0;
}

	
