/*
Reference:
[] Brennan Underwood, "DJGPP VGA access", http://www.delorie.com/djgpp/doc/brennan/brennan_access_vga.html.
[] "GRAPHICS PROGRAMMING IN DJGPP", (c)1996 Jeff Weeks and Code X software, http://www.execulink.com/~psweeks/tut/.
[] The Dark Angel, "Game Programming With DJGPP", http://reocities.com/SiliconValley/park/8933/main.html. 
[] The Celtek Cybernetic Core, "Tutorial", http://www.oocities.org/siliconvalley/pines/8864/tutorial.htm.
[] David Brackeen, "256-Color VGA programming in C", http://www.brackeen.com/vga/index.html.

History:
Initial date: 2013/07/29

*/


#define	OPT	1	/* Using Method 1 */

#if (OPT==1)
#include <sys/movedata.h>	/* _dosmemputb() */
#endif
#if (OPT==2)
#include <sys/farptr.h>		/* */
#endif
#if (OPT==3)
#include <sys/nearptr.h>	/* */
#endif

#include <go32.h>
#include <dos.h>
#include <stdio.h>	
#include <stdlib.h>	/* exit() */
#include <sys/time.h>	/* time_t */


#define GRAPHICS        0x013
#define TEXT            0x03

char *video_buffer = (char *)0xa0000;

void Set_Video_Mode(int mode)
{
        union REGS regs;

        regs.x.ax = mode;
        int86(0x10, &regs, &regs);
}

/* */
void WaitRetrace(void)
{
	// Wait Vertical Retrace
	while(inportb(0x03DA)&0x08) {};
	// Wait Refresh
	while(!(inportb(0x03DA)&0x08)) {};
}





void PutPixel(int x, int y, char color)
{
#if (OPT==1)
	_dosmemputb(&color, 1, 0xa0000+(y << 8) + (y << 6) + x);
#endif
#if (OPT==2)
	_farpokeb(_dos_ds, 0xa0000+(y << 8) + (y << 6) + x, 1)
#endif
#if (OPT==3)
	video_buffer[(y << 8) + (y << 6) + x] = color;
#endif
}

void DrawLine(int x1, int y1, int x2, int y2, char c) {
	int delta_x, delta_y;
	int major_axis, direction;
	int double_delta_x;
	int double_delta_y;
	int diff_double_deltas;
	int error;

	// by making sure y1 is greater than y2 we eliminate different line
	// possibilites.  So, if this condition is false, we just switch our
	// coordinates.  Now we know the line goes from top to bottom.  We just
	// need to know if it goes left to right or right to left.
	if(y1 > y2) {
		y1 ^= y2;		// swap y1 and y2
		y2 ^= y1;
		y1 ^= y2;
		x1 ^= x2;		// swap x1 and x2
		x2 ^= x1;
		x1 ^= x2;
	}

	delta_x = x2 - x1;		// will determine L->R or R->L
	delta_y = y2 - y1;		// has to be positive because line goes T->B

	if(delta_x > 0)		// delta_x is positive: we're going left to right
		direction = 1;
	else {			// delta_x is negative: we're going from right to left
		delta_x = -delta_x;	// we need the absolute length of this axis later on
		direction = -1;
	}

	// find out what are major axis is
	if(delta_x > delta_y) major_axis = 0;	// our main axis is the x
	else major_axis = 1;	// our main axis in the y

	switch(major_axis) {	// what is our main axis
	case 0:	// major axis is the x
		double_delta_y = delta_y + delta_y;
		diff_double_deltas = double_delta_y - (delta_x + delta_x);
		error = double_delta_y - delta_x;

		PutPixel(x1,y1,c);		// plot our first pixel
		while(delta_x--) {		// loop for the length of the major axis
			if(error >= 0) {	// if the error is greater than or equal to zero:
				y1++;		// increase the minor axis (y)
				error += diff_double_deltas;
			}
        		else error += double_delta_y;
			x1 += direction;	// increase the major axis to next pixel
			PutPixel(x1,y1,c);	// plot our pixel
		}
		break;
	case 1:	// major axis is the y
		double_delta_x = delta_x + delta_x;
		diff_double_deltas = double_delta_x - (delta_y + delta_y);
		error = double_delta_x - delta_y;

		PutPixel(x1,y1,c);		// plot our first pixel
		while(delta_y--) {		// loop for the length of the major axis
			if(error >= 0) {	// if the error is greater than or equal to zero:
				x1 += direction;	// increase the minor axis (x)
				error += diff_double_deltas;
			} else error += double_delta_x;
			y1++;			// increase major axis to next pixel
			PutPixel(x1,y1,c);	// plot our pixel
		}
		break;
	}
	return;		// we're done
}




int main(void)
{
        int count;
	int	x, y, x2, y2;
	char	c;
	time_t	t1, t0;
	double	elapsed;

#if (OPT==1)

#endif
#if (OPT==3)
        /* disable all memory protection */
        if(__djgpp_nearptr_enable()==0)
	{
		printf("Could get access to first 640K of memory.\n");
		exit(-1);
	}
        video_buffer += __djgpp_conventional_base;
#endif

        /* go to graphics mode */
        Set_Video_Mode(GRAPHICS);

        /* fill up the screen with random pixels */
        for(count = 0; count < 32000; count++) {
		x = rand() % 320;	/* Width */ 
		y = rand() % 200;	/* Height */
		c = rand() % 256;	/* Color */
        	PutPixel( x, y, c);
        }

	time(&t0);
	/* Pixels Part */
	do
	{
		x = rand() % 320;	/* Width */ 
		y = rand() % 200;	/* Height */
		c = rand() % 256;	/* Color */
		PutPixel( x, y, c);
	}while(!kbhit());
	while (kbhit()) getch();

	/* Lines Part */ 
	do
	{
		x = rand() % 320;	/* Width */ 
		y = rand() % 200;	/* Height */
		x2 = rand() % 320;	/* Width */ 
		y2 = rand() % 200;	/* Height */
		c = rand() % 256;	/* Color */
		DrawLine( x, y, x2, y2, c);
	}while(!kbhit());	
	while (kbhit()) getch();

        /* go back to text mode */
        Set_Video_Mode(TEXT);

	time(&t1);
	elapsed = difftime(t1, t0);

	printf (": %f\n", (double)elapsed);
#if (OPT==3)
        /* reenable memory protection */
        __djgpp_nearptr_disable();
#endif
        exit(0);
}

