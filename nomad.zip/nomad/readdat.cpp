// READDAT.CPP : for the console application.
// DJGPP Version

#include <stdio.h>
#include <stdlib.h>	/* malloc(), free() */
#include <string.h>	/* strrchr() */
#include <memory.h>
#ifdef __GNUC__
#include <sys/types.h>
#include <sys/stat.h>	/* mkdir() */
#endif
#if defined(_MSC_VER)||defined(MINGW)
#include <direct.h> 	/* _mkdir() */
#endif

#define	MAX_PATH	256

#define	s8		char
#define	u8		unsigned char
#define	s16		short
#define	u16		unsigned short
#define s32		int
#define	u32		unsigned int
#define	s64		


FILE	*stream1, *stream2;
char	SrcFilename[MAX_PATH];
char	DstFilename[MAX_PATH];
long	nFileSize;
int	result;

long	DATCount;	// 32 DAT Area
long	DATSize[]={
	12465, 12508, 12446, 12486, 12524, 12533, 12516, 12540,
	12466, 12389, 12329, 12362, 12388, 12403, 12333, 12421,
	16686, 16894, 27688, 13236, 8192, 202350, 247540, 194754,
	204488, 12480, 4408, 6426, 3536, 4818, 8262, 20050
//	229376 // what data of gap
};
long	DATOffset[32+16];


//	Read data from the file unreal
u32 DIRSize;
u8	Directory[512*512];
u8	DATBuf[4*1024*1024];

/* Last 8 bytes data from the end of file */
/* 4 bytes number of files and 4 bytes offset of directory */
struct _Header{
	u32	numFile;
	u32	Offset;
} PackHeader;

/* 64 bytes FileInfo */
struct _FileInfo{
	u8	Filename[56];
	u32 Offset;
	u32	Size;
} FileInfo;


int CountDATOffset()
{
	long	nStatus;
	long	nCount;
	long	nOffset;
	long	nFileOffset;
	int		i;
	
	nStatus	= 0;
	DATCount = sizeof(DATSize)/sizeof(long);

	nCount = DATCount;
	nOffset = 0;	// Default Value
	for(i=0;i<nCount;i++)
	{
		nOffset = nOffset + DATSize[i];
		nFileOffset = nFileSize - nOffset;
		DATOffset[i]= nFileOffset;
		printf("%2d Offset: %08x Size: %08x\n", i, nFileOffset, DATSize[i]);
	}

	// Decode process
	for(i=nFileOffset;i<nFileSize;i++)
	{
		DATBuf[i]=DATBuf[i]^0xA5;
	}
	
	return	nStatus;
}

// Write Data To File
s32 WriteFile(char *FileName, u8 * DATBuf, u32 DATSize)
{
	FILE	*hFile;
	u32	numWritten;
	s32	result=-1;


		hFile = fopen( FileName, "w+b");
		/* Open for write */
		if( hFile == NULL )
		{
			printf( "The file %s was not created\n", FileName);
		}
		else
		{
			numWritten = fwrite( DATBuf, sizeof( char ), DATSize, hFile);

			if (numWritten==DATSize)
				printf( " %10d bytes >>", DATSize);
			
			/* Close stream */
			result = fclose(hFile);
			if( result )
				printf( "The file %s was not closed\n", FileName);
		}

		return	result;
}

/* from backslash to slash */
s32 Path(char *Name)
{
	s32	Status=-1;
	char	*pSlash;
	
		pSlash	= Name;
		do 
		{
			pSlash	= strchr(pSlash,'\\'); 
			if (pSlash)
			{
				*pSlash ='/';
				pSlash++;
			}
			
		}while(pSlash);
	Status = 0;
	
	return	Status;
}

int main(int argc, char* argv[])
{
	u32	i;
	u32	numRead, numWritten;
	u32 numFile;
	s8	fileName[64];	// 64 byte fileName
	s8	directoryName[64];	// 64 bytes directoryName
	s8	subdirectoryName[64];	// 64 bytes subdirectoryName
	s8	compressedfileName[64];
	u32 nameLength;
	u32 fileOffset;
	u32 fileSize;
	u32 compressedSize;	// Compressed size
	u32 uncompressedSize;	// Uncompressed size
	u32 dataOffset;
	u32	codeSize;
	u32	codeOffset;
	u32	codeBase;
	u32	decodeSize;
	u8	*pCode;
	u8	Key;


	if (argc==2)
	{
		sprintf(SrcFilename, argv[1]);
	}
	else
	{	
		printf("Syntax:  %s FILENAME.EXT\n", argv[0]);
		return	-1;
	}

	stream1 = fopen( SrcFilename, "rb");

	/* Open for read (will fail if file does not exist) */
	if( stream1 == NULL )
	{
		printf( "The file %s was not opened\n", SrcFilename);
	}
	else
	{
		nFileSize = -1;	// Default Size
		result	= fseek(stream1, 0L, SEEK_END);	//	End of File
		if (result)
		{
			// Error Handle
		}
		else
		{
			nFileSize = ftell(stream1);
		}

		fileOffset = nFileSize;	// Beginning of File
		numRead = 8L;
		fileOffset = fileOffset - numRead;
		result	= fseek(stream1, fileOffset, SEEK_SET);	//	Beginning of File
		numRead = fread(&PackHeader, sizeof(unsigned char), numRead, stream1);
		dataOffset = PackHeader.Offset;	// 4 bytes offset
		numFile = PackHeader.numFile;	// 4 bytes number of files
		

		DIRSize = nFileSize-dataOffset-4-4;		// The size of File Area
		numRead	= DIRSize;
		result	= fseek(stream1, dataOffset, SEEK_SET);	//	SEEK_SET Begin of File
		numRead = fread(Directory,sizeof(unsigned char), numRead, stream1);

		printf( "The file %s was %d bytes length. Read %d bytes data! %d Files\n" , SrcFilename, nFileSize, numRead, numFile);

		if ( numRead )
		{

			sprintf(DstFilename, "DECODE.DAT");
			stream2 = fopen( DstFilename, "w+b");
			/* Open for write */
			if( stream2 == NULL )
			{
				printf( "The file %s was not opened\n", DstFilename);
			}
			else
			{
				u32	DIRBase;
				s8	*pDirectory;
				u32	EntryOffset	= 0x0000;
				u32	NextEntryOffset;
				s32	ErrNo;
				
				pDirectory = (s8*)Directory;
				//   First - Print filename, Offset, Size
				for(i=0;i<numFile;i++)
				{
					// Get the current file information
					strcpy(fileName,pDirectory+EntryOffset+0);
					EntryOffset	= EntryOffset + strlen(fileName)+1;
					memcpy(&fileOffset, pDirectory+EntryOffset+0, 4);
					EntryOffset	= EntryOffset + 4;
					memcpy(&uncompressedSize, pDirectory+EntryOffset+0, 4);
					EntryOffset	= EntryOffset + 4;
					
					/* Get the file offset of Next Entry */
					if (EntryOffset<DIRSize)
					{ 
						NextEntryOffset	= EntryOffset + strlen(pDirectory+EntryOffset+0)+1;
						memcpy(&fileSize, pDirectory+NextEntryOffset+0, 4);
					}
					else
						fileSize = dataOffset;	// The offset of directory area
					fileSize = fileSize - fileOffset;
					
					/* Get the name of subdirectory */
					nameLength	= strlen(strrchr(fileName,'\\'));
					if (nameLength)
					{ 
						nameLength	= strlen(fileName)-nameLength;
						strncpy(directoryName, fileName, nameLength);
						directoryName[nameLength] = '\0';
					}
					/* Rename to zip filename */
					nameLength	= strlen(strchr(fileName,'.'));
					if (nameLength)
					{ 
						nameLength	= strlen(fileName)-nameLength+1;
						strncpy(compressedfileName, fileName, nameLength);
						compressedfileName[nameLength] = '\0';
						strcat(compressedfileName,"ZIP");
					}					
						

					// Read DATA from file
					result	= fseek(stream1, fileOffset, SEEK_SET);	//	SEEK_SET Begin of File
					numRead = fread(DATBuf,sizeof(unsigned char), fileSize, stream1);					
					
					//fileOffset = nFileSize - fileOffset;
					printf("%24s %40s -\t %10x: %10x %10x\t", directoryName, compressedfileName,  fileOffset, fileSize, uncompressedSize);

					if (numRead==fileSize)
					{
						/*  Create a hierarchy of directories */
						char *pSlash	= fileName;

						do 
						{

							pSlash	= strchr(pSlash,'\\');
							/* Get the name of subdirectory */
							if (pSlash)
								nameLength	= strlen(pSlash);
							else
								nameLength = 0;	

							if (nameLength)
							{ 
								pSlash++;	// ignore first slash
							#if (DBGLEVEL&0x01) 
								printf("%s %d \t", pSlash, nameLength-1);
							#endif
								nameLength	= strlen(fileName)-nameLength;
								strncpy(subdirectoryName, fileName, nameLength);
								subdirectoryName[nameLength] = '\0';
							#ifdef	WIN32
								ErrNo = _mkdir(subdirectoryName);
							#else
								Path(subdirectoryName);
								//printf("%s\t", subdirectoryName);
								ErrNo = mkdir(subdirectoryName, S_IRWXU|S_IRWXG|S_IROTH|S_IXOTH);
							#endif
							}
						}while(nameLength>0);

						#ifdef	__unix__
							Path(compressedfileName);
						#endif	
						//printf("%16s\t", compressedfileName);
						WriteFile(compressedfileName, DATBuf, fileSize);
					}
					//
					printf("\n");

				}


				numWritten = fwrite( Directory, sizeof( char ), DIRSize, stream2);

				if (numWritten)
					printf( "The file %s was written %d bytes data.\n", DstFilename, numWritten);
				
				/* Close stream */
				result = fclose(stream2);
				if( result )
					printf( "The file %s was not closed\n", DstFilename);
			}
		}

		/* Close stream */
		result = fclose( stream1 );
		if( result )
			printf( "The file %s was not closed\n", SrcFilename);
	}

	return 0;
}

