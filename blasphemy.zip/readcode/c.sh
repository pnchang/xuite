# MinGW  
#export DXDIR='/C/Program Files (x86)/Microsoft DirectX SDK (June 2010)/'
gcc -fpack-struct=1 -fno-exceptions -fpermissive -static -D"__STDC_LIMIT_MACROS" -D"MINGW" -o READDATG.exe  IMAGE.CPP READDAT.CPP -lstdc++  