/*
1996\z\zerograv  Zero Gravity
1997\b\beamed  beamed
1997\m\mundai_f  Mundai
1998\l\llane_f
1998\u\urknall
1998\theparty98\demo\kkowboy
1999\summerencounter99\demo\moral_ha
2000\scene_event00\demo\megademo
Blasphemy
Denmark
*/
#include <stdio.h>
#include <stdlib.h>	/* free() */
#include <string.h>	/* strrchr() */
#include <memory.h>
#ifdef __GNUC__
#include <sys/types.h>
#include <sys/stat.h>	/* mkdir() */
#endif
#ifdef _MSC_VER
#include <direct.h>	/* _mkdir() */
#endif
#include <stdint.h>	/* standard integer */

#include "common.h"
#include "image.h"	/* image */

#define	DBG		0x0000
#ifndef	UINT32_MAX
#define UINT32_MAX  4294967295UL
#endif 

#ifndef	MAX_PATH
#define	MAX_PATH	256
#endif

// Limitation
#define	RAWSIZE		8*1024*1024

//	Read data from the file unreal
uint32_t	DIRSize;


#pragma pack(push)	/* push current alignment to stack */
#pragma pack(1)	/* set alignment to 1 byte boundary */

/*
8 bytes Length Data Information Header 
*/
typedef	struct _infoHeader{
	uint32_t	Offset;	// Offset of Directory
	uint32_t	Number;	// Number of Data
} infoHeader;
/*
21 bytes Length Directory Entry 
*/
typedef	struct _directoryEntry{
	uint8_t	Name[13];	// Filename
	uint32_t	Size;	// Size of Data
	uint32_t	Offset;	// Offset of Data
} directoryEntry;


typedef	struct _pixInfo{
	uint32_t	Base;
	uint32_t	Offset;
	uint32_t	Size;
	uint16_t	Width;
	uint16_t	Height;
	uint8_t	Plane;
	uint8_t	PaletteInfoNo;
} pixInfo;


typedef	struct _paletteInfo{
	uint32_t	Base;
	uint32_t	Offset;
	uint32_t	Size;
	uint8_t	ColorNo;
} paletteInfo;

/* 8-byte length */
typedef	struct _pixHeader{
	uint16_t	Width;
	uint16_t	Height;
	uint8_t	u[4];
} pixHeader;

/* Program segmentation */
typedef	struct _programInfo{
	uint32_t	Offset;
	uint32_t	Size;
} programInfo;	

/* data entry */
typedef	struct _dataEntry{
	uint32_t	Offset;
	uint32_t	Size;
} dataEntry;

/* 3D object entry */
typedef	struct _objectEntry{
	uint32_t	Offset;
	uint32_t	NumberVertices;
	uint32_t	NumberFaces;
} objectEntry;

#pragma pack(pop)	/* restore original alignment from stack */

/*
Pix File
W definition:
0: Header of Pix 
otherwise, it is a width of picture
Palette: 256 colors * 3 channels RGB
*/
int32_t PixFile(char *FileName, uint8_t *Buf, uint32_t BufSize, uint16_t W, uint8_t *Palette)
{
	int32_t	Status=-1;
	char	Filename[1024];

	uint32_t	Base, Offset, Size;
	uint8_t		*Pix;
	uint32_t	PixSize;
	uint16_t	Width, Height, Plane;	
	uint32_t	PaletteOfs, PaletteSize;
	pixHeader	PixHeader;	
	//RIX_HEAD	RIXHeader;
	raw_file	RawPix;	

	if (W)
	{
		// By Argument W
		Offset = 0;	// Offset of Pix Data
		Size = 0;	// Size of Pix Header
		PixHeader.Width = W;
		PixHeader.Height = BufSize/PixHeader.Width;		
	}
	else
	{
		// Default
		Offset = 0;	// Offset of Pix Header
		Size = sizeof(pixHeader);	// Size of Pix Header
		memcpy(&PixHeader, Buf, Size);
		Offset = Offset+Size;	// Offset of Pix Data
	}
		Width = PixHeader.Width;
		Height = PixHeader.Height;
		PixSize = Width*Height*1;

				Pix = Buf+Offset;				
				RawPix.w = Width;
				RawPix.h = Height;
				RawPix.c = 256;
				RawPix.bpp = 8;
				RawPix.bpc = 6;
				RawPix.palette = Palette;
				RawPix.bitmap = Pix;
		
				sprintf(Filename, "%s.TGA", FileName);	
				printf("\t %12s: %08x %08x %6d x %6d %6d colors" , Filename, Offset, Size, RawPix.w, RawPix.h, RawPix.c);

					WriteTGAFile(Filename, &RawPix);	
					printf("\n");

					
	return	Status;	
}

/*
XOR Operator
*/
int32_t Xor(uint8_t *Buf, uint32_t BufSize, uint8_t Key)
{
	int32_t	Status=0;
	int32_t	i;
	
	for(i=0;i<BufSize;i++)
	{
		Buf[i]=Buf[i]^Key;
	}
	
	return	Status;
}


// little endian
#define	OYZO	0x4F5A594F
#define	Adam	0x6D616441
/*
Data in Executable File
*/
int32_t DataLib(uint8_t *Buf, uint32_t BufBase, uint32_t BufSize)
{
	int32_t	Status=-1;
	char	Filename[128];
	int32_t	i;
	uint8_t	*p;
	uint32_t	Base, Offset, Size;
	infoHeader	*InfoHeader;
	directoryEntry	*de;
	uint32_t	DirectoryOffset, DirectorySize;
	uint16_t	numData;	// number of Data
	uint32_t	DataBase, DataOffset, DataSize;
	uint32_t	Signature;

		Base = BufBase;
		Size = sizeof(uint32_t);
		Offset = BufSize-Size;	// from the end of file
		Signature = *(uint32_t*)(Buf+Offset);	// OYZO
		if (Signature==OYZO)
		{
			// OYZO
			printf("OYZO\t");
		}
		else
		{
			Offset = BufSize;
		}
		Size = sizeof(infoHeader);
		Offset = Offset-Size;
		InfoHeader = (infoHeader*)(Buf+Offset);
		numData = InfoHeader->Number;
		DirectoryOffset = InfoHeader->Offset;
		Size = sizeof(directoryEntry);
		DirectorySize = numData*Size;
		Offset = DirectoryOffset;
			printf("%3d %08x %08x \n", numData, DirectoryOffset, DirectorySize);
		if (Offset<BufSize)
		{	
			for(i=0;i<numData;i++)
			{
				uint32_t	n, EntryOffset;
				directoryEntry	*de;

				EntryOffset = Offset;
				de = (directoryEntry*)(Buf+Offset);
				n =sizeof(de->Name);
				memcpy(Filename, de->Name, n);
				Filename[n]='\0';	// Null terminator
				DataOffset = de->Offset;
				DataSize = de->Size;
				Offset = Offset+Size;	// Next Directory Entry
				
					printf("\t%3d %08x %24s %08x %08x %08x\t", i, EntryOffset, Filename, DataOffset, DataSize, (DataOffset+DataSize));
					p = new uint8_t[DataSize];
					if (p)
					{
						memcpy(p,Buf+DataOffset,DataSize);
						if (Signature==OYZO)
						{
							Status = Xor(p,DataSize,0x2A);
						}
						Status = WriteBFile(Filename, p, DataSize);	// write data to a file.
						delete	p;
					}
					printf("\n");
				
			};
			printf(" number of data: %3d\n", numData);

			Status = 0;
		}
		
	return	Status;
}	

/*
Data in Executable File
*/
int32_t Data(uint8_t *Buf, uint32_t BufBase, uint32_t BufSize, uint32_t EXESize)
{
	int32_t	Status=-1;
	char	Filename[128];
	char	DstFilename[128];
	uint8_t	Maximum;
	int32_t	i;
	uint8_t	*p;
	uint32_t	Base, Offset, Size;
	infoHeader	*InfoHeader;
	directoryEntry	*de;
	uint32_t	DirectoryOffset, DirectorySize;
	uint16_t	numData;	// number of Data
	uint32_t	DataBase, DataOffset, DataSize;
	uint32_t	Signature;
	uint16_t	numPix;	// number of Picture
	uint8_t		*Pix;	
	uint16_t	Width, Height, Plane;
	uint32_t	PlaneSize;
	uint16_t	numPlane;
	uint32_t	Length;
	uint32_t	RAWSize;
	uint8_t	Palette[256*3];
	uint32_t PaletteOffset, PaletteSize;	
	//RIX_HEAD	RIXHeader;
	raw_file	RawPix;	

// EXE
	programInfo	ProgramInfoTable[]={
			{ 0x00000000, 0x00003500},	// Seg000 CODE
		};

	
	dataEntry	ModTable[]={
			{ 0x00015B80, 0x06BD80},
		};

	pixInfo	PixInfoTable[]={
			{ 0x00003660,0x0600,0xCF40,320,165,1, 0},	// seg003 
		};
	paletteInfo	PaletteInfoTable[]={
			{ 0x00003660,0x0000,0x0300,0},	//0 seg003
	};
		// Initialize
		Base = BufBase;	// DOS Header Size
		Status = DataLib(Buf, 0, BufSize);
		
	return	Status;
}

/*
Do Executable File(s)
BufBase: should be 0.
EXEBase: start address of code
EXESize: size of all executable files
*/
int32_t DoEXE(char *FileName, uint8_t *Buf, uint32_t BufBase, uint32_t BufSize, uint32_t *EXEBase, uint32_t *EXESize)
{
	int32_t	Status;
	char	Filename[128];
	uint32_t	Base, Offset, Size;	
	uint32_t	numEXE;	// number of EXE Files	
	uint32_t	sizeEXE;	// Size of All Executable Files
	IMAGE_DOS_HEADER *ImageDOSHeader;
	
	// Initialize
	Status = -1;
		*EXEBase = 0;	// zero code base
		
		numEXE	=0;
		sizeEXE	= 0;		
		Offset = BufBase;	// Start Address of Buffer
		ImageDOSHeader = (IMAGE_DOS_HEADER*)(Buf+Offset);
			// Check Signature 'MZ' 
			while ((*ImageDOSHeader).e_magic==IMAGE_DOS_SIGNATURE)
			{
				Base = (ImageDOSHeader->e_cparhdr)<<4;	// Base of CODE
				if (numEXE==0)	*EXEBase = Base;	// get Address of Code in First Executable File
				Size = ImageDOSHeader->e_cblp;
				if (Size)	Size = 512-Size;	// n bytes left on last page
				Size = (ImageDOSHeader->e_cp)*512-Size;
				printf("\t%3d  %08x %08x\t", numEXE, Offset, Size);
				sprintf(Filename, "%s%02d.EXE", FileName, numEXE);
				Status = WriteBFile(Filename, Buf+Offset, Size);	// write out the execute file.
				printf("\n");
				// if it is a pack execute file, crunch it. 
				Offset = Offset+Size;
				numEXE++;
				if (Offset>=BufSize)	break;	//	Excess 
				ImageDOSHeader = (IMAGE_DOS_HEADER*)(Buf+Offset);
			}
		
		if (numEXE)
		{
			// Find Executable File(s)
			*EXESize = Offset;
			printf("\t%3d  %08x %08x\n", numEXE, *EXEBase, *EXESize);
			Status = 0;
		}
		
	return	Status;
}

/*
Do Data File(s)
*/
int32_t DoDATA(uint8_t *Buf, uint32_t BufSize)
{
	int32_t	Status=-1;
	char	Filename[128];	
	uint32_t	Base, Offset, Size;	
	uint32_t	numData;	// number of Data Files	
	uint32_t	i, k;
	uint8_t	*p;
	infoHeader	*InfoHeader;
	uint32_t	DirectoryOffset, DirectorySize;
	uint32_t	DataBase, DataOffset, DataSize;
	uint32_t	cSize, dSize;

	char	*NameTable[]={
		"titlefg.gif", 
		"titlebg.gif",
		"blaslo25.gif",
		"circle.gif",
		"credz.gif",
		"credzr.gif",
		"zgrav2.gif",
		"plasmtex.gif",
		"phongtxt.gif",
		"tex2.gif",
		"flyinman.gif",
		"draaber.col",
		"draaber2.col",
		"dirt.col",
		"plasm2.col",
		"plasm3.col",
		"tunblue.col",
		"voxel.col",
		"voxelfog.col",
		"tunred.col",
		"tunlight.col",
		"tun2.col",
		"circle.tbl",
		"fadein3b.gif",
		"blasphem.gif",
		"greetzto.gif",
		"spoon.gif",
		"blasm.gif",
		"purple.gif",
		"fudge.gif",
		"xtacy.gif",
		"tgoofs.gif",
		"noice.gif",
		"andevery.gif",
		"thanx.gif",
		"spiral.gif",
		"spiral2.gif",
		"zoombg.gif",
		"phongbg.gif",
		"twins.pap",
		"draaber.pap",
		"draabe2d.pap",
		"peanut.pap",
		"tuntxt15.gif",
		"voxel.tbl",
		"vmapgr.gif",
		"title.gif",
		"titlebw.gif",
		"spaceshi.pap",
		"chillum.pap",
		"ryges.col",
		};
	
	dataEntry	DataInfoTable[]={
		{ 0x00056, 0x0D35}, 
		{ 0x00D8B, 0x0D2F},
		{ 0x01ABA, 0x6FB4},
		{ 0x08A6E, 0x0AE7},
		{ 0x09555, 0x13B6},
		{ 0x0A90B, 0x1BB8},
		{ 0x0C4C3, 0x9B9},
		{ 0x0CE7C, 0x0A7E5},
		{ 0x17661, 0x70C},
		{ 0x17D6D, 0x4CC3},
		{ 0x1CA30, 0x111E},
		{ 0x1DB4E, 0x300},
		{ 0x1DE4E, 0x300},
		{ 0x1E14E, 0x300},
		{ 0x1E44E, 0x300},
		{ 0x1E74E, 0x300},
		{ 0x1EA4E, 0x300},
		{ 0x1ED4E, 0x300},
		{ 0x1F04E, 0x300},
		{ 0x1F34E, 0x300},
		{ 0x1F64E, 0x300},
		{ 0x1F94E, 0x300},
		{ 0x1FC4E, 0x1388},
		{ 0x20FD6, 0x958D},
		{ 0x2A563, 0x20A01},
		{ 0x4AF64, 0x12DB},
		{ 0x4C23F, 0x18AD5},
		{ 0x64D14, 0x2731F},
		{ 0x8C033, 0x0F1C4},
		{ 0x9B1F7, 0x0EA7F},
		{ 0x0A9C76, 0x17BDB},
		{ 0x0C1851, 0x2F79F},
		{ 0x0F0FF0, 0x22158},
		{ 0x113148, 0x1145},
		{ 0x11428D, 0x1FD6},
		{ 0x116263, 0x420D},
		{ 0x11A470, 0x420D},
		{ 0x11E67D, 0x4CE2},
		{ 0x12335F, 0x9CA5},
		{ 0x12D004, 0x3B28},
		{ 0x130B2C, 0x36C8},
		{ 0x1341F4, 0x0A88},
		{ 0x134C7C, 0x1638},
		{ 0x1362B4, 0x1744A},
		{ 0x14D6FE, 0x280},
		{ 0x14D97E, 0x3469},
		{ 0x150DE7, 0x74D1},
		{ 0x1582B8, 0x5ED1},
		{ 0x15E189, 0x2C18},
		{ 0x160DA1, 0x4388},
		{ 0x165129, 0x300}
		};
		
	
			Base = 0;
			Size = sizeof(uint32_t);
			Offset = BufSize-Size;

			numData = sizeof(DataInfoTable)/sizeof(DataInfoTable[0]);
			for(i=0;i<numData;i++)
			{
				DataOffset = DataInfoTable[i].Offset;
				DataSize = DataInfoTable[i].Size;
				sprintf(Filename,"%s", NameTable[i]);
				printf("\t%2d %24s %08x %08x %08x\t", i, Filename, DataOffset, DataSize, (DataOffset+DataSize));
				p = Buf+DataOffset;
				Status = WriteBFile(Filename, p, DataSize);	// write data to a file.
				printf("\n");				
			}
			printf(" number of data: %3d\n", numData);
			
			Status = 0;
	
	return	Status;
}


/* main program */
int main(int argc, char* argv[])
{
	FILE	*hFile;
	char	Filename[MAX_PATH];
	uint32_t	FileBase;
	uint32_t	FileOffset;
	uint32_t	numRead, numWritten;
	uint32_t	Base, Size, Offset;	
	uint32_t	Status;
	uint8_t	*CODEBuf = NULL;	// pointer of CODE Buffer
	uint8_t	*DATABuf = NULL;	// pointer of DATA Buffer

	if (argc==2)
	{
		strcpy(Filename, argv[1]);
	}
	else
	{
		printf("Syntax: %s FILENAME.EXE \n", argv[0]);
		return	-1;	
	}

	FileOffset = 0L;
	numRead = UINT32_MAX;	// Maximum value
	Status = ReadBFile( Filename, FileOffset, &CODEBuf, &numRead);	// Read CODE File
	if (Status==0)
	{
		char	PathName[4096];
		char	FileName[2048];
		char	FileNameExtension[1024];
		char	*p;
		uint32_t	Signature;		
		uint32_t	Length;
		
		PathName[0]='\0';	// NULL character
		Length = sizeof(PathName);
		Status = GetPathName(Filename, PathName, &Length);
		if (Status==0)
		{
			// Path
			printf("%s %4d  ", PathName, Length);
		}
		sprintf(FileName, "%s", Filename+Length);	// Filename
		FileNameExtension[0]='\0';	// Null terminator
		p = strchr(FileName, '.');	
		if (p)
		{
			// Filename extension 
			sprintf(FileNameExtension,"%s", p+1);
			*p='\0';	// Null terminator
		}
		printf("%s%s.%s\t%08x %12d(%08x)\n", PathName, FileName, FileNameExtension, FileOffset, numRead, numRead);
			Base = 0;
			Offset = 0;
			Size = 0;
			Status = DoEXE(FileName, CODEBuf, Offset, numRead, &Base, &Size);
			if (Status==0)
			{
				Signature = *(uint32_t*)(CODEBuf+Size);
				printf("%08x\t", Signature);
				// 4-byte Length
				switch	(Signature)
				{
				}
			
				Status = Data(CODEBuf, Base, numRead, Size);
			}
			else
			{
				// Data File
				Status = DataLib(CODEBuf, Base, numRead); 
			}
			
			if (Signature==Adam)
			{
				// .DAT File for DOS32
				sprintf(Filename,"%s%s.DAT", PathName, FileName);
				FileOffset = 0L;
				numRead = UINT32_MAX;	// Maximum value
				Status = ReadBFile( Filename, FileOffset, &DATABuf, &numRead);	// Read CODE File
				if (Status==0)
				{
					printf("%s\t%08x %12d(%08x)\n", Filename, FileOffset, numRead, numRead);
					Status = DoDATA(DATABuf, numRead);
					free(DATABuf);	// free memory
				}
				else
				{
					printf("%s not found!\n", Filename);
				}
			}
				
		free(CODEBuf);	// free memory
	}
	
	
	return	Status;
}

	
