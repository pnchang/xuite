/*

*/

#define	_USE_MATH_DEFINES

#include <windows.h>
#include <math.h>

#ifndef M_PI
#define  M_PI   3.14159265358979323846 /* pi */ 
#endif
#define CLIENT_WIDTH    800
#define CLIENT_HEIGHT   600

#include "VECTBALL.CPP"

int Xoff, Yoff, Zoff;

char progName[]="VECTBALL ";
char SINTAB[256];

// forward declaration:
LRESULT CALLBACK WinProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
void ClientResize(HWND hWnd, int nWidth, int nHeight);

void ClientResize(HWND hWnd, int nWidth, int nHeight)
{
	RECT rcClient, rcWindow;
	POINT ptDiff;

	GetClientRect(hWnd, &rcClient);
	GetWindowRect(hWnd, &rcWindow);
	ptDiff.x = (rcWindow.right - rcWindow.left) - rcClient.right;
	ptDiff.y = (rcWindow.bottom - rcWindow.top) - rcClient.bottom;
	MoveWindow(hWnd,rcWindow.left, rcWindow.top, nWidth + ptDiff.x, nHeight + ptDiff.y, TRUE);
}


int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrevInst, LPSTR lpszCmdLine, int nCmdShow)
{
	WNDCLASSEX winclass;
	HWND hWnd;
	MSG msg;


	winclass.cbSize=sizeof(WNDCLASSEX);
	winclass.style=CS_DBLCLKS;
	winclass.lpfnWndProc=&WinProc;
	winclass.cbClsExtra=0;
	winclass.cbWndExtra=0;
	winclass.hInstance=hInst;
	winclass.hIcon=LoadIcon(NULL,IDI_WINLOGO);
	winclass.hCursor=LoadCursor(NULL,IDC_NO);
	winclass.hbrBackground=NULL;
	winclass.lpszMenuName=NULL;
	winclass.lpszClassName=progName;
	winclass.hIconSm=NULL;

	if (!RegisterClassEx(&winclass))
		return 0;
	hWnd=CreateWindow(
			progName,
			progName,
			WS_SYSMENU|WS_CAPTION|WS_BORDER|WS_OVERLAPPED|WS_VISIBLE|WS_MINIMIZEBOX,
			CW_USEDEFAULT,
			0,
			CLIENT_WIDTH+2,
			CLIENT_HEIGHT+16+2,
			NULL,
			NULL,
			hInst,
			NULL);
	ShowWindow(hWnd,nCmdShow);
	UpdateWindow(hWnd);
	while (GetMessage(&msg,NULL,0,0)) 
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return (msg.wParam);
}

HDC pDC;
HBITMAP oldObject;
HBITMAP ourbitmap;
int * framebuf;

/*
void render_effect(int tick,int * framebuf)
{
	int i,j,k;
	tick/=4;
	for (k=0,i=0;i<CLIENT_HEIGHT;i++)
		for (j=0;j<CLIENT_WIDTH;j++,k++)
			*(framebuf+k)=RGB(SINTAB[(i+tick)&0xff],
				SINTAB[(j-tick)&0xff],
				SINTAB[(SINTAB[tick&0xff]+(k>>6))&0xff]);
}
*/

void render_effect(int tick, int *framebuf)
{
	{
		// Clear the backBuffer
		memset(backBuffer, 0, sizeof(backBuffer));

		
		if(direction==1)	// if object is moving away from you,
		{
			distance++;	// move it even further
			if(distance>=800)	// if at the limit, make it come back
			{
				direction=0;
				distance=800;
			}
		}
		else	// no, object is moving towards you
		{
			distance--;	// bring it a little closer
			if(distance<=128)	// if at limit, make it go away again
			{
				direction=1;
				distance=128;
			}
		}
		// update the angles
		xangle+= 8;
		if(xangle>=360)
			xangle=0;
		yangle+= 4;
		if(yangle>=360)
			yangle=0;
		zangle-=8;
		if(zangle<=0)
			zangle=359;
		// draw the vector ball object on the hidden screen
		draw_vector_object();
		// show what we just did
		

		
		// Copy to the display
		memcpy(framebuf, backBuffer, sizeof(backBuffer));
	}
}

void render(HDC hDC)
{
	render_effect(GetTickCount(),framebuf);
	BitBlt(hDC,0,0,CLIENT_WIDTH,CLIENT_HEIGHT,pDC,0,0,SRCCOPY);
}

void deinit_framebuf(void)
{
	SelectObject(pDC,oldObject);	// Restoring the original object
	DeleteDC(pDC);
	DeleteObject(ourbitmap);
}

void init_framebuf(void)
{
	HDC hDC;
	BITMAPINFO bitmapInfo;
	
	hDC=CreateCompatibleDC(NULL);	// If this handle is NULL, the function creates a memory DC compatible with the application's current screen.
	bitmapInfo.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);
	bitmapInfo.bmiHeader.biWidth=CLIENT_WIDTH;
	bitmapInfo.bmiHeader.biHeight=-CLIENT_HEIGHT; /* top-down */
	bitmapInfo.bmiHeader.biPlanes=1;
	bitmapInfo.bmiHeader.biBitCount=32;
	bitmapInfo.bmiHeader.biCompression=BI_RGB;
	bitmapInfo.bmiHeader.biSizeImage=0;
	bitmapInfo.bmiHeader.biClrUsed=256;
	bitmapInfo.bmiHeader.biClrImportant=256;
	// GDI device-independent bitmap
	ourbitmap=CreateDIBSection( hDC, &bitmapInfo, DIB_RGB_COLORS, (void**)&framebuf, 0, 0 );	// If hSection is NULL, the system allocates memory for the DIB.
	
	pDC=CreateCompatibleDC(NULL);	// If this handle is NULL, the function creates a memory DC compatible with the application's current screen.
	oldObject=(HBITMAP)SelectObject(pDC,ourbitmap);	// Saving the original object 
	DeleteDC(hDC);
}

LRESULT CALLBACK WinProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	HDC hDC;
	PAINTSTRUCT PtStr;
	
	switch (uMsg) {
		case WM_DESTROY:
			deinit_framebuf();
			PostQuitMessage(0);
			KillTimer (hWnd, 1);
		break;
		case WM_CREATE:
			SetTimer (hWnd, 1, 20, NULL);
			ClientResize(hWnd,CLIENT_WIDTH,CLIENT_HEIGHT);
			init_framebuf();
			
			// Initialize 
			create_lookup_tables();
			//create_object(Obj2,numBalls2,1);	//create_vector_object();
			create_object12h();
			// Clear the backBuffer
			memset(backBuffer, 0, sizeof(backBuffer));
		break;
		case WM_TIMER:
			InvalidateRgn(hWnd,0,0);
			UpdateWindow (hWnd);
		break;
		case WM_PAINT:
			hDC=BeginPaint(hWnd,&PtStr);
			render(hDC);
			EndPaint(hWnd,&PtStr);
		break;
		case WM_KEYDOWN:
			switch (wParam)
			{
				case VK_ESCAPE:
				{
					SendMessage(hWnd, WM_DESTROY, wParam, lParam);	
				}
				break;
				case VK_F1:
					if (ObjectIndex<MAXOBJECTS-1)	
						ObjectIndex++;
					(*fptr[ObjectIndex])();	// Function Pointer

					break;
				case VK_F2:
					if (ObjectIndex>0)
						ObjectIndex--;
					(*fptr[ObjectIndex])();
					break;					
				case VK_F3:
					create_object(Obj1,numBalls1,0);
				break;
				case VK_F4:
					create_object(Obj2,numBalls2,1);
				break;
				case VK_F5:
					create_object(Obj3,numBalls3,2);
				break;				
				case VK_F6:
					create_object14h();
				break;				
				case VK_F7:
					create_object15h();
				break;
				case VK_F8:
					create_object16h();
				break;				
				case VK_F9:
					create_object17h();
				break;	
			}
		break;		
		case WM_CHAR:
			switch (wParam)
			{
				case 'A':
				case 'a':
					Zoff += 5;	// away
					break;
				case 'Z':
				case 'z':
					Zoff -= 5;	// toward
					break;	
				case ',':
					Xoff -= 5;	// left
					break;
				case '.':
					Xoff += 5;	// right
					break;
				case 'S':
				case 's':
					Yoff -= 5;	// up
					break;
				case 'X':
				case 'x':
					Yoff += 5;	// down
					break;		
			}
		break;		
		default:
			return DefWindowProc (hWnd, uMsg, wParam, lParam);
		break;
	}
	return 0;
}
