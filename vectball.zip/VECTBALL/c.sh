# MINGW GDI
# export DXDIR='/C/Program Files/Microsoft DirectX SDK (June 2010)/'
gcc -fno-exceptions -fpermissive -static  -I"$DXDIR""Include" -L"$DXDIR""lib/x86" -x c++ -o CGG.EXE  cg.c  -lwinmm -lstdc++ -mwindows 

